<?php
    
/*  Aquí emplearemos el patrón de Creación: Factory Method al cual la pasaremos
    como argumento la Interfaz del Object implicado, e invocaremos los métodos:
    CrearControlador_Object alojados en la clase Funciones, que nos devolverá
    el DAO correspondiente ya instanciado.
 
    Este patrón nos ahorra trabajo, puesto que nos libera sobre la forma 
    correcta de crear objetos, dada su flexibilidad al utilizar una clase 
    constructora (al estilo del Abstract Factory). 
 */
   
class AccesoDatosFactory {
    
    public static function obtenerDao_Operario(IDao_Operario $idao_operario)
    {
        return new Dao_Operario();
    }
    
    public static function obtenerDao_Equipo(IDao_Equipo $idao_equipo)
    {
        return new Dao_Equipo();
    }
    
    public static function obtenerDao_ListaValores(IDao_ListaValores $idao_listavalores)
    {
        return new Dao_ListaValores();
    }
    
    public static function obtenerDao_Mantenimiento(IDao_Mantenimiento $idao_mantenimiento)
    {
        return new Dao_Mantenimiento();
    }
}
