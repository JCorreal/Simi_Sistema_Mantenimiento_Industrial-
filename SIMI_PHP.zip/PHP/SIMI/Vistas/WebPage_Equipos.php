<!DOCTYPE html>
<html>
    <head>     
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
          <title>Equipos</title>             
          <link href="../resources/css/bootstrap1.min.css" rel="stylesheet" type="text/css"/>
    </head>    
    
    <body>        
    
        <?php
            require_once '../Vistas/WebPage_Maestro.php';
            require_once '../Controladores/AutoLoader.php';
            spl_autoload_register(); 
                             
            $mensajeError = null;
            $id = 0;
            $marca = null;  
            $linea = null;
            $nombre_equipo = null;
            $lubricacion = null;
            $serie = null;           
            $armarcas = array();
            $arlineas = array();
            $controlador = Funciones::crearControlador_Equipo(); 
            $arlistado = $controlador->controlarProgramacion();
            $tamano = sizeof($arlistado);
            
            for($j = 0; $j < $tamano; $j++)
            {           
                if ($arlistado[$j] == 'MARCAS')
                {                   
                    $listavalores = new ListaValores();
                    $listavalores->setListaValores_Id($arlistado[$j+1]);
                    $listavalores->setNombre($arlistado[$j+2]);
                    array_push($armarcas, $listavalores);
                    $j++; $j++;
                }           
                elseif ($arlistado[$j] == 'LINEAS')
                {                   
                    $listavalores = new ListaValores();
                    $listavalores->setListaValores_Id($arlistado[$j+1]);
                    $listavalores->setNombre($arlistado[$j+2]);
                    array_push($arlineas, $listavalores); 
                    $j++; $j++;
                }        
            }  
            
            if ($armarcas == null) 
            {
                $mensaje= Mensajes::Mensaje11;   
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
            }
            elseif ($arlineas == null)
            {
                $mensaje= Mensajes::Mensaje12;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
            }
 

            if (filter_input_array(INPUT_GET))
            {                
	        $id = base64_decode(filter_input(INPUT_GET, 'id'), FILTER_SANITIZE_NUMBER_INT);          
                if (($id != 0) && ($id != null))
                {                    
                    $equipo = $controlador->obtenerEquipo($id);
                    if ($equipo != null)
                    {
                        $nombre_equipo = $equipo->getNombre_equipo();
                        $marca = $equipo->getMarca();              
                        $serie = $equipo->getSerie();
                        $linea = $equipo->getLinea();
                        $lubricacion = $equipo->getLubricacion();
                    }
                }
     	    }
        
            
            if (filter_input_array(INPUT_POST)) 
            {
                $id = trim(filter_input(INPUT_POST, 'itCampoClave', FILTER_SANITIZE_NUMBER_INT));
                $nombre_equipo = trim(filter_input(INPUT_POST, 'itNombre', FILTER_SANITIZE_STRING));
                $serie = trim(strtoupper(filter_input(INPUT_POST, 'itSerie', FILTER_SANITIZE_STRING)));                    
                $marca = filter_input(INPUT_POST,'slMarcas');
                $linea = filter_input(INPUT_POST,'slLineas');                
                $lubricacion = (filter_input(INPUT_POST,'chLubricacion')?1:0);

                $grabar = true;
                if (Funciones::validar_CampoRequerido($nombre_equipo))
                {
		    $grabar = false;
		    $mensajeError = 'Nombre'.' '.Mensajes::MensajeCampoRequerido;		    
		}
                if (Funciones::validar_CampoRequerido($serie))
                {
                    $grabar = false;
                    $mensajeError = 'Serie'.' '.Mensajes::MensajeCampoRequerido;	    
                }
          
                if ($grabar)
                {                  
                  Response_Equipo::grabarEquipo(); 
                }
            }      
        ?>
       
        <form name="WebPage_Equipos" 
              action="WebPage_Equipos.php"              
              class="formoid-solid-green" 
              style="background-color:#FFFFFF;
                     font-size:12px;
                     font-family:'Roboto',Arial,Helvetica,sans-serif;
                     color:#34495E;
                     max-width:480px;
                     min-width:150px" 
              method="post">
            
            <div class="title"><h2><i class="fa fa-wrench"></i>&nbsp;Equipos</h2></div>
            <input id="itCampoClave" name="itCampoClave" type="hidden" value="<?php echo !empty($id)?$id:0;?>"/>
                                
            
	    <div class="element-input">
                 <label for="itNombre" class="title">
                        <span class="required">Nombre *</span>
                 </label>
                <div class="item-cont">
                     <input class="medium" 
                            type="text"
                            id="itNombre" 
                            name="itNombre"  
                            required="required"                            
                            maxLength="50"                        
                            placeholder="Nombre Equipo"
                            value="<?php echo !empty($nombre_equipo)?$nombre_equipo:'';?>"/> 
                   
                    <span class="icon-place"></span>
                </div>
            </div>
            

        <div class="element-select">
            <label for="slMarcas" class="title"><span class="required">Marca *</span></label>
            <div class="item-cont">
                <div class="medium"><span>
                    <select id="slMarcas" 
                            name="slMarcas">
                                   <?php foreach($armarcas as $listavalores): ?>
                                        <option value="<?php echo $listavalores->getListaValores_Id(); ?>"
                                        <?php if (($id != 0) && ($listavalores->getListaValores_Id() == $marca)): ?>
                                                  selected="selected"
                                        <?php endif; ?>>
                                        <?php echo $listavalores->getNombre(); ?>
                                        </option>      
                                   <?php endforeach;?>                             
                    </select>
                      <i></i><span class="icon-place"></span></span>
                </div>
            </div>
        </div>
                
        <div class="element-input">
             <label for="itSerie" class="title">
                    <span class="required">Serie *</span>
              </label>
            <div class="item-cont">
                  <input class="medium"
                         type="text"
                         id="itSerie" 
                         name="itSerie" 
                         maxLength="20"
                         required="required" 
                         placeholder="Serie"
                         value="<?php echo !empty($serie)?$serie:'';?>"/>
                   
                <span class="icon-place"></span>
            </div>
        </div>
	
        <div class="element-select">
             <label for="slLineas" class="title"><span class="required">Linea *</span></label>
            <div class="item-cont">
                <div class="medium"><span>
                    <select id="slLineas" 
                                  name="slLineas">
                                   <?php foreach($arlineas as $listavalores): ?>
                                        <option value="<?php echo $listavalores->getListaValores_Id(); ?>"
                                        <?php if (($id != 0) && ($listavalores->getListaValores_Id() == $linea)): ?>
                                                  selected="selected"
                                        <?php endif; ?>>
                                        <?php echo $listavalores->getNombre(); ?>
                                        </option>      
                                   <?php endforeach;?>                             
                    </select>
                    <i></i><span class="icon-place"></span></span>
                </div>
            </div>
        </div>
               

	
	<div class="element-checkbox">
            <label for="chLubricacion" class="title">Lubricacion</label>	
            <div class="column column1">
                 <input type="checkbox" 
                        id="chLubricacion" 
                        name="chLubricacion"
                    <?php if ($lubricacion == 1): ?> checked="checked"<?php endif; ?>/>
           
             <span></span>
            </div>
            <span class="clearfix"></span>
        </div>


            <div>
                <label id="labelMensajeError" style="color: red; "><?php echo !empty($mensajeError)?$mensajeError:'';?></label>
            </div>
            
            <div class="submit">
                <input type="submit" 
                       value="Enviar"
                       onmousedown="return VerificarEquipos();"/>             
            </div>  
      </form>
    
</body>

</html>
