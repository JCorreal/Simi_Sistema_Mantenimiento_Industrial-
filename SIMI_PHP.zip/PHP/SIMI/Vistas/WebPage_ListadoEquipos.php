<!DOCTYPE html>
<html lang="es">
    <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Listado Equipos</title> 
            <link href="../resources/css/bootstrap1.min.css" rel="stylesheet" type="text/css"/>
            <script src="js/ValidacionesPaginas.js" type="text/javascript"></script>
    </head>    

    <body>      
        <?php
          ini_set('display_errors', 1);
             ini_set('display_startup_errors', 1);
             error_reporting(E_ALL);
            require_once '../Vistas/WebPage_Maestro.php';
            require_once '../Controladores/AutoLoader.php';
            spl_autoload_register(); 

            $pagina = 'WebPage_Equipos.php';
            $datoBuscar = null;

            if (filter_input_array(INPUT_GET))  
            {
                $datoBuscar = strtoupper(filter_input(INPUT_GET, 'Buscar', FILTER_SANITIZE_STRING));             
            }

            $controlador = Funciones::crearControlador_Equipo();         
            if (filter_input_array(INPUT_POST))    
            {                 
                if (filter_input(INPUT_POST, 'itBusqueda') != '')
                {
                   $datoBuscar = filter_input(INPUT_POST, 'itBusqueda');
                   header("Location: ../Vistas/WebPage_ListadoEquipos.php?Buscar=$datoBuscar");                    
                }                  
                else
                {   
                   header("Location: ../Vistas/$pagina");                            
                }               
            }
        ?>   

      <form name="WebPage_ListadoEquipos" action="WebPage_ListadoEquipos.php" method="post">
   
          <div class="container">
		
		<br>
                
                <table width="55%" align="center" border="1" cellspacing="0" cellpadding="6">
          
                    <tr>
                        <td align="center" width="55%"  bgcolor="teal"><label class="titulos">Equipos&nbsp;<i class="fa fa-wrench"></i></label></td>             
                    </tr>
	                            
                    <div align="center">
                         <input type="submit" name="btnNuevo" value="Nuevo"/>            
                         <input type="submit" name="btnBuscar" value="Buscar" />   
                            <input class="small"
                                   type="text"
                                   id="itBusqueda"
                                   name="itBusqueda"      
                                   placeholder="Serie Equipo"
                                   maxLength="20"                         
                                   value="">
                          </input>                 
                   </div>
                <table/>
          

		<table width="55%" rules="all" border="1" align="center">
                    <thead>
                        <tr>                         
                             <th>Nombre</th>
                             <th>Serie</th>
                             <th>Lubricacion</th>
                             <th>Acciones</th>
                        </tr>
                    </thead>
                      
                    <tbody>
                            <?php
                                $vector_resultado = $controlador->cargarListado($datoBuscar);
                                foreach($vector_resultado as $lista => $valor){
		            ?>
                            <tr>                                
                                <td><?php echo $valor[1];  ?></td>
                                <td><?php echo $valor[2];  ?></td>
                                <?php if($valor[5] === 'SI')
                                      {
                                        echo '<td><span class="label label-success">SI</span></td>';
                                      }
                                      else
                                      {
                                        echo '<td><span class="label label-warning">NO</span></td>';
                                      }
                                ?>
                                <td style="width:100px;">
                                <a href="../Vistas/WebPage_Equipos.php?id=<?php echo base64_encode($valor[0]);  ?>" title="Editar datos" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>                                                                         
                                &nbsp &nbsp  
                                <a href="../Form_Response/Response_Eliminar.php?accion=3&id=<?php echo base64_encode($valor[0]);  ?> " onclick="return ConfirmarBorrado();"  title="Eliminar" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                            </tr>
			    <?php } ?>   
                        </tbody>                            
                </table>
	   
	 </div>
	
      </form>              
			
</body>
</html>
