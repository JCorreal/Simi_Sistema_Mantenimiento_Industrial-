<!DOCTYPE html>
<html>
    <head>			
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
          <title>Acceso</title>                  
          <script src="js/ValidacionesPaginas.js" type="text/javascript"></script>
    </head>    
    
    <body>        
        <?php 
                require_once '../Vistas/WebPage_Maestro.php';                          
                require_once '../Controladores/AutoLoader.php';
                spl_autoload_register();
               
                $mensajeError =  null;
                $documento = null;
                $clave = null;
             
                if (filter_input_array(INPUT_POST))    
                {     
                    $mensajeError =  Mensajes::Mensaje2;     
                    $documento = trim(filter_input(INPUT_POST, 'itDocumento', FILTER_SANITIZE_NUMBER_INT));
                    $clave = trim(filter_input(INPUT_POST,'itClave', FILTER_SANITIZE_NUMBER_INT));               
                    $ingresar = true;

                    if (Funciones::validar_CampoRequerido($documento)) 
                    {
                        $ingresar = false;
                        $mensajeError = 'Documento'.' '.Mensajes::MensajeCampoRequerido;	                    
                    }  
                    if (!preg_match('/^[0-9]+$/', $documento))
                    { // No mostrar mensaje para que no se enteren que el campo es numérico
                       $ingresar = false;                                          
                    }
                    if(strlen($documento) < 6)
                    {
                        $ingresar = false;                    
                    }
                    if (Funciones::validar_CampoRequerido($clave))
                    {
                       $ingresar = false; 
                       $mensajeError = 'Clave'.' '.Mensajes::MensajeCampoRequerido;		    
                    }     
                    if (!preg_match('/^[0-9]+$/', $clave))
                    { // No mostrar mensaje para que no se enteren que el campo es numérico
                       $ingresar = false;                                          
                    }
                    if(strlen($clave) != 6)
                    {
                       $ingresar = false;                    
                    }
                    if ($ingresar)
                    {             
                        Response_Acceso::ingresarSistema();
                    }
                } 
	?>

        <form name="index" 
              action="index.php" 
              class="formoid-solid-green" 
              style="background-color:#FFFFFF;
                     font-size:12px;
                     font-family:'Roboto',Arial,Helvetica,sans-serif;
                     color:#34495E;
                     max-width:440px;
                     min-width:150px" 
              method="post">
            
        <div class="title"><h2><i class="fa fa-key"></i>&nbsp;Acceso</h2></div>
         
	<div class="element-name">
              <label for="itDocumento" class="title">
                     <span class="required">Documento *</span>
              </label>
            <div class="nameFirst">
                  <input class="small" 
                         type="text" 
                         id="itDocumento" 
                         name="itDocumento" 
                         required="required"
                         placeholder="Usuario"
                         maxlength="10"
                         size="10"
                         value="<?php echo !empty($documento)?$documento:'';?>"/>                
                  <span class="icon-place"></span>
            </div>
        </div>
         
	<div class="element-password">
              <label for="itClave" class="title">
                     <span class="required">Clave *</span>
              </label>

            <div class="item-cont">
                  <input class="small"
                         type="password" 
                         id="itClave" 
                         name="itClave" 
                         required="required"
                         placeholder="Password"
                         maxlength="6"
                         size="6"
                         onkeypress="return ValidarNumeros(event)" 
                         onkeydown="return AnularPegado(event)"
                         value="<?php echo !empty($clave)?$clave:'';?>"/>                  
                  <span class="icon-place"></span>
            </div>
        </div>
         
        <div>
             <label id="labelMensajeError" style="color: red; "><?php echo !empty($mensajeError)?$mensajeError:'';?></label>
        </div>
         
         <div class="submit">
             <input type="submit"  
                    value="Enviar" 
                    onmousedown="return VerificarAcceso();"/>
         </div>
     </form>
   </body>
 </html>
