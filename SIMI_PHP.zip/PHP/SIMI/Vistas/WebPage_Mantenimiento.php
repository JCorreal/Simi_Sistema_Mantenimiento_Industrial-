<!DOCTYPE html>
<html>
    <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Mantenimiento</title>	        
            <script src="js/ValidacionesPaginas.js" type="text/javascript"></script>
    </head>
    
    <body>
        <?php
            require_once '../Vistas/WebPage_Maestro.php'; 
            require_once '../Controladores/AutoLoader.php';
            spl_autoload_register(); 
         
            $mensajeError = null;
            $id = 0;
            $codigo = null;
            $documento = null;
            $fecha = null;         
            $observaciones = null;
            $arlistado = array();
            $arequipos = array();
            $aroperarios = array();                          
            $controlador = Funciones::crearControlador_Mantenimiento();       
                                           
            if (filter_input_array(INPUT_GET))
            {                
                $id = base64_decode(filter_input(INPUT_GET, 'id'), FILTER_SANITIZE_NUMBER_INT);
                $arlistado = $controlador->controlarProgramacion('PROGRAMACION');
                $tamano = sizeof($arlistado);
                for($i = 0; $i < $tamano; $i++)
                {              
                    if ($arlistado[$i] == 'EQUIPOS')
                    {                   
                        array_push($arequipos, $arlistado[$i+1], $arlistado[$i+2]);
                        $i++; $i++;
                    }           
                    elseif ($arlistado[$i] == 'OPERARIOS')
                    {                   
                        array_push($aroperarios, $arlistado[$i+1], $arlistado[$i+2]);
                        $i++; $i++;                       
                    }  
                } 
                if ($aroperarios == null) 
                {
                    $mensaje= Mensajes::Mensaje13;   
                    header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
                }
                elseif ($arequipos == null)
                {
                    $mensaje= Mensajes::Mensaje14;
                    header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
                }
                if (($id != 0) && ($id != null))
                {
                    $mantenimiento = $controlador->obtenerMantenimiento($id);
                    if ($mantenimiento != null)
                    {
                        $id = $mantenimiento->getMantenimiento_Id();
                        $codigo = $mantenimiento->getEquipo_Id();                 
                        $documento = $mantenimiento->getOperario_Id();                 
                        $fecha = $mantenimiento->getFecha();                 
                        $observaciones = $mantenimiento->getObservaciones();                         
                    }
                }
            }              
            else 
            {                
                $arlistado = $controlador->ControlarProgramacion('PROGRAMAR');                 
                $tamano = sizeof($arlistado);
                for($i = 0; $i < $tamano; $i++)
                {
                  if ($arlistado[$i] == 'EQUIPOS')
                  {                   
                      array_push($arequipos, $arlistado[$i+1], $arlistado[$i+2]);
                  }           
                  elseif ($arlistado[$i] == 'OPERARIOS')
                  {                   
                      array_push($aroperarios, $arlistado[$i+1], $arlistado[$i+2]);
                  }           
                }
            } 
            
            if (filter_input_array(INPUT_POST))
            {            
              $id = filter_input(INPUT_POST, 'itCampoClave', FILTER_SANITIZE_NUMBER_INT);  
              $codigo = filter_input(INPUT_POST, 'slEquipos', FILTER_SANITIZE_NUMBER_INT);
              $documento = filter_input(INPUT_POST, 'slOperarios', FILTER_SANITIZE_NUMBER_INT);           
              $fecha = filter_input(INPUT_POST, 'itFecha', FILTER_SANITIZE_STRING);          
              $observaciones = filter_input(INPUT_POST,'itObservaciones',FILTER_SANITIZE_STRING);

              $grabar = true;
              if ($fecha < date("Y-m-d")) // Ojo si desea conectar con Oracle Cambiar a D/M/Y
              {
                  $grabar = false;
                  $mensajeError = Mensajes::Mensaje27;
              }

              if ($grabar)
              {              
                Response_Mantenimiento::grabarMantenimiento();
              }
          }        
        ?>
       
        <form name="WebPage_Mantenimiento" action="WebPage_Mantenimiento.php" 
              class="formoid-solid-green" 
              style="background-color:#FFFFFF;
                     font-size:12px;
                     font-family:'Roboto', Arial,Helvetica,sans-serif;
                     color:#34495E;
                     max-width:480px;
                     min-width:150px" 
              method="post">
              
            <div class="title"><h2><i class="fa fa-calendar"></i>&nbsp;Mantenimiento</h2></div>
            <input id="itCampoClave" name="itCampoClave" type="hidden" value="<?php echo !empty($id)?$id:0;?>"/>

          <div class="element-select">
               <label for="slEquipos" class="title">
                      <span class="required">Equipo *</span>
               </label>
              <div class="item-cont">
                  <div class="medium"><span>
                          <select id="slEquipos" 
                                  name="slEquipos" 
                                  required="required">
                                  <?php $size_Equipos = sizeof($arequipos); 
                                        for($i=0; $i < $size_Equipos; $i++){ ?>
                                        <option value="<?php echo $arequipos[$i];  ?>"
                                                <?php if (($id != 0) && ($arequipos[$i] == $codigo)): ?>
                                                           selected="selected"
                                                <?php endif; ?>
                                                ><?php $i++; echo $arequipos[$i]; } 
                                   ?>
                                        </option>
                          </select>
                          <i></i><span class="icon-place"></span></span>
                  </div>
              </div>
          </div>
          <div class="element-select">
               <label for="slOperarios" class="title">
                      <span class="required">Operario *</span>
               </label>
              <div class="item-cont">
                  <div class="medium"><span>
                          <select id="slOperarios" 
                                  name="slOperarios" 
                                  required="required">
                                  <?php $size_Operarios = sizeof($aroperarios);  
                                        for($i=0; $i < $size_Operarios; $i++){ ?>
                                        <option value="<?php echo $aroperarios[$i];  ?>"
                                                <?php if (($id != 0) && ($aroperarios[$i] == $documento)): ?>
                                                          selected="selected"
                                                <?php endif; ?>
                                                ><?php $i++; echo $aroperarios[$i]; } 
                                   ?>
                                        </option>
                          </select>
                          <i></i><span class="icon-place"></span></span>
                  </div>
               </div>
          </div>
          <div class="element-date">
              <label for="itFecha" class="title">
                     <span class="required">Fecha *</span>
              </label>
              <div class="item-cont">
                  <input class="medium"                         
                         type="date" 
                         id="itFecha" 
                         name="itFecha" 
                         data-format="yyyy-mm-dd"
                         required="required"                       
                         value="<?php echo !empty($fecha)?$fecha: date("Y-m-d");?>"/>

                  <span class="icon-place"></span>
              </div>
          </div>
          <div class="element-textarea">
               <label for="itObservaciones" class="title">Observaciones</label>
               <div class="item-cont">             
                    <textarea id="itObservaciones"                                      
                              name="itObservaciones" 
                              placeholder="Observacion" 
                              maxlength="255"
                              cols="30"
                              rows="4"><?php echo !empty($observaciones)?$observaciones:'';?>
                    </textarea>
                    <span class="icon-place"></span>
               </div>
          </div>

          <div>
              <label id="labelMensajeError" style="color: red; "><?php echo !empty($mensajeError)?$mensajeError:'';?></label>
          </div>

           <div class="submit">
                <input type="submit" 
                       value="Enviar" 
                       onmousedown="return VerificarMantenimiento();"/>             
           </div>
        </form>           
    </body>
</html>


