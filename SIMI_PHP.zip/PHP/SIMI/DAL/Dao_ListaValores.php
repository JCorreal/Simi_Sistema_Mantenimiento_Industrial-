<?php // Capa Acceso Datos para Marcas y Líneas
    
class Dao_ListaValores extends Dao_General implements IDao_ListaValores {
  
    public function obtenerListaValores($datoBuscar)
    {  
        $vecresultado = array();  
        $listavalores = new ListaValores();
        try
        {
            $vecresultado = parent::buscarRegistro('TBL_LISTAVALORES', $datoBuscar);
            if ($vecresultado != null)
            {                
                $listavalores->setListaValores_Id($vecresultado[0][0]);
                $listavalores->setNombre($vecresultado[0][1]);
                $listavalores->setDescripcion($vecresultado[0][2]);
                $listavalores->setTipo($vecresultado[0][3]);   
                unset($vecresultado);                
            }
            return $listavalores;           
        }
        catch (Exception $ex)
        {
           echo $ex;
        }
    }

    public function guardarListaValores($listavalores, $usuario)
    {          
        $cn = Conexion::obtenerConexion();  
        try
        {             
            $cn->query("SET @result = 1");
            $cn->query("CALL SPR_IU_ListaValores('" . $listavalores->getListaValores_Id() . "', 
                                                 '" . $listavalores->getNombre() . "', 
                                                 '" . $listavalores->getDescripcion() . "', 
                                                 '" . $listavalores->getTipo() . "', 
                                                 '" . $usuario . "',  
                                                 @result)");

            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];
        }
        catch (Exception $ex)
        {
           mysqli_close($cn);
           echo $ex;
        }  
    }
  
   
    public function cargarListado($tabla, $opcion) {
        $listaElementos = parent::cargarListas($tabla, $opcion);
        return $listaElementos;
    }
    
    public function eliminarRegistro($datoEliminar) {
      $result = parent::borrarRegistro("TBL_LISTAVALORES", $datoEliminar);
      return $result;
    }
}
