<?php // Este es el Response para el registro de Marcas y Líneas
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL); 

class Response_ListaValores {
  
    public static function grabarListaValores()
    {
        $listavalores = new Listavalores ();                
        $listavalores->setListaValores_Id(filter_input(INPUT_POST, 'itCampoClave',FILTER_SANITIZE_NUMBER_INT));     
        $listavalores->setNombre(strtoupper(filter_input(INPUT_POST, 'itNombre', FILTER_SANITIZE_STRING)));
        $listavalores->setDescripcion(filter_input(INPUT_POST, 'itDescripcion',FILTER_SANITIZE_STRING));   
        $listavalores->setTipo(filter_input(INPUT_POST, 'itTipo',FILTER_SANITIZE_STRING));                 
        $controlador = Funciones::crearControlador_ListaValores();
        $resultado = $controlador->guardarListaValores($listavalores);
        if ($resultado == 0)
        {
            $mensaje = null;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");
        }
        elseif ($resultado == 1)
        {
            $mensaje = Mensajes::Mensaje8;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
        }
        else 
        {
            $mensaje = Mensajes::MensajeErrorBD;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
        }
    }
}
