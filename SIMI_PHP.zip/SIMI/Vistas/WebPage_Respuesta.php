<html>
    <head>
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
          <title>Respuesta</title>
    </head>

    <body>
        <?php 
              require_once '../Vistas/WebPage_Maestro.php';
              require_once '../Controladores/AutoLoader.php';
              spl_autoload_register();          
              $respuesta = filter_input(INPUT_GET,'respuesta');
        ?> 
 
        <form name="WebPage_Respuesta" 
              action="WebPage_Respuesta.php"
              class="formoid-solid-green" 
              style="background-color:#FFFFFF;
                     font-size:12px;
                     font-family:'Roboto', Arial,Helvetica,sans-serif;
                     color:#34495E;
                     max-width:440px;
                     min-width:140px">                  
               
                <div class="title">                                       
                    <?php if($respuesta == 'R'){ ?>  
                    <img src="../resources/Imagenes/Informacion.jpg" alt=""/>    
                    <?php } ?>     
                    <?php if($respuesta == 'E'){ ?>
                    <img src="../resources/Imagenes/Error.jpg" alt="">
                    <?php } ?>  
                </div>
                
                <br>
                
                <div>
                     <label id="labelMensajeError" style="color: red; "><?php echo filter_input(INPUT_GET,'mensaje'); ?></label>
                </div>
                
                <br>
                
                <div align="center">
                    <a href="WebPage_Menu.php" style="font-size:20px"><i class="fa fa-home"></i>&nbsp;Regresar Menu</a>
                </div>    
                <br>
        </form>     
    </body>
</html>
