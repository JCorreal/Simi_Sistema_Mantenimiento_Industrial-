<?php // Este es un DAO General con métodos transvesales que los demás extienden

class Dao_General {
    
    public function buscarRegistro($tabla, $datoBuscar)
    { // Función para buscar un registro específico       
        $cn = Conexion::obtenerConexion();          
        try 
        {           
            $rs = $cn->query("CALL SPR_R_BuscarRegistro('" . $tabla . "', '" . $datoBuscar . "')");
            $vecresultado = array(); // Recorremos el resultado de la consulta y lo almacenamos en el array
            while ($fila = $rs->fetch_row()) 
            {
                array_push($vecresultado, $fila);                
            }
            mysqli_free_result($rs);
            mysqli_close($cn);
            return $vecresultado;
        }
        catch (Exception $ex)
        { 
           mysqli_close($cn);
           echo $ex;     
        }
    }

    public function cargarListas($tabla, $opcion)
    { 
        $listaElementos = array();    
        $cn = Conexion::obtenerConexion();    
        try
        {  
            $rs = $cn->query("CALL SPR_R_CargarListado('" . $tabla . "',  '" . $opcion . "')");          
            while ($fila = $rs->fetch_row())
            {
               array_push($listaElementos, $fila);                
            }
            mysqli_free_result ($rs);
            mysqli_close($cn);
            return  $listaElementos;
        }
        catch (Exception $ex)
        { 
           mysqli_close($cn); 
           echo $ex;     
        }
    }
   
    public function controlProgramacion($tabla)
    { 
        $resultado1 = NULL;
        $resultado2 = NULL;     
        $resultado3 = NULL;    
        $cn = Conexion::obtenerConexion();    
        try
        {
            $refCAllSp = $cn->prepare('CALL SPR_R_CargarCombosListas(?)');
            $refCAllSp->bind_param("s", $tabla);
            $refCAllSp->execute();      
            $refCAllSp->bind_result($resultado1, $resultado2, $resultado3); 
            $listaElementos = array();
            while ($refCAllSp->fetch())
            {  
                 array_push($listaElementos, $resultado3);  
                 array_push($listaElementos, $resultado1);
                 array_push($listaElementos, $resultado2);
            }
            mysqli_stmt_close ($refCAllSp);
            mysqli_close($cn);      
            return $listaElementos;
        }
        catch (Exception $ex)
        { 
           mysqli_close($cn); 
           echo $ex;     
        } 
    }
  
    public function borrarRegistro($tabla, $datoEliminar)
    {
        $cn = Conexion::obtenerConexion();      
        try
        {           
            $cn->query("SET @result = 1");
            $cn->query("CALL SPR_D_Registro('" . $tabla . "', '" . $datoEliminar . "',  @result)");
            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];
        }
        catch (Exception $ex)
        {
            mysqli_close($cn);
            echo $ex;
        }  
    }
}
