<!DOCTYPE html>
<html>    
    <head>
           <title>.</title>
           <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">                   
	   <link href="../resources/css/bootstrap.min.css" rel="stylesheet" media="screen">
           <link href="../resources/css/font-awesome.css" rel="stylesheet" type="text/css"/>
	   <link href="../resources/css/my_style.css" rel="stylesheet" media="screen">
	   <link href="../resources/css/styles.css" rel="stylesheet" media="screen">        
           <link href="../resources/css/Estilo.css" media="screen" rel="stylesheet" type="text/css"/>
    </head> 
        
    <body>
            <?php require_once '../Controladores/Mensajes.php'; ?>  
            <div class="DivSuperior"><br><?php echo Mensajes::MensajeAplicacion;?>                
                 <div class="DivIzquierda"></div>                                        
            </div>    
            <br><br>
    </body>
</html>



