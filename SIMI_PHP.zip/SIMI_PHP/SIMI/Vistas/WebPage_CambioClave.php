<!DOCTYPE html>
<html>
    <head>       
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Cambio Clave</title>	
            <script src="js/ValidacionesPaginas.js" type="text/javascript"></script>
    </head>
    
    <body>
        <?php 
                require_once '../Vistas/WebPage_Maestro.php';
                require_once '../Controladores/Funciones.php';
                require_once '../Form_Response/Response_CambioClave.php';

                $mensajeError = null;
                $clave        = null;
                $clavenueva   = null;
                $confirmar    = null;                           
                
                if (filter_input_array(INPUT_POST))        
                {
                    $clave = trim(filter_input(INPUT_POST, 'itClave', FILTER_SANITIZE_NUMBER_INT));
                    $clavenueva = trim(filter_input(INPUT_POST, 'itClaveNueva', FILTER_SANITIZE_NUMBER_INT));
                    $confirmar = trim(filter_input(INPUT_POST, 'itConfirmar', FILTER_SANITIZE_NUMBER_INT));

                    $grabar = true;                
                    if (Funciones::validar_CampoRequerido($clave))
                    {   
                        $grabar = false;
                        $mensajeError ='Clave'.' '.Mensajes::MensajeCampoRequerido;	
                    }	               
                    if (Funciones::validar_CampoRequerido($clavenueva))
                    {   
                        $grabar = false;
                        $mensajeError ='ClaveNueva'.' '.Mensajes::MensajeCampoRequerido;
                    }	
                    if (strlen($clavenueva)!=6) {
                        $grabar = false;
                        $mensajeError = Mensajes::Mensaje21;			
                    }
                    if ($clavenueva == $clave) {
                        $grabar = false;
                        $mensajeError = Mensajes::Mensaje4;		    
                    }                
                    if (Funciones::validar_CampoRequerido($confirmar))
                    {                  
                         $grabar = false;	
                         $mensajeError ='Confirmar'.' '.Mensajes::MensajeCampoRequerido;		
                    }	
                    if ($confirmar != $clavenueva) 
                    {
                        $grabar = false;
                        $mensajeError = Mensajes::Mensaje5;		    
                    }
                    if ($grabar)
                    {             
                       Response_CambioClave::grabarCambioClave($clave, $clavenueva);
                    }
                } 
        ?>
            <form name="WebPage_CambioClave" 
                  action="WebPage_CambioClave.php"
                  class="formoid-solid-green" 
                  style="background-color:#FFFFFF;
                         font-size:12px;
                         font-family:'Roboto', Arial,Helvetica,sans-serif;
                         color:#34495E;
                         max-width:440px;
                         min-width:150px" 
                   method="post">
        
                <div class="title"><h2><i class="fa fa-key"></i>&nbsp;Cambio Clave</h2></div>

                <div class="element-password">
                     <label for ="itClave" class="title">
                            <span class="required">Clave Actual *</span>
                     </label>
                    <div class="item-cont">
                         <input class="small" 
                                type="password" 
                                id="itClave" 
                                name="itClave"                                 
                                required="required" 
                                placeholder="Clave"
                                maxlength="6"
                                size="6"
                                onkeypress="return ValidarNumeros(event)" 
                                onkeydown="return AnularPegado(event)"
                                value="<?php echo !empty($clave)?$clave:'';?>"/>             
                         <span class="icon-place"></span>
                    </div>
                </div>

                <div class="element-password">
                     <label for="itClaveNueva" class="title">
                            <span class="required">Clave Nueva *</span>
                     </label>
                    <div class="item-cont">
                         <input class="small" 
                                type="password" 
                                id="itClaveNueva" 
                                name="itClaveNueva"                                  
                                required="required" 
                                placeholder="Clave Nueva"
                                maxlength="6"
                                size="6"
                                onkeypress="return ValidarNumeros(event)" 
                                onkeydown="return AnularPegado(event)"
                                value="<?php echo !empty($clavenueva)?$clavenueva:'';?>"/>                
                         <span class="icon-place"></span>
                    </div>
                </div>

                <div class="element-password">
                     <label for="itConfirmar" class="title">
                            <span class="required">Confirmar *</span>
                     </label>
                    <div class="item-cont">
                         <input class="small" 
                                type="password" 
                                id="itConfirmar" 
                                name="itConfirmar"                                 
                                required="required" 
                                placeholder="Confirmar Clave"
                                maxlength="6"
                                size="6"
                                onkeypress="return ValidarNumeros(event)" 
                                onkeydown="return AnularPegado(event)"
                                value="<?php echo !empty($confirmar)?$confirmar:'';?>"/>                
                         <span class="icon-place"></span>
                    </div>
                </div>    

                <div>
                    <label id="labelMensajeError" style="color: red; "><?php echo !empty($mensajeError)?$mensajeError:'';?></label>
                </div>

                <div class="submit">
                     <input type="submit" 
                            value="Enviar" 
                            onmousedown="return VerificarCambioClave();"/>              
                </div>
            </form>
    </body>
</html>