<?php
        require_once '../Controladores/Mensajes.php';
        require_once '../Controladores/Funciones.php';

        $id = base64_decode(filter_input(INPUT_GET, 'id'), FILTER_SANITIZE_NUMBER_INT);                 
        $tabla = (filter_input(INPUT_GET, 'accion'));
        $resultado = -1;             
        if ($tabla == '1') // TBL_OPERARIOS
        {
            $controlador = Funciones::crearControlador_Operario();
            $resultado = $controlador->eliminarRegistro($id);
            if ($resultado == 1)
            {
                $mensaje= Mensajes::Mensaje20;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }  
            else if ($resultado == 0)
            {
                $mensaje = null;  
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
            }
            else
            {
                $mensaje = Mensajes::MensajeErrorBD;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }
        }
        if ($tabla == '2') // TBL_LISTAVALORES
        {
            $controlador  = Funciones::crearControlador_ListaValores();
            $resultado = $controlador->eliminarRegistro($id);
            if ($resultado == 1)
            {                   
                $mensaje= Mensajes::Mensaje9;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }
            else if ($resultado == 0)
            {
                $mensaje = null;  
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
            }
            else
            {
                $mensaje = Mensajes::MensajeErrorBD;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }
        }
        if ($tabla == '3') // TBL_EQUIPOS
        {
           $controlador  = Funciones::crearControlador_Equipo();
           $resultado = $controlador->eliminarRegistro($id);
           if ($resultado == 1)
           {                   
               $mensaje = Mensajes::Mensaje22;                                
               header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
           }
           else if ($resultado == 0)
           {
                  $mensaje = null;  
                  header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
           }
           else
           {
                  $mensaje = Mensajes::MensajeErrorBD;
                  header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
           }
        }
        if ($tabla == '4') // TBL_MANTENIMIENTO
        {
           $controlador  = Funciones::crearControlador_Mantenimiento();
           $resultado = $controlador->eliminarRegistro($id);                         
           if ($resultado == 0)
           {
               $mensaje = null;  
               header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
           }
           else
           {
               $mensaje = Mensajes::MensajeErrorBD;
               header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
           }
        }
