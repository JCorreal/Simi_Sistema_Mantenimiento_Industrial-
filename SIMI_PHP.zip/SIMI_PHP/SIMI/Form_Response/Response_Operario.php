<?php // Este es el Response para el registro de Operarios
     
class Response_Operario {
     
    public static function grabarOperario($foto)
    {       
        $operario = new Operario();   
        $operario->setOperario_Id(filter_input(INPUT_POST, 'itCampoClave',FILTER_SANITIZE_NUMBER_INT));        
        $operario->setDocumento(filter_input(INPUT_POST, 'itDocumento',FILTER_SANITIZE_STRING));
        $operario->setNombres(ucwords(strtolower(filter_input(INPUT_POST, 'itNombres',FILTER_SANITIZE_STRING))));
        $operario->setApellidos(ucwords(strtolower(filter_input(INPUT_POST, 'itApellidos',FILTER_SANITIZE_STRING))));        
        $operario->setTelefono(filter_input(INPUT_POST, 'itTelefono',FILTER_SANITIZE_NUMBER_INT));
        $operario->setCorreo(strtolower(filter_input(INPUT_POST, 'itCorreo', FILTER_SANITIZE_EMAIL)));
        $operario->setFoto($foto);

        $controlador = Funciones::crearControlador_Operario();       
        $resultado = $controlador->guardarOperario($operario);         

        if ($resultado == 0) 
        {
            $mensaje = null;  
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");   
        }
        elseif ($resultado == 1)
        {
            $mensaje = Mensajes::Mensaje26;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");   
        }
        else 
        {
            $mensaje = Mensajes::MensajeErrorBD;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");   
        }     
    }

}



