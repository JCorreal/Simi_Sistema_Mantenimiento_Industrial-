<?php // Este es el Response para el cambio de clave de acceso al aplicativo    
     
class Response_CambioClave {

    public static function grabarCambioClave($claveanterior, $clavenueva)
    {         
        $controlador = Funciones::crearControlador_Operario();              
        $resultado = $controlador->guardarCambioClave($claveanterior, $clavenueva);
        if ($resultado == 0)
        { 
            $mensaje = null;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");
        }     
        elseif ($resultado == 1)
        {
            $mensaje = Mensajes::Mensaje3;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");   
        }
        else 
        {
            $mensaje = Mensajes::MensajeErrorBD;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
        }      
          
    }
}


