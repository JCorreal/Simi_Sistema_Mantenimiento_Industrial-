﻿<?php  /* Clase que nos devuelve la conexion con el proveedor que se desee, por
          defecto está configurada para conectar con MariaDB-MySQL, pero puedes optar
          por cambiar a SQL Server u Oracle.
          ==================================================================================
                               Conectar con SQL Server  
          ==================================================================================
           $serverName = "NombrePC\SQLEXPRESS";
           $connectionInfo=array( "Database"=>"SIMIDB");                
           $conexion = sqlsrv_connect( $serverName, $connectionInfo);
           if( !$conexion ) {
        
          ==================================================================================
                               Conectar con ORACLE  
          ==================================================================================
          Si se desea efectuar la conexión con Oracle, debes reemplazar las dos lineas anteriores
          por las siguientes:
         
          $conexion = oci_connect('SIMIDB', 'XXXX', 'localhost/XE');
          if (!$conexion) {
         
          Y por supuesto reemplazar el directorio DAL por el correspondiente a Oracle
          Además de quitar el ; del archivo PHP.ini para habilitar las conexiones hacia Oracle
          Ojo buscar y quitar el ; del comienzo de la siguiente línea en el PHP.ini
          ; extension=php_oci8_11g.dll  ; Use with Oracle 11gR2 Instant Client         
          ================================================================================== */
        

class Conexion {
 
    public static function obtenerConexion()
    {
        $server   = 'localhost';
        $username = 'root';
        $password = 'root';
        $database = 'SIMIDB'; 

        try
        {    
            $conexion = new mysqli($server, $username, $password, $database);
            if (mysqli_connect_errno())
            {          
                die("No se puede conectar a la base de datos");
            }
            else 
            {
               return($conexion);
            }         
        }
        catch (Exception $ex)
        { 
           echo $ex;     
        }
    }

}

 