<?php // Interface que expone los métodos que implementa el DAO de Mantenimiento

interface IDao_Mantenimiento {
  
   public function obtenerMantenimiento($datoBuscar);
   public function guardarMantenimiento($mantenimiento, $usuario); 
   public function cargarListado($opcion);
   public function controlarProgramacion($tabla);
   public function eliminarRegistro($datoEliminar);
   
}
