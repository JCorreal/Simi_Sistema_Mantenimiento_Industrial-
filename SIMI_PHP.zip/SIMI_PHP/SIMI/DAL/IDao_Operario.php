<?php // Interface que expone los métodos que implementa el DAO de Operarios

interface IDao_Operario {
  
  public function obtenerAcceso($documento, $clave);
  public function obtenerOperario($datoBuscar);
  public function guardarOperario($operario, $usuario);
  public function guardarCambioClave($claveanterior, $clavenueva, $usuario);
  public function cargarListado($opcion);
  public function eliminarRegistro($datoEliminar);
    
}
