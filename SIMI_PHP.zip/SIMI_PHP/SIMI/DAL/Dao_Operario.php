<?php // Capa Acceso Datos para control de Operarios
     
require_once 'IDao_Operario.php';
require_once 'Conexion.php';
require_once 'Dao_General.php';

      
class Dao_Operario extends Dao_General implements IDao_Operario {
    
    public function obtenerAcceso($documento, $clave) 
    {
        $operario = new Operario(); 
        $cn = Conexion::obtenerConexion();
        try
        { 
            $rs = $cn->query("CALL SPR_R_ObtenerAcceso('" . $documento . "', '" . $clave . "')");
            $fila = $rs->fetch_row();
            if ($fila != null)
            {
                $operario->setOperario_Id($fila[0]);          
                $operario->setNombres($fila[1]);
                $operario->setApellidos($fila[2]); 
                $operario->setPerfil($fila[3]);               
            }           
            mysqli_free_result($rs);
            mysqli_close($cn);
            return $operario;           
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
    }

    public function obtenerOperario($datoBuscar)
    {  
        $vecresultado = array();  
        $operario = new Operario();
        try
        { 
            $vecresultado = parent::buscarRegistro('TBL_OPERARIOS', $datoBuscar);
            if ($vecresultado != null)
            {                
                $operario->setOperario_Id($vecresultado[0][0]);
                $operario->setDocumento($vecresultado[0][1]);
                $operario->setNombres($vecresultado[0][2]);
                $operario->setApellidos($vecresultado[0][3]);
                $operario->setTelefono($vecresultado[0][4]);
                $operario->setCorreo($vecresultado[0][5]);   
                $operario->setFoto($vecresultado[0][6]);                             
            }
            unset($vecresultado);   
            return $operario;
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
  }

    public function guardarOperario($operario, $usuario)
    { 
        $cn = Conexion::obtenerConexion();
        try 
        {                   
            $cn->query("SET @result = 1");
            $cn->query("CALL SPR_IU_Operarios('" . $operario->getOperario_Id() . "',
                                              '" . $operario->getDocumento() . "',
                                              '" . $operario->getNombres() . "', 
                                              '" . $operario->getApellidos() . "', 
                                              '" . $operario->getTelefono() . "', 
                                              '" . $operario->getCorreo() . "',                                         
                                              '" . $operario->getFoto() . "', 
                                              '" . $usuario . "',                                                                          
                                              @result)");

            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];          
        }
        catch (Exception $ex)
        {
            mysqli_close($cn);  
            echo $ex;
        }
    }
    
    public function guardarCambioClave($claveanterior, $clavenueva, $usuario)
    {   
        $cn = Conexion::obtenerConexion();
        try
        {                    
            $cn->query("SET @result = 1");
            $cn->query("CALL SPR_U_CambioClave('" . $usuario . "', 
                                               '" . $claveanterior . "', 
                                               '" . $clavenueva . "', 
                                               @result)");
            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];        
        }
        catch (Exception $ex)
        { 
           mysqli_close($cn); 
           echo $ex;     
        }
    }
    
    public function cargarListado($opcion) {
        $listaElementos = parent::cargarListas("TBL_OPERARIOS", $opcion);
        return $listaElementos;
    }
    
    public function eliminarRegistro($datoEliminar) {
      $result = parent::borrarRegistro("TBL_OPERARIOS", $datoEliminar);
      return $result;
    }
}
