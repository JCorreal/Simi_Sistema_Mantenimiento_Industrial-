<?php // Este es el Controlador para el registro del Mantenimiento
     
require_once '../Modelos/Mantenimiento.php';
require_once '../DAL/Dao_Mantenimiento.php';

class Controlador_Mantenimiento {
   
    protected $idao_mantenimiento;
        
    public function __construct(IDao_Mantenimiento $idao_mantenimiento)
    {
        $this->idao_mantenimiento = new Dao_Mantenimiento();
    }
        
    public function obtenerMantenimiento($datoBuscar)
    {
       return $this->idao_mantenimiento->obtenerMantenimiento($datoBuscar);
    }
    
    public function guardarMantenimiento ($object)
    {
      $usuario = Funciones::obtenerUsuario(); 
      return $this->idao_mantenimiento->guardarMantenimiento($object, $usuario);
    }

    public function controlarProgramacion($tabla){      
      return $this->idao_mantenimiento->controlarProgramacion($tabla);
    }
    
    public function cargarListado($opcion) {
       return $this->idao_mantenimiento->CargarListado($opcion);
    }
    
    public function eliminarRegistro($datoBuscar){        
        return $this->idao_mantenimiento->eliminarRegistro($datoBuscar);
    }
}
