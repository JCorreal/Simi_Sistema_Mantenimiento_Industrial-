<?php // Colección de mensajes empleados por el aplicativo
   
class Mensajes
{    
    const MensajeAplicacion =  "SIMI - SISTEMA DE MANTENIMIENTO INDUSTRIAL";
    const MensajeGraba =  "El registro ha sido grabado satisfactoriamente";
    const MensajeActualiza =  "El registro ha sido modificado satisfactoriamente";
    const MensajeBorrado =  "El registro ha sido eliminado satisfactoriamente";
    const MensajeConfirmarBorrado =  "¿ Esta seguro que desea eliminar este registro ?";
    const MensajeCampoRequerido =  "Error, este campo es requerido por favor ingresar la informacion";
    const MensajeErrorBD =  "Se ha producido un error accesando la base de datos";
    const Mensaje2 =  "Error, La clave es incorrecta intente de nuevo";
    const Mensaje3 =  "Error, esta no es su clave actual, reportese  con el administrador";
    const Mensaje4 =  "Error, debe ingresar una clave diferente de la anterior";
    const Mensaje5 =  "Error, esta no es la misma clave digitada en clave nueva";
    const Mensaje6 =  "Error, primera cifra no puede ser 0";
    const Mensaje7 =  "Error, esta serie ya esta asignada a otro equipo";
    const Mensaje8 =  "Error, este nombre ya esta asignado";
    const Mensaje9 =  "Error, este registro no se puede eliminar ya que esta relacionado en equipos";
    const Mensaje10 =  "Error, ya existe una programacion para este operario en esta fecha";
    const Mensaje11 =  "No existen Marcas disponibles para relacionar al equipo";
    const Mensaje12 =  "No existen Lineas disponibles para relacionar al equipo";
    const Mensaje13 =  "No existen Operarios disponibles para relacionar al mantenimiento";
    const Mensaje14 =  "No existen Equipos disponibles para relacionar al mantenimiento";
    const Mensaje15 =  "Error, documentos no pueden ser menores de 6 digitos";
    const Mensaje16 =  "Error, correo con formato errado";
    const Mensaje17 =  "Error, la longitud del telefono debe tener 7 o 10 dígitos";
    const Mensaje18 =  "Error, no se encontro la foto referenciada en la ruta";
    const Mensaje19 =  "Error, el formato de la imagen no es valido";
    const Mensaje20 =  "Error, este operario no se puede eliminar ya que tiene programaciones pendientes";
    const Mensaje21 =  "Error, por favor ingrese una clave que contenga al menos 6 digitos";
    const Mensaje22 =  "Error, este equipo no se puede eliminar ya que tiene programacion pendiente por ejecutar";
    const Mensaje23 =  "Error, existen caracteres numericos en este campo";
    const Mensaje24 =  "Error, No se encontro la foto referenciada en la ruta";
    const Mensaje25 =  "Error, caracteres no numericos en este campo";
    const Mensaje26 =  "Error, este registro ya existe";
    const Mensaje27 =  "Error, fecha no puede ser menor que la actual";
    const Mensaje28 =  "Error, longitud del campo supera los caracteres permitidos";
    
}
    
    
  


