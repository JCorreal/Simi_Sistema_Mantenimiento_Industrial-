<?php // Este es el Controlador para el registro de Operarios
 
require_once '../Modelos/Operario.php';
require_once '../DAL/Dao_Operario.php';
 
class Controlador_Operario {
    
    protected $idao_operario;
        
    public function __construct(IDao_Operario $idao_operario)
    {
        $this->idao_operario = new Dao_Operario();
    }
    
    public function obtenerAcceso($datoBuscar, $clave) 
    {          
        return $this->idao_operario->obtenerAcceso($datoBuscar, $clave);       
    }
    
    public function obtenerOperario($datoBuscar)
    {
        return $this->idao_operario->obtenerOperario($datoBuscar);
    }
    
    public function guardarCambioClave($claveanterior, $clavenueva)
    {
      $usuario = Funciones::obtenerUsuario();        
      return $this->idao_operario->guardarCambioClave($claveanterior, $clavenueva, $usuario);
    }
    
    public function guardarOperario ($object)
    {
       $usuario = Funciones::obtenerUsuario();
       return $this->idao_operario->guardarOperario($object, $usuario); 
    }

    public function cargarListado($opcion) {
       return $this->idao_operario->cargarListado($opcion);
    }
    
    public function eliminarRegistro($datoBuscar){        
        return $this->idao_operario->eliminarRegistro($datoBuscar);
    }
}
