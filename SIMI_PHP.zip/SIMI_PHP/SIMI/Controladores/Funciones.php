<?php // Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones
   
require_once 'AccesoDatosFactory.php';
require_once 'Controlador_Equipo.php';
require_once 'Controlador_ListaValores.php';
require_once 'Controlador_Mantenimiento.php';
require_once 'Controlador_Operario.php';


class Funciones
{   
   
    public static function obtenerUsuario()
    { // Obtener usuario Conectado de la sesion
        try
        {
            session_start();
            if(!empty($_SESSION['UsuarioConectado']))
            {
              $user = $_SESSION['UsuarioConectado'];
              return $user;
            } 
            else
            {
              header("Location: ../Vistas/index.php");                 
            }
        }
        catch (Exception $ex)
        {
          echo $ex;
        }
    }
     
   public static function validar_PrimeraPosicion($cadena)
   {
        $respuesta = FALSE;   
        if(substr($cadena,0,1) == 0)
        {
           $respuesta = TRUE;
        }     
        return $respuesta;
   }
   
    public static function validar_CampoRequerido($cadena)
    {     
        $respuesta = FALSE;  
        $cadena = trim($cadena); // Eliminar espacios 
        $cadena = stripslashes($cadena); // Elimina backslashes \
        //$cadena = htmlspecialchars($cadena); // Traduce caracteres especiales en entidades HTML

        if(empty($cadena))
        {
           $respuesta = TRUE;
        }
        return $respuesta;
    } 
   
    public static function validar_Correo($cadena)
    {          
        $respuesta = FALSE; 
        if(!filter_var($cadena, FILTER_VALIDATE_EMAIL))  
        {
           $respuesta = TRUE;
        }
        return $respuesta;
    }
   
    public static function validar_SoloNumeros($cadena)
    {
        $respuesta = FALSE;  
        if (!preg_match("/^[0-9]+$/", $cadena))
        {
           $respuesta = TRUE;
        }
        return $respuesta;
    }
   
    public static function validar_Longitud($cadena, $tipo, $valor1, $valor2)
    {
        $respuesta = FALSE;  
        if ($tipo == 'Menor')
        {
            if (strlen($cadena) < $valor1) 
            {
                $respuesta = TRUE;
            }
        }
        elseif ($tipo == 'Mayor') 
        {
            if (strlen($cadena) > $valor1) 
            {
                $respuesta = TRUE;
            }
        }
        else
        {            
            if ((strlen($cadena) != $valor1) && (strlen($cadena) != $valor2))
            {
                $respuesta = TRUE;
            }
        }     
        return $respuesta;
    }  
  
    public static function crearControlador_Operario()
    {
        $dao_operario = new Dao_Operario();
        $dao_operario = AccesoDatosFactory::obtenerDao_Operario($dao_operario);       
        return new Controlador_Operario($dao_operario);
    }
   
    public static function crearControlador_Equipo()
    {
        $dao_equipo = new Dao_Equipo();
        $dao_equipo = AccesoDatosFactory::obtenerDao_Equipo($dao_equipo);       
        return new Controlador_Equipo($dao_equipo);
    }
   
    public static function crearControlador_ListaValores()
    {
        $dao_listavalores = new Dao_ListaValores();
        $dao_listavalores = AccesoDatosFactory::obtenerDao_ListaValores($dao_listavalores);       
        return new Controlador_ListaValores($dao_listavalores);
    }
   
    public static function crearControlador_Mantenimiento()
    {
        $dao_mantenimiento = new Dao_Mantenimiento();
        $dao_mantenimiento = AccesoDatosFactory::obtenerDao_Mantenimiento($dao_mantenimiento);       
        return new Controlador_Mantenimiento($dao_mantenimiento);
    }   
}


