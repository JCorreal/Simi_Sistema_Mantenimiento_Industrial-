<?php /* Estas líneas son las encargadas de llamar el archivo de ayudas chm o PDF

         Adecuar la ruta de acuerdo al PC y SO
         Si se desea abrir ayuda en formato CHM en Linux. 
         hay que descargar algun programa como: ChmSee 

         Estas dos linas solo funcionan en Win
         $proces = shell_exec('../resources/Ayudas/Ayuda.chm');
         shell_exec('kill '.$proces);

         Para Linux voy a abrir la ayuda en formato PDF */

        $file = '../resources/Ayudas/Ayuda.pdf';
        $filename = 'filename.pdf';
        // Header content type
        header('Content-type: application/pdf');
        header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Transfer-Encoding: binary');
        header('Accept-Ranges: bytes');
        // Read the file
        @readfile($file);
        header("Location: ../Vistas/WebPage_Menu.php");      

    