<?php // Este es el Controlador para el registro de Equipos            
    
require_once '../Modelos/Equipo.php';
require_once '../DAL/Dao_Equipo.php';

class Controlador_Equipo {
   
    protected $idao_equipo;
        
    public function __construct(IDao_Equipo $idao_equipo)
    {
        $this->idao_equipo = new Dao_Equipo();
    }
        
    public function obtenerEquipo($datoBuscar)
    {
       return $this->idao_equipo->obtenerEquipo($datoBuscar);
    }
    
    public function guardarEquipo ($object)
    {
      $usuario = Funciones::obtenerUsuario();   
      return $this->idao_equipo->guardarEquipo($object, $usuario);
    }
    
    public function controlarProgramacion(){      
      return $this->idao_equipo->controlarProgramacion();
    }
    
    public function cargarListado($opcion) {
       return $this->idao_equipo->cargarListado($opcion);
    }
    
    public function eliminarRegistro($datoBuscar){        
        return $this->idao_equipo->eliminarRegistro($datoBuscar);
    }

}
