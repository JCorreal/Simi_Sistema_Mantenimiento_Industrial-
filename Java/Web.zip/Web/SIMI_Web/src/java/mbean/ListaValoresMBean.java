package mbean; // Managed Bean que responde a las acciones del form Lista Valores

import bll.Controlador_ListaValores;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.ListaValores;

public class ListaValoresMBean {
    
    private ListaValores listavalores = new ListaValores();
    private String titulo;
    private final Controlador_ListaValores _controlador = Funciones.CrearControlador_ListaValores();
  
    public ListaValoresMBean()
    {      
        titulo = Funciones.Pagina;      
        if (Funciones.ParametroBuscar == 0)
        { 
            this.listavalores = new ListaValores ();   
            listavalores.setTipo(Funciones.Pagina);
        }  
        else
        {
            ListaValores tmp_listavalores = (ListaValores) _controlador.obtenerListaValores(Funciones.ParametroBuscar);
            if (tmp_listavalores != null)
            {          
                this.listavalores = tmp_listavalores ;              
            }
        }      
    }
  
    public ListaValores getListavalores() {
        return listavalores;
    }

    public void setListavalores(ListaValores listavalores) {
        this.listavalores = listavalores;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }    
    
    public String guardar()
    {
        int resultado;   
        resultado = _controlador.guardarListaValores(listavalores);
        if (resultado == 0)  
        {    
           this.listavalores = null;
           Funciones.ParametroBuscar = 0;
           return "si";
        }
        else if (resultado == 1)
        {
            Error.ElMensaje = Mensajes.Mensaje8;              
            return "no";
        }
        else
        {
            Error.ElMensaje = Mensajes.MensajeErrorBD; 
            return "no";
        }      
    }
}
         
       
             


