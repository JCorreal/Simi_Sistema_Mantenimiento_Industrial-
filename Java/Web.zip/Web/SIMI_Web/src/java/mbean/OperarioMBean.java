package mbean; // Managed Bean que responde a las acciones del form Operarios

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.Operario;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;

public class OperarioMBean  {
    
    private final Controlador_Operario _controlador = Funciones.CrearControlador_Operario();
    private Operario operario = new Operario();  
    private String fotoBD = null;
    private boolean activarCampo = false;  
          
    public OperarioMBean()
    {
        if (Funciones.ParametroBuscar == 0)
        {         
           this.operario = new Operario ();     
        }  
        else
        {        
            Operario tmp_operario = (Operario) _controlador.obtenerOperario(Funciones.ParametroBuscar);
            if (tmp_operario != null)
            {
                this.activarCampo = true;            
                this.operario = tmp_operario ; 
                if (tmp_operario.getFoto()!= null && !"".equals(tmp_operario.getFoto())) 
                {
                   fotoBD = tmp_operario.getFoto();
                }           
            }
        }      
    }
   
    public Operario getOperario() {
        return operario;
    }

    public void setOperario(Operario operario) {
        this.operario = operario;
    }

    public boolean isActivarCampo() {
        return activarCampo;
    }

    public void setActivarCampo(boolean activarCampo) {
        this.activarCampo = activarCampo;
    }
        
    public boolean verificar()
    {
       boolean Grabar = true;          
       if (!"".equals(operario.getCorreo()))
       {
            if (Funciones.validar_Correo(operario.getCorreo()))
            {
                Grabar = false;               
                Error.ElMensaje = Mensajes.Mensaje16;
            }    
       }
       return Grabar; 
    }
    
    public String guardar() 
    {      
        int resultado;  
        if (verificar())
        {
            if (!"".equals(operario.getFoto()) && (operario.getFoto() != null))
            {
                if (!operario.getFoto().equals(fotoBD))
                {
                  cargarFoto();         
                }
            }  
            else
            {
              operario.setFoto(null);  
            }
            resultado = _controlador.guardarOperario(operario);
            if(resultado == 0)    
            {
               this.operario = null;      
               Funciones.ParametroBuscar = 0;
               return "si";
            }
            else if (resultado == 1)
            {
                Error.ElMensaje = Mensajes.Mensaje26;   
                return "no"; 
            }
            else
            {
                Error.ElMensaje = Mensajes.MensajeErrorBD;   
                return "no";
            }
        } 
        else
        {
            return "no";
        }
    }

   public void cargarFoto()
   {   
       File fIn  = new File(this.operario.getFoto());
       File fOut = new File("E:/Fuentes CM/ControlMantenimiento-JavaWeb/web/Imagenes/" + operario.getDocumento() + ".jpg" );
       copyFile(fIn, fOut);     
       this.operario.setFoto("Imagenes/" + operario.getDocumento() + ".jpg");
    }                                              

    public void copyFile(File s, File t)
    {
        try
        {
            FileChannel in = (new FileInputStream(s)).getChannel();
            FileChannel out = (new FileOutputStream(t)).getChannel();
            in.transferTo(0, s.length(), out);
            out.close();
        }
        catch (Exception ex) 
        {
            System.out.println(ex);
        }
    }      

}
