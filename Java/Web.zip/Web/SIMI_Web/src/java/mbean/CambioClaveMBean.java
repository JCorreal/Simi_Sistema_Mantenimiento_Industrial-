package mbean; // Managed Bean que responde a las acciones del form Cambio Clave

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;

public class CambioClaveMBean {

    private int claveActual;
    private int claveNueva;
    private int confirmar;   
   
    public CambioClaveMBean(){}

    public int getClaveActual() 
    {
        return claveActual;
    }

    public void setClaveActual(int claveActual) 
    {
        this.claveActual = claveActual;
    }

    public int getClaveNueva()
    {
        return claveNueva;
    }

    public void setClaveNueva(int claveNueva) 
    {
        this.claveNueva = claveNueva;
    }

    public int getConfirmar()
    {
        return confirmar;
    }

    public void setConfirmar(int confirmar)
    {
        this.confirmar = confirmar;
    }
    
    public String grabar()
    {
        int resultado; 
        Controlador_Operario _controlador = Funciones.CrearControlador_Operario();  
        resultado = _controlador.guardarCambioClave(Funciones.UsuarioConectado, claveActual, claveNueva);      
        if (resultado == 0) 
        {
            return "si";
        }
        else
        {
           Error.ElMensaje = Mensajes.MensajeErrorBD; 
           return "no";
        }
    }
    
}    


