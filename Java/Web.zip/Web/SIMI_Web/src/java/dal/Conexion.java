package dal; // Clase que nos devuelve la conexion con el proveedor que se desee, por
          
import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion
{
    
    public static synchronized Connection obtenerConexion()
    {
        Connection cn = null;
        try 
        {   
           Class.forName("oracle.jdbc.OracleDriver");          
           cn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SIMIDB","tiger");
        }
        catch (Exception ex) 
        {
            cn = null;
            System.out.println("Error : " +ex);     
        }
        return cn;
    }
}
