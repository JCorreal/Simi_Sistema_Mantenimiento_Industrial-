package bll; // Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones
   
import dal.Dao_Operario;
import dal.Dao_ListaValores;
import dal.Dao_Equipo;
import dal.Dao_Mantenimiento;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;

public class Funciones {
    
    public static String Fuente;
    public static String ValorTipo;    
    public static int ParametroBuscar;
    public static String NombreUsuario;  
    public static int PerfilAcceso;
    public static int UsuarioConectado;    
    private static Dao_Operario dao_operario;
    private static Dao_Equipo dao_equipo;
    private static Dao_Mantenimiento dao_mantenimiento;
    private static Dao_ListaValores dao_listavalores;
            
    public static Controlador_Equipo crearControlador_Equipo()
    {
        dao_equipo = (Dao_Equipo) AccesoDatosFactory.obtenerDao_Equipo();
        return new Controlador_Equipo(dao_equipo);        
    }
    
    public static Controlador_Mantenimiento crearControlador_Mantenimiento()
    {
        dao_mantenimiento = (Dao_Mantenimiento) AccesoDatosFactory.obtenerDao_Mantenimiento();
        return new Controlador_Mantenimiento(dao_mantenimiento);        
    }
    
    
    public static Controlador_Operario crearControlador_Operario()
    {
        dao_operario = (Dao_Operario) AccesoDatosFactory.obtenerDao_Operario();
        return new Controlador_Operario(dao_operario);        
    }
    
    public static Controlador_ListaValores crearControlador_ListaValores()
    {
        dao_listavalores = (Dao_ListaValores) AccesoDatosFactory.obtenerDao_ListaValores();
        return new Controlador_ListaValores(dao_listavalores);        
    }
    
    // Funcion para validar campos de formulario vacios 
    public static boolean validar_CampoVacio(String cadena)
    {
       boolean vacio = false;    
       cadena = cadena.trim(); 
       if (cadena.equals(""))  // Validar Campo en blanco
       {
           vacio = true;
       }
       return vacio;
    }
         
    // Funcion para comprobar existencia de caracteres no numericos
    public static void validar_SoloNumeros(java.awt.event.KeyEvent evt) 
    {
        char a = evt.getKeyChar();  
	if (a == 8)    
        {
	    return;    
        }
        if(!(a >= KeyEvent.VK_0 && a <= KeyEvent.VK_9 )) 
        {
            evt.consume();
        }
    }
         
    // Funcion para comprobar existencia de caracteres diferentes de letras
    public static void validar_SoloLetras(KeyEvent e)
    {    
       Character caracter = new Character(e.getKeyChar()); 
       char ct = caracter.charValue(); 
	   if (!(Character.isLetter(ct) //si es letra 	 
               || ct == ' ' //o un espacio 
	       || ct == 8   //o backspace
	   )) 
	   e.consume();
    }
    
    // Anular el pegado con teclas Control V   
    public static void anularPegado(java.awt.event.KeyEvent evt)
    {
        char e = evt.getKeyChar();
        if  (evt.getKeyCode() == 86 || e == KeyEvent.VK_CONTROL)         
        {
            evt.consume();
        }
    }
    
    // Funcion para validar direcciones de correo electronico
    public static boolean validar_Correo(String cadena)
    {
        cadena = cadena.trim(); 
        return  (!cadena.matches("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*"));
    }
    
    // Funcion para eliminar posibles espacios de tabulacion en un campo de texto
    public static String eliminarTabulador(String cadena, String conversion)
    {
        cadena = cadena.trim();
        while (cadena.indexOf("  ", 0) != -1)
        {
           cadena = (cadena.replace("  ", " "));
        }
        if (conversion.equals("MAY"))
        {
           cadena = cadena.toUpperCase();
        }
        if (conversion.equals("1MAY")) // Organizar primera letra en Mayuscula y siguientes en Minuscula
        {
           cadena = cadena.toLowerCase();           
           char[] caracteres = cadena.toCharArray();
           caracteres[0] = Character.toUpperCase(caracteres[0]);
           int tamano = cadena.length();
           for (int i = 0; i < (tamano - 2); i++) 
           {
                if (caracteres[i] == ' ' || caracteres[i] == '.' || caracteres[i] == ',')
                {
                  caracteres[i + 1] = Character.toUpperCase(caracteres[i + 1]);               
                }
           }
           cadena = new String(caracteres);
        }
       return cadena;
    }
    
    public static void limpiar(Component component) 
    {
        if (component instanceof JTextField)
        {
            JTextField text = (JTextField) component;
            text.setText("");
        }
        else
        {
            if (component instanceof Container) 
            {
                for (Component c : ((Container) component).getComponents())
                {
                    limpiar(c);
                }
            } 
        }
    }           
                
}
