package bo; // Clase que representa la estructura en BD ListaValores, donde almacenaremos Lineas y Marcas
      
public class ListaValores {
  
    private int listavalores_id  = 0;
    private String nombre        = null;  
    private String descripcion   = null;
    private String tipo          = null;

    public ListaValores() {}

    public int getListavalores_id() {
        return listavalores_id;
    }

    public void setListavalores_id(int listavalores_id) {
        this.listavalores_id = listavalores_id;
    }
        
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
