package dal; // Interface que expone los métodos que implementa el DAO de Operarios

import bo.Operario;
import java.util.List;

public interface IDao_Operario {
    
  public List cargarOperarios();   
  public Operario obtenerAcceso (String datoBuscar, int clave);
  public Operario obtenerOperario (int datoBuscar);
  public int guardarOperario(Operario operario, int Usuario);
  public int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva);
  public int eliminarRegistro(int datoEliminar);       

}
