package SIMI_Desktop;

import bll.Controlador_Equipo;
import bll.Funciones;
import bll.Mensajes;
import bo.Equipo;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class JFrame_Equipos extends javax.swing.JFrame {
    private final Controlador_Equipo _controlador = Funciones.crearControlador_Equipo();
        
    javax.swing.DefaultListModel datosLista;
    boolean grabar;  
    Equipo equipo;
    int elementoActivo;
    
    public JFrame_Equipos() {
           initComponents();
           JList_Buscar.setVisible(false);
           JComboBox_CodigoMarca.setVisible(false);
           JComboBox_CodigoLinea.setVisible(false);
        
        List ListadeValores =new ArrayList();
        ListadeValores = _controlador.cargarCombosEM();    
        int tamano = ListadeValores.size();
        JList_Buscar.setModel( new javax.swing.DefaultListModel());
        datosLista = (javax.swing.DefaultListModel)JList_Buscar.getModel();        
        for(int i=0; i < tamano; i++) {
            if ("EQUIPOS".equals(ListadeValores.get(i).toString()))
            {     
              i++;
              i++;
              datosLista.addElement(ListadeValores.get(i).toString());              
            }
            else if ("LINEAS".equals(ListadeValores.get(i).toString()))
            { 
                i++;
                JComboBox_CodigoLinea.addItem(ListadeValores.get(i).toString());
                i++;       
                JComboBox_NombreLinea.addItem(ListadeValores.get(i).toString());                
            }
            else if ("MARCAS".equals(ListadeValores.get(i).toString()))
            { 
                i++;
                JComboBox_CodigoMarca.addItem(ListadeValores.get(i).toString());
                i++;       
                JComboBox_NombreMarca.addItem(ListadeValores.get(i).toString());                
            }
        }            
        if (JComboBox_CodigoMarca.getItemCount() == 0)
        {            
         JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje11, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);         
         JButton_Grabar.setEnabled(false);
        }
        else if (JComboBox_CodigoLinea.getItemCount() == 0)
        {
         JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje12, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);         
         JButton_Grabar.setEnabled(false);            
        }
        else
        {
            ListadeValores.clear();
        }      
    }
        
    private void CargarListaSeleccion()
    {     
        List listadeValores = new ArrayList();
        JList_Buscar.setModel( new javax.swing.DefaultListModel());
        datosLista = (javax.swing.DefaultListModel)JList_Buscar.getModel();
        listadeValores = _controlador.cargarListas();    
        for(int i=0; i<listadeValores.size(); i++) {
            datosLista.addElement(listadeValores.get(i).toString());
        }
        listadeValores.clear();
    }

    private void LLenarCampos()
    {
      equipo = (Equipo) _controlador.obtenerEquipo(Integer.parseInt(JLabel_Codigo.getText()));     
      if (equipo != null) 
      {  
         JTextField_Nombre.setText(equipo.getNombre_equipo().trim());
         JComboBox_CodigoMarca.setSelectedItem(equipo.getMarca());       
         JComboBox_NombreMarca.setSelectedIndex(JComboBox_CodigoMarca.getSelectedIndex()); 
         JTextField_Serie.setText(equipo.getSerie().trim());
         JComboBox_CodigoLinea.setSelectedItem(equipo.getLinea());
         JComboBox_NombreLinea.setSelectedIndex(JComboBox_CodigoLinea.getSelectedIndex());         
         JCheckBox_Lubricacion.setSelected((equipo.getLubricacion() == 1));         
         JButton_Eliminar.setEnabled(true);
     }
    }
    
    private void guardar(String Mensaje)
    {
     int Resultado;   
     equipo = new Equipo();
     equipo.setEquipo_id(Integer.parseInt(JLabel_Codigo.getText())); 
     equipo.setNombre_equipo(JTextField_Nombre.getText().trim());
     equipo.setMarca(Integer.parseInt(JComboBox_CodigoMarca.getSelectedItem().toString()));
     equipo.setSerie(JTextField_Serie.getText().trim());
     equipo.setLinea(Integer.parseInt(JComboBox_CodigoLinea.getSelectedItem().toString()));
     equipo.setLubricacion(JCheckBox_Lubricacion.isSelected() ? 1:0 );   
     
      Resultado = _controlador.guardarEquipo(equipo);
        switch (Resultado) {
            case 0:
                JOptionPane.showMessageDialog(rootPane, Mensaje, Mensajes.MensajeAplicacion, WIDTH);
                CargarListaSeleccion();
                Limpiar();
                break;
            case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje7, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextField_Serie.requestFocus();
                break;
            default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
        }      
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        JButton_Salir = new javax.swing.JButton();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Eliminar = new javax.swing.JButton();
        JButton_Ayuda = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        JList_Buscar = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        JLabel_Codigo = new javax.swing.JLabel();
        JButton_Buscar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        JTextField_Nombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        JComboBox_NombreMarca = new javax.swing.JComboBox();
        JComboBox_CodigoMarca = new javax.swing.JComboBox();
        JTextField_Serie = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JComboBox_NombreLinea = new javax.swing.JComboBox();
        JComboBox_CodigoLinea = new javax.swing.JComboBox();
        JCheckBox_Lubricacion = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SAVE.jpg"))); // NOI18N
        JButton_Grabar.setText("Grabar");
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });

        JButton_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Borrar.jpg"))); // NOI18N
        JButton_Eliminar.setText("Eliminar");
        JButton_Eliminar.setEnabled(false);
        JButton_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EliminarActionPerformed(evt);
            }
        });

        JButton_Ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HELP.jpg"))); // NOI18N
        JButton_Ayuda.setText("Ayuda");
        JButton_Ayuda.setToolTipText("");
        JButton_Ayuda.setPreferredSize(new java.awt.Dimension(85, 23));
        JButton_Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AyudaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JButton_Grabar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JButton_Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Ayuda, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Salir, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {JButton_Cancelar, JButton_Eliminar, JButton_Grabar, JButton_Salir});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JButton_Salir)
                    .addComponent(JButton_Cancelar)
                    .addComponent(JButton_Grabar)
                    .addComponent(JButton_Eliminar)
                    .addComponent(JButton_Ayuda, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {JButton_Cancelar, JButton_Eliminar, JButton_Grabar, JButton_Salir});

        JList_Buscar.setBackground(new java.awt.Color(240, 240, 240));
        JList_Buscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JList_BuscarMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(JList_Buscar);

        jLabel1.setText("Codigo");

        JLabel_Codigo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        JLabel_Codigo.setText("0");

        JButton_Buscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        JButton_Buscar.setText("...");
        JButton_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_BuscarActionPerformed(evt);
            }
        });

        jLabel2.setText("Nombre");

        JTextField_Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_NombreActionPerformed(evt);
            }
        });

        jLabel3.setText("Marca");

        JComboBox_NombreMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreMarcaActionPerformed(evt);
            }
        });

        JTextField_Serie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_SerieActionPerformed(evt);
            }
        });

        jLabel4.setText("Serie");

        jLabel5.setText("Linea");

        JComboBox_NombreLinea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreLineaActionPerformed(evt);
            }
        });

        JCheckBox_Lubricacion.setText("Lubricacion     ");
        JCheckBox_Lubricacion.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JCheckBox_Lubricacion, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(40, 40, 40)
                                .addComponent(JLabel_Codigo)
                                .addGap(31, 31, 31)
                                .addComponent(JButton_Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(36, 36, 36)
                                .addComponent(JTextField_Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(44, 44, 44)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(JComboBox_NombreLinea, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(JComboBox_CodigoLinea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(JTextField_Serie, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(JComboBox_NombreMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(30, 30, 30)
                                        .addComponent(JComboBox_CodigoMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(87, 87, 87))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JButton_Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(JLabel_Codigo))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(JTextField_Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(JComboBox_NombreMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JComboBox_CodigoMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JTextField_Serie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JComboBox_NombreLinea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(JComboBox_CodigoLinea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JCheckBox_Lubricacion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(658, 410));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        JTextField_NombreActionPerformed(evt);
        if (grabar)
        {
            JTextField_SerieActionPerformed(evt);
            if (grabar)
            {
              guardar(("0".equals(JLabel_Codigo.getText())) ? Mensajes.MensajeGraba : Mensajes.MensajeActualiza);             
            }
        }
    }//GEN-LAST:event_JButton_GrabarActionPerformed

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
        Limpiar(); // Limpiar Formulario
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EliminarActionPerformed
            if (JOptionPane.showConfirmDialog(rootPane, Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, JOptionPane.YES_NO_OPTION )==0)
            {  
               if (_controlador.eliminarRegistro(Integer.parseInt(JLabel_Codigo.getText()))==0)
               {
                   JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, WIDTH);
                   datosLista.remove(elementoActivo);
                   Limpiar();
                }                
                else
                {
                     JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                }           
            }        
    }//GEN-LAST:event_JButton_EliminarActionPerformed

    private void JList_BuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JList_BuscarMouseClicked
        if (!datosLista.isEmpty()) // Si hay datos para mostrar
        {
            Limpiar();
            String cadena = JList_Buscar.getSelectedValue().toString();
            elementoActivo = JList_Buscar.getSelectedIndex();
            String resultado = "";
            int Posicion = cadena.indexOf( ' ' );
            for ( int i = 0; i < Posicion; i++ ) {
                resultado= resultado + cadena.charAt(i);                
            }            
            JLabel_Codigo.setText(resultado.trim());
            JList_Buscar.setVisible(false);
            LLenarCampos();
        }
    }//GEN-LAST:event_JList_BuscarMouseClicked

    private void JButton_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_BuscarActionPerformed
        if (!datosLista.isEmpty()) // Si hay datos para mostrar
        {
            JList_Buscar.setVisible(true);
        }
    }//GEN-LAST:event_JButton_BuscarActionPerformed

    private void JTextField_NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_NombreActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Nombre.getText()))    // Validar Campo en blanco
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Nombre.requestFocus();
        }
        else
        {
            JTextField_Nombre.setText(Funciones.eliminarTabulador(JTextField_Nombre.getText(), "1MAY"));
            if (JTextField_Nombre.getText().length() > 50)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextField_Nombre.requestFocus();
            }
            else
            {
                JComboBox_NombreMarca.requestFocus();
            }
        }
    }//GEN-LAST:event_JTextField_NombreActionPerformed

    private void JComboBox_NombreMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreMarcaActionPerformed
        JComboBox_CodigoMarca.setSelectedIndex(JComboBox_NombreMarca.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreMarcaActionPerformed

    private void JTextField_SerieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_SerieActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Serie.getText()))    // Validar Campo en blanco
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Serie.requestFocus();
        }
        else
        {
            JTextField_Serie.setText(Funciones.eliminarTabulador(JTextField_Serie.getText(), "MAY"));
            if (JTextField_Serie.getText().length()>20)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextField_Serie.requestFocus();
            }
            else
            {
                JComboBox_NombreLinea.requestFocus();
            }            
        }
    }//GEN-LAST:event_JTextField_SerieActionPerformed

    private void JComboBox_NombreLineaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreLineaActionPerformed
        JComboBox_CodigoLinea.setSelectedIndex(JComboBox_NombreLinea.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreLineaActionPerformed

    private void JButton_AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AyudaActionPerformed
        try {
            /* Runtime run = Runtime.getRuntime();
             run.exec("hh.exe E:/Fuentes CM/ControlMantenimiento-JavaDesktop/ControlMantenimiento-JavaDesktop/Ayudas/Ayuda.chm");
             run.freeMemory();*/
             
            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje29, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_JButton_AyudaActionPerformed

    private void Limpiar()
    {
      Funciones.limpiar(rootPane);
      JList_Buscar.setVisible(false);
      JLabel_Codigo.setText("0");
      JCheckBox_Lubricacion.setSelected(false);
      JButton_Eliminar.setEnabled(false);
      JTextField_Nombre.requestFocus();
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Ayuda;
    private javax.swing.JButton JButton_Buscar;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Eliminar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private javax.swing.JCheckBox JCheckBox_Lubricacion;
    private javax.swing.JComboBox JComboBox_CodigoLinea;
    private javax.swing.JComboBox JComboBox_CodigoMarca;
    private javax.swing.JComboBox JComboBox_NombreLinea;
    private javax.swing.JComboBox JComboBox_NombreMarca;
    private javax.swing.JLabel JLabel_Codigo;
    private javax.swing.JList JList_Buscar;
    private javax.swing.JTextField JTextField_Nombre;
    private javax.swing.JTextField JTextField_Serie;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
