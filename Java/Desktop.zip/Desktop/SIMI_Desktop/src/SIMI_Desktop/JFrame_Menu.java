package SIMI_Desktop;

import bll.Controlador_Mantenimiento;
import bll.Funciones;
import bll.Mensajes;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class JFrame_Menu extends javax.swing.JFrame {

    public JFrame_Menu() {
        initComponents();
        if (Funciones.PerfilAcceso==1)
        {
           jMenuAdmin.setEnabled(true);
           JButton_Equipos.setEnabled(true);
           JButton_Mantenimiento.setEnabled(true);
           JButton_ModificarM.setEnabled(true);
           JButton_Marcas.setEnabled(true);
           JButton_Lineas.setEnabled(true);           
        }
      JLabel_UsuarioConectado.setText("Bienvenido: " +" "+ Funciones.NombreUsuario);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlblFoto = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        JLabel_UsuarioConectado = new javax.swing.JLabel();
        JButton_Operarios = new javax.swing.JButton();
        JButton_Equipos = new javax.swing.JButton();
        JButton_Mantenimiento = new javax.swing.JButton();
        JButton_ModificarM = new javax.swing.JButton();
        JButton_Marcas = new javax.swing.JButton();
        JButton_Lineas = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItemOperarios = new javax.swing.JMenuItem();
        jMenuItemCambioClave = new javax.swing.JMenuItem();
        jMenuItemSalir = new javax.swing.JMenuItem();
        jMenuAdmin = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuItemIngresarM = new javax.swing.JMenuItem();
        jMenuItemModificarM = new javax.swing.JMenuItem();
        jMenuItemEquipos = new javax.swing.JMenuItem();
        jMenuItemLineas = new javax.swing.JMenuItem();
        jMenuItemMarcas = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlblFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SIMI-LOGO.jpg"))); // NOI18N
        jlblFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        JLabel_UsuarioConectado.setText("Bienvenido: ");
        JLabel_UsuarioConectado.setToolTipText("");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JLabel_UsuarioConectado)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(JLabel_UsuarioConectado)
                .addGap(0, 51, Short.MAX_VALUE))
        );

        JButton_Operarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Operarios.jpg"))); // NOI18N
        JButton_Operarios.setToolTipText("Operarios");
        JButton_Operarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_OperariosActionPerformed(evt);
            }
        });

        JButton_Equipos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/equipos.jpg"))); // NOI18N
        JButton_Equipos.setToolTipText("Equipos");
        JButton_Equipos.setEnabled(false);
        JButton_Equipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EquiposActionPerformed(evt);
            }
        });

        JButton_Mantenimiento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tiempo.jpg"))); // NOI18N
        JButton_Mantenimiento.setToolTipText("Programar Mtto.");
        JButton_Mantenimiento.setEnabled(false);
        JButton_Mantenimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_MantenimientoActionPerformed(evt);
            }
        });

        JButton_ModificarM.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/MMto.jpg"))); // NOI18N
        JButton_ModificarM.setToolTipText("Modificar Mtto.");
        JButton_ModificarM.setEnabled(false);
        JButton_ModificarM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_ModificarMActionPerformed(evt);
            }
        });

        JButton_Marcas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/marcas.jpg"))); // NOI18N
        JButton_Marcas.setToolTipText("Marcas");
        JButton_Marcas.setEnabled(false);
        JButton_Marcas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_MarcasActionPerformed(evt);
            }
        });

        JButton_Lineas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Listas.jpg"))); // NOI18N
        JButton_Lineas.setToolTipText("Lineas");
        JButton_Lineas.setEnabled(false);
        JButton_Lineas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_LineasActionPerformed(evt);
            }
        });

        jMenu1.setText("Menu");

        jMenuItemOperarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icoperarios.jpg"))); // NOI18N
        jMenuItemOperarios.setText("Operarios");
        jMenuItemOperarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemOperariosActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItemOperarios);

        jMenuItemCambioClave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icoclave.jpg"))); // NOI18N
        jMenuItemCambioClave.setText("Cambio Clave");
        jMenuItemCambioClave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCambioClaveActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItemCambioClave);

        jMenuItemSalir.setText("Salir");
        jMenuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSalirActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItemSalir);

        jMenuBar1.add(jMenu1);

        jMenuAdmin.setText("Administracion");
        jMenuAdmin.setEnabled(false);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icotiempo.jpg"))); // NOI18N
        jMenu3.setText("Mantenimiento");

        jMenuItemIngresarM.setText("Programar Mantenimiento");
        jMenuItemIngresarM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemIngresarMActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItemIngresarM);

        jMenuItemModificarM.setText("Modificar Programacion");
        jMenuItemModificarM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemModificarMActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItemModificarM);

        jMenuAdmin.add(jMenu3);

        jMenuItemEquipos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icoequipos.jpg"))); // NOI18N
        jMenuItemEquipos.setText("Equipos");
        jMenuItemEquipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemEquiposActionPerformed(evt);
            }
        });
        jMenuAdmin.add(jMenuItemEquipos);

        jMenuItemLineas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icolineas.jpg"))); // NOI18N
        jMenuItemLineas.setText("Lineas");
        jMenuItemLineas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineasActionPerformed(evt);
            }
        });
        jMenuAdmin.add(jMenuItemLineas);

        jMenuItemMarcas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/icomarca.jpg"))); // NOI18N
        jMenuItemMarcas.setText("Marcas");
        jMenuItemMarcas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemMarcasActionPerformed(evt);
            }
        });
        jMenuAdmin.add(jMenuItemMarcas);

        jMenuBar1.add(jMenuAdmin);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(JButton_Operarios, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(JButton_Equipos, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(JButton_Mantenimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(JButton_ModificarM, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(JButton_Marcas, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(JButton_Lineas, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jlblFoto)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(JButton_Marcas, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(JButton_ModificarM, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(JButton_Mantenimiento, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(JButton_Equipos, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                .addComponent(JButton_Operarios, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(JButton_Lineas, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        setSize(new java.awt.Dimension(792, 554));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItemOperariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemOperariosActionPerformed
     JFrame_Operarios oforma = new JFrame_Operarios();     
     oforma.setVisible(true);  
    }//GEN-LAST:event_jMenuItemOperariosActionPerformed

    private void jMenuItemLineasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineasActionPerformed
      Funciones.ValorTipo = "LINEAS";
      JFrame_ListaValores oforma  = new JFrame_ListaValores();
      oforma.setTitle(Funciones.ValorTipo); 
      oforma.setVisible(true);
    }//GEN-LAST:event_jMenuItemLineasActionPerformed

    private void jMenuItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSalirActionPerformed
      System.exit(0);
    }//GEN-LAST:event_jMenuItemSalirActionPerformed

    private void jMenuItemMarcasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemMarcasActionPerformed
      Funciones.ValorTipo = "MARCAS";
      JFrame_ListaValores oforma  = new JFrame_ListaValores();
      oforma.setTitle(Funciones.ValorTipo);
      oforma.setVisible(true);
    }//GEN-LAST:event_jMenuItemMarcasActionPerformed

    private void jMenuItemEquiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemEquiposActionPerformed
        JFrame_Equipos oforma  = new JFrame_Equipos();      
        oforma.setVisible(true);     
    }//GEN-LAST:event_jMenuItemEquiposActionPerformed

    private void jMenuItemCambioClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCambioClaveActionPerformed
      JFrame_CambioClave oforma  = new JFrame_CambioClave();      
      oforma.setVisible(true); 
    }//GEN-LAST:event_jMenuItemCambioClaveActionPerformed

    private void jMenuItemIngresarMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemIngresarMActionPerformed
        Funciones.Fuente = "PROGRAMAR";
        VerificarExistencia();
    }//GEN-LAST:event_jMenuItemIngresarMActionPerformed
   
    private void jMenuItemModificarMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemModificarMActionPerformed
        Funciones.Fuente = "PROGRAMACION";
        VerificarExistencia();
    }//GEN-LAST:event_jMenuItemModificarMActionPerformed

    private void JButton_OperariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_OperariosActionPerformed
       jMenuItemOperariosActionPerformed(evt);
    }//GEN-LAST:event_JButton_OperariosActionPerformed

    private void JButton_MantenimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_MantenimientoActionPerformed
       jMenuItemIngresarMActionPerformed(evt);
    }//GEN-LAST:event_JButton_MantenimientoActionPerformed

    private void JButton_EquiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EquiposActionPerformed
        jMenuItemEquiposActionPerformed(evt);
    }//GEN-LAST:event_JButton_EquiposActionPerformed

    private void JButton_MarcasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_MarcasActionPerformed
      jMenuItemMarcasActionPerformed(evt);
    }//GEN-LAST:event_JButton_MarcasActionPerformed

    private void JButton_LineasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_LineasActionPerformed
       jMenuItemLineasActionPerformed(evt);
    }//GEN-LAST:event_JButton_LineasActionPerformed

    private void JButton_ModificarMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_ModificarMActionPerformed
       jMenuItemModificarMActionPerformed(evt);
    }//GEN-LAST:event_JButton_ModificarMActionPerformed

    private void VerificarExistencia()
    {
        List ListadeValores =new ArrayList();
        Controlador_Mantenimiento _controlador = Funciones.crearControlador_Mantenimiento();
        ListadeValores = _controlador.cargarCombosEM(Funciones.Fuente);        
        boolean ExitenOperarios = false;
        boolean ExitenEquipos = false;
        for(int i=0; i< ListadeValores.size(); i++)
        {           
            if (ListadeValores.get(i).toString().equals("OPERARIOS"))
            {
                ExitenOperarios = true;
                break;        
            }            
        }    
        for(int j=0; j< ListadeValores.size(); j++)
        {           
            if (ListadeValores.get(j).toString().equals("EQUIPOS"))
            {
                ExitenEquipos = true;
                break;        
            }            
        }
        if (ExitenOperarios == false)
        {
           JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje13, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);               ;
        }
        else if (ExitenEquipos == false)
        {
           JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje14, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);               ;
        }
        else
        {
          JFrame_Mantenimiento oforma  = new JFrame_Mantenimiento();            
          oforma.setVisible(true);     
        }
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Equipos;
    private javax.swing.JButton JButton_Lineas;
    private javax.swing.JButton JButton_Mantenimiento;
    private javax.swing.JButton JButton_Marcas;
    private javax.swing.JButton JButton_ModificarM;
    private javax.swing.JButton JButton_Operarios;
    private javax.swing.JLabel JLabel_UsuarioConectado;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenuAdmin;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemCambioClave;
    private javax.swing.JMenuItem jMenuItemEquipos;
    private javax.swing.JMenuItem jMenuItemIngresarM;
    private javax.swing.JMenuItem jMenuItemLineas;
    private javax.swing.JMenuItem jMenuItemMarcas;
    private javax.swing.JMenuItem jMenuItemModificarM;
    private javax.swing.JMenuItem jMenuItemOperarios;
    private javax.swing.JMenuItem jMenuItemSalir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jlblFoto;
    // End of variables declaration//GEN-END:variables
}
