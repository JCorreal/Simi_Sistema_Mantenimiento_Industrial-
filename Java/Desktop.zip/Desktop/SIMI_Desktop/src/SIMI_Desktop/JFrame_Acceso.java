package SIMI_Desktop;

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bo.Operario;
import javax.swing.JOptionPane;

public class JFrame_Acceso extends javax.swing.JFrame  {

    Operario operario;
    boolean  ingresar;    
    int      contadorIntentos;
    
    public JFrame_Acceso() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        JTextField_Documento = new javax.swing.JTextField();
        JPasswordField_Clave = new javax.swing.JPasswordField();
        jPanel2 = new javax.swing.JPanel();
        JButton_Aceptar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Acceso SIMI");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setText("Clave");

        jLabel1.setText("Documento");

        JTextField_Documento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_DocumentoActionPerformed(evt);
            }
        });
        JTextField_Documento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JTextField_DocumentoAnularPegado(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTextField_DocumentoValidar_SoloNumeros(evt);
            }
        });

        JPasswordField_Clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ClaveActionPerformed(evt);
            }
        });
        JPasswordField_Clave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyTyped(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        JButton_Aceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SECUR05.jpg"))); // NOI18N
        JButton_Aceptar.setText("Aceptar");
        JButton_Aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AceptarActionPerformed(evt);
            }
        });

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(JButton_Aceptar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Cancelar)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {JButton_Aceptar, JButton_Cancelar});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JButton_Aceptar)
                    .addComponent(JButton_Cancelar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {JButton_Aceptar, JButton_Cancelar});

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JTextField_Documento, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JPasswordField_Clave, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JTextField_Documento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(JPasswordField_Clave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(373, 260));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
          
    
    private void JTextField_DocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_DocumentoActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Documento.getText())) // Validar Campo en blanco
        {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Documento.requestFocus();
        } else if (JTextField_Documento.getText().length()<6 || JTextField_Documento.getText().length()>10) {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje15, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Documento.requestFocus();
        } else {            
            JPasswordField_Clave.requestFocus();
        }
    }//GEN-LAST:event_JTextField_DocumentoActionPerformed

    private void JPasswordField_ClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_Clave.getPassword())))
        {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else if (JPasswordField_Clave.getPassword().length != 6  ) {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else {
            JButton_Aceptar.requestFocus();
        }
    }//GEN-LAST:event_JPasswordField_ClaveActionPerformed


    private void JButton_AceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AceptarActionPerformed
        Intentos(); // Incrementar contador de intentos de acceso
        ingresar = true;
        JTextField_DocumentoActionPerformed(evt); // Revisar Documento
        if (ingresar)
        {
            JPasswordField_ClaveActionPerformed(evt); // Revisar Clave
            if (ingresar)
            {  
                Controlador_Operario _controlador = Funciones.crearControlador_Operario();
                operario = (Operario) _controlador.obtenerAcceso(JTextField_Documento.getText(),  Integer.parseInt(String.valueOf(JPasswordField_Clave.getPassword()).trim()));
                if (operario != null)
                {                    
                    Funciones.UsuarioConectado = operario.getOperario_Id();
                    Funciones.PerfilAcceso = operario.getPerfil();
                    Funciones.NombreUsuario = operario.getNombres() + ' ' + operario.getApellidos();
                    dispose(); // Descargar Formulario Acceso e invocar Menú Principal
                    JFrame_Menu oforma = new JFrame_Menu();
                    oforma.setVisible(true);
                } 
                else
                {                       
                    JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje2, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
                    JPasswordField_Clave.requestFocus();                    
                }
            }
        }
    }//GEN-LAST:event_JButton_AceptarActionPerformed

    private void Validar_SoloNumeros(java.awt.event.KeyEvent evt) {                                     
        Funciones.validar_SoloNumeros(evt);
    }    
    
    private void Intentos() {
       contadorIntentos = (contadorIntentos + 1);
       if (contadorIntentos == 3)
       {
          System.exit(0); // Usuario desconocido luego de 3 intentos, finalizar
       }
    }
    
    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
     Funciones.limpiar(rootPane);
     JTextField_Documento.requestFocus();     
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JTextField_DocumentoAnularPegado(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTextField_DocumentoAnularPegado
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JTextField_DocumentoAnularPegado

    private void JTextField_DocumentoValidar_SoloNumeros(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTextField_DocumentoValidar_SoloNumeros
        Funciones.validar_SoloNumeros(evt);
    }//GEN-LAST:event_JTextField_DocumentoValidar_SoloNumeros

    private void JPasswordField_ClaveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyTyped
        Funciones.validar_SoloNumeros(evt);
    }//GEN-LAST:event_JPasswordField_ClaveKeyTyped

    private void JPasswordField_ClaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyPressed
      Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ClaveKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Aceptar;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JPasswordField JPasswordField_Clave;
    private javax.swing.JTextField JTextField_Documento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables

    
}
