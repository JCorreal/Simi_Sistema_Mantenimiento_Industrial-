package mbean; // Managed Bean que responde a las acciones del form Listado_Operarios

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.CargarListado;
import java.util.ArrayList;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

public class ListadoOperariosMBean {
     
    private final Controlador_Operario _controlador = Funciones.CrearControlador_Operario(); 
    private ArrayList<CargarListado> listadoGeneral;
    private String datoBuscar = null;
 
    public ListadoOperariosMBean()
    {
       Error.ElMensaje = null;  
       if (Funciones.Busqueda != null)
       {
            listadoGeneral = Funciones.cargarBusqueda(Funciones.Busqueda);    
       }
       else
       {
           Funciones.arListadoGeneral = new ArrayList(); 
           Funciones.arListadoGeneral = _controlador.cargarListado();
           listadoGeneral = Funciones.arListadoGeneral; 
       }
    }

    public ArrayList<CargarListado> getListadoGeneral() {
        return listadoGeneral;
    }  

    public String getDatoBuscar() {
        return datoBuscar;
    }

    public void setDatoBuscar(String datoBuscar) {
        this.datoBuscar = datoBuscar;
    }

    public String buscarInformacion() throws Throwable
    {         
        String respuesta = null; 
        if (!"".equals(datoBuscar.trim())) 
        {    
            Funciones.Busqueda = datoBuscar;
            ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
            ec.redirect(((HttpServletRequest) ec.getRequest()).getRequestURI());
            respuesta = "Filtro";
        }    
        else
        {
          Error.ElMensaje = Mensajes.Mensaje29; 
          respuesta = "NOSELECCION";
        }
        return respuesta;
    }
   
    public String actualizar(String codigo)
    {    
        Funciones.ParametroBuscar = Integer.parseInt(codigo);
        return "OPERARIOS"; 
    }
    
    public String nuevoRegistro()
    {                
      Funciones.ParametroBuscar = 0;           
      return Funciones.Pagina;   
    }
    
   public String eliminarRegistro(String codigo)
   {    
        String respuesta = null;
        Error.ElMensaje = null;
        int resultado;                           
        resultado = _controlador.eliminarRegistro(Integer.parseInt(codigo));  
        if (resultado == 0)
        {
            Funciones.ParametroBuscar = 0;
            respuesta = "si";
        } 
        else if (resultado == 1)
        {          
             Error.ElMensaje = Mensajes.Mensaje20;    
        }              
        else
        {
            Error.ElMensaje = Mensajes.MensajeErrorBD;             
            respuesta = "no";  
        }            
        return respuesta;
   }
 
}
