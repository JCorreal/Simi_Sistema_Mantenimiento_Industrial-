package mbean; // Managed Bean que responde a las acciones del form Acceso-Login

import bll.Controlador_Operario;
import bll.Error;
import bll.Funciones;
import bll.Mensajes;
import bo.Operario;

public class AccesoMBean {
    
    private Operario operario = new Operario();
    
    public AccesoMBean()
    {
        Error.ElMensaje = "";        
    }
        
    public Operario getOperario()
    {
        return operario;
    }

    public void setOperario(Operario operario) 
    {
        this.operario = operario;
    }

    public boolean verificar()
    {
        boolean ingreso=true;         
        if (Funciones.verificar_SoloNumeros(operario.getDocumento()))
        {
           ingreso = false;                           
        }           
        return ingreso; 
    }
    
    public String ingresar()
    {            
        String respuesta = "no";  
        if (verificar())
        {
            Controlador_Operario _controlador = Funciones.CrearControlador_Operario();
            operario = (Operario) _controlador.obtenerAcceso(operario.getDocumento(), operario.getClave());
            if (operario != null) 
            {
                Funciones.UsuarioConectado = operario.getOperario_Id();
                Funciones.PerfilAcceso = operario.getPerfil();  // Obtener Perfil de Acceso              
                Funciones.NombreUsuario = operario.getNombres() + " " + operario.getApellidos();            
                operario = null;
                respuesta = "si";
            }
            else
            {
                Error.ElMensaje = Mensajes.Mensaje2;  
                respuesta = "no";
            } 
        }
        else
        {          
            Error.ElMensaje = Mensajes.Mensaje2;  
            respuesta = "no";
        }
          
         return respuesta;
       
    }
    
}
