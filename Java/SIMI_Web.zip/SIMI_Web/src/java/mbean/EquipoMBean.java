package mbean; // Managed Bean que responde a las acciones del form Equipos

import bll.Controlador_Equipo;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.Equipo;
import java.util.ArrayList;
import javax.faces.model.SelectItem;

public class EquipoMBean {
    
    private Equipo equipo = new Equipo();
    private final Controlador_Equipo _controlador = Funciones.CrearControlador_Equipo();
           
    private ArrayList<SelectItem> listaMarcas = new ArrayList<>();
    private ArrayList<SelectItem> listaLineas = new ArrayList<>();   
    private ArrayList<SelectItem> lista = new ArrayList<>();

    public ArrayList<SelectItem> getListaMarcas() 
    {
        return listaMarcas;
    }

    public void setListaMarcas(ArrayList<SelectItem> listaMarcas)
    {
        this.listaMarcas = listaMarcas;
    }

    public ArrayList<SelectItem> getListaLineas()
    {
        return listaLineas;
    }

    public void setListaLineas(ArrayList<SelectItem> listaLineas)
    {
        this.listaLineas = listaLineas;
    }
            
    public EquipoMBean()
    {        
        cargarCombos();  
        if (Funciones.ParametroBuscar == 0)
        {
           this.equipo = new Equipo ();   
        }
        else
        {
            Equipo tmp_equipo = (Equipo) _controlador.obtenerEquipo(Funciones.ParametroBuscar);
            if (tmp_equipo != null)
            {           
                this.equipo = tmp_equipo ;              
            }
        }     
    }
  
    public Equipo getEquipo() 
    {
        return equipo;
    }

    public void setEquipo(Equipo equipo) 
    {
        this.equipo = equipo;
    }      
   
    
   public void cargarCombos()
   {
        String respuesta = null;
        lista = _controlador.ControlarProgramacion();
        int tamano = lista.size();
        for(int i = 0; i < tamano; i++) 
        {        
            if ("LINEAS".equals(lista.get(i).getValue().toString()))
            {     
              i++;
              listaLineas.add(new SelectItem(lista.get(i).getValue(), lista.get(i).getLabel()));
            }
            else if ("MARCAS".equals(lista.get(i).getValue().toString()))
            {     
              i++;
              listaMarcas.add(new SelectItem(lista.get(i).getValue(),  lista.get(i).getLabel()));
            }
        }             
        if (listaMarcas == null)
        {           
            Error.ElMensaje = Mensajes.Mensaje11; 
            respuesta = "NOMARCAS";  
        }
        else if (listaLineas == null)
        {           
            Error.ElMensaje = Mensajes.Mensaje11; 
            respuesta = "NOLINEAS";  
        }
   }
    
    public String guardar()
    {     
        int resultado;   
        resultado = _controlador.guardarEquipo(equipo);
        if (resultado == 0)
        {    
           this.equipo = null;
           Funciones.ParametroBuscar = 0;
           return "si";
        }
        else if (resultado==1) 
        {
            Error.ElMensaje = Mensajes.Mensaje7;
            return "no";
        }
        else
        {
           Error.ElMensaje = Mensajes.MensajeErrorBD;   
           return "no";
        }
    } 
}
