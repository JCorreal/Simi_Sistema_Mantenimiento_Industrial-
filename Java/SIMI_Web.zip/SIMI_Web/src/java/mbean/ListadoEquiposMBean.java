package mbean; // Managed Bean que responde a las acciones del form Listado_Equipos

import bll.Controlador_Equipo;
import bll.Funciones;
import bll.Mensajes;
import bo.CargarListado;
import java.util.ArrayList;
import bll.Error;

public class ListadoEquiposMBean {
    
    private final Controlador_Equipo _controlador = Funciones.CrearControlador_Equipo(); 
    private ArrayList<CargarListado> listadoGeneral;
    private String datoBuscar = null; 

    public ListadoEquiposMBean()
    {
        Error.ElMensaje = null;  
        if (Funciones.Busqueda != null)
        {
          listadoGeneral = _controlador.CargarListado(Funciones.Busqueda);   
        }
        else
        {
            listadoGeneral = _controlador.CargarListado(null);
        }
    }
 
    public ArrayList<CargarListado> getListadoGeneral() {
        return listadoGeneral;
    }  

    public String getDatoBuscar() {
        return datoBuscar;
    }

    public void setDatoBuscar(String datoBuscar) {
        this.datoBuscar = datoBuscar;
    }
   
        
    public String buscarInformacion() throws Throwable
    {         
        String respuesta = null; 
        if (this.datoBuscar != null) 
        {          
            listadoGeneral = _controlador.CargarListado(datoBuscar);
            if (listadoGeneral != null)
            {
               Funciones.Busqueda = datoBuscar;
            }
            respuesta = "Filtro";
        }    
        else
        {
            Error.ElMensaje = Mensajes.Mensaje29; 
            respuesta = "NOSELECCION";
        }
        return respuesta;
    }
   
    public String actualizar(int codigo)
    {    
        Funciones.ParametroBuscar = codigo;
        return "EQUIPOS"; 
    }
    
    public String nuevoRegistro()
    {                
        Funciones.ParametroBuscar = 0;           
        return "EQUIPOS";   
    }
    
    public String eliminarRegistro(String codigo)
    {    
        String respuesta = null;
        Error.ElMensaje = null;
        int resultado;                           
        resultado = _controlador.eliminarRegistro(Integer.parseInt(codigo)); 
        if (resultado == 0)
        {
            Funciones.ParametroBuscar = 0;
            respuesta = "si";
        } 
        else if (resultado == 1)
        {          
            Error.ElMensaje = Mensajes.Mensaje22;    
        }              
        else
        {
            Error.ElMensaje = Mensajes.MensajeErrorBD;             
            respuesta = "no";  
        }
        return respuesta;
    }
 
}
