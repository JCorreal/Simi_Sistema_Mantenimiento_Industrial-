package mbean; // Managed Bean que responde a las acciones del form Operarios

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.Operario;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import org.primefaces.model.UploadedFile;

public class OperarioMBean  {
    
    private final Controlador_Operario _controlador = Funciones.CrearControlador_Operario();
    private Operario operario = new Operario();  
    private boolean activarCampo = false;  
    private final String ruta =  (String)(getClass().getProtectionDomain().getCodeSource().getLocation()).toString();   
    private final String destination = ruta.substring(6,46) + "web/resources/Imagenes/Fotos_Operarios/"; 
    private UploadedFile file;
    
    public OperarioMBean()
    {
        if (Funciones.ParametroBuscar == 0)
        {         
           this.operario = new Operario ();     
        }  
        else
        {        
            Operario tmp_operario = (Operario) _controlador.obtenerOperario(Funciones.ParametroBuscar);
            if (tmp_operario != null)
            {
                this.activarCampo = true;            
                this.operario = tmp_operario ; 
                if (tmp_operario.getFoto()!= null && !"".equals(tmp_operario.getFoto())) 
                {
                   this.operario.setFoto("resources/Imagenes/Fotos_Operarios/" + operario.getFoto());
                }           
            }
        }      
    }
   
    public UploadedFile getFile() {
        return file;
    }

    public void setFile(UploadedFile file) {
        this.file = file;
    }
    
    public Operario getOperario() {
        return operario;
    }

    public void setOperario(Operario operario) {
        this.operario = operario;
    }

    public boolean isActivarCampo() {
        return activarCampo;
    }

    public void setActivarCampo(boolean activarCampo) {
        this.activarCampo = activarCampo;
    }
        
    public boolean verificar()
    {
       boolean Grabar = true;          
       if (!"".equals(operario.getCorreo()))
       {
            if (Funciones.validar_Correo(operario.getCorreo()))
            {
                Grabar = false;               
                Error.ElMensaje = Mensajes.Mensaje16;
            }    
       }
       return Grabar; 
    }
    
    public String guardar() 
    {      
        int resultado;  
        if (verificar())
        {
            if (file != null) 
            {
                operario.setFoto(operario.getDocumento() + ".jpg");
            }  
            else
            {
              operario.setFoto(null);  
            }
            resultado = _controlador.guardarOperario(operario);
            if(resultado == 0)    
            {
                if (file != null) 
                {
                    File fIn  = new File(file.getFileName());
                    File fOut = new File(destination + operario.getDocumento() + ".jpg" );               
                    copyFile(fIn, fOut);   
                }
               this.operario = null;      
               Funciones.ParametroBuscar = 0;
               return "si";
            }
            else if (resultado == 1)
            {
                Error.ElMensaje = Mensajes.Mensaje26;   
                return "no"; 
            }
            else
            {
                Error.ElMensaje = Mensajes.MensajeErrorBD;   
                return "no";
            }
        } 
        else
        {
            return "no";
        }
    }

   

    public void copyFile(File s, File t)
    {
        try
        {
            FileChannel in = (new FileInputStream(s)).getChannel();
            FileChannel out = (new FileOutputStream(t)).getChannel();
            in.transferTo(0, s.length(), out);
            in.close();             
            out.close(); 
        }
        catch (IOException ex) 
        {
            System.out.println(ex);
        }
    }      


}
