package mbean; // Managed Bean que responde a las acciones del form Mantenimiento

import bll.Controlador_Mantenimiento;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.Mantenimiento;
import java.util.ArrayList;
import java.util.Date;
import javax.faces.model.SelectItem;

public final class MantenimientoMBean {
    
    private final Controlador_Mantenimiento _controlador = Funciones.CrearControlador_Mantenimiento();
    private Mantenimiento mantenimiento = new Mantenimiento();
    private ArrayList<SelectItem> lista = new ArrayList<>();
    private ArrayList<SelectItem> listaOperarios = new ArrayList<>();
    private ArrayList<SelectItem> listaEquipos = new ArrayList<>();   
    private boolean ActivarCampo = false;       
    private final Date minFecha = new Date();

    public ArrayList<SelectItem> getListaOperarios() {
        return listaOperarios;
    }

    public void setListaOperarios(ArrayList<SelectItem> listaOperarios) {
        this.listaOperarios = listaOperarios;
    }

    public ArrayList<SelectItem> getListaEquipos() {
        return listaEquipos;
    }

    public void setListaEquipos(ArrayList<SelectItem> listaEquipos) {
        this.listaEquipos = listaEquipos;
    }
   
    
    public MantenimientoMBean()
    {
        if (Funciones.ParametroBuscar == 0)
        {    
            lista = _controlador.controlarProgramacion("PROGRAMAR");
            this.mantenimiento = new Mantenimiento();  
            cargarCombos();
        }
        else
        {       
            lista = _controlador.controlarProgramacion("PROGRAMACION");  
            cargarCombos();
            Mantenimiento tmp_mantenimiento  = (Mantenimiento) _controlador.obtenerMantenimiento(Funciones.ParametroBuscar);
            if (tmp_mantenimiento  != null)
            {                     
               this.ActivarCampo = true;           
               this.mantenimiento = tmp_mantenimiento; 
            }               
        }   
    }   
 
    public void cargarCombos()
    {
        String respuesta = null;
        int tamano = lista.size();
        for(int i = 0; i < tamano; i++) 
        {        
            if ("EQUIPOS".equals(lista.get(i).getValue().toString()))
            {     
              i++;
              listaEquipos.add(new SelectItem(lista.get(i).getValue(), lista.get(i).getLabel()));
            }
            else if ("OPERARIOS".equals(lista.get(i).getValue().toString()))
            {     
              i++;
              listaOperarios.add(new SelectItem(lista.get(i).getValue(),  lista.get(i).getLabel()));
            }                
        }      
        if (listaOperarios == null)
        {           
            Error.ElMensaje = Mensajes.Mensaje11; 
            respuesta = "NOPERARIOS";  
        }
        else if (listaEquipos == null)
        {           
            Error.ElMensaje = Mensajes.Mensaje11; 
            respuesta = "NOPROGRAMACION";  
        }
    }
          
    public Mantenimiento getMantenimiento() {
        return mantenimiento;
    }

    public void setMantenimiento(Mantenimiento mantenimiento) {
        this.mantenimiento = mantenimiento;
    }
    
      public boolean isActivarCampo() {
        return ActivarCampo;
    }

    public void setActivarCampo(boolean ActivarCampo) {
        this.ActivarCampo = ActivarCampo;
    }

    public Date getMinFecha() {
        return minFecha;
    }
   
    public String guardar()
    {
        int resultado;      
        resultado = _controlador.guardarMantenimiento(mantenimiento);
        if (resultado == 0) 
        {
          this.mantenimiento = null;
          Funciones.ParametroBuscar = 0;
          return "si";
        }
        else  if (resultado == 1)
        {
           Error.ElMensaje = Mensajes.Mensaje10;   
           return "no";
        }    
        else
        {
           Error.ElMensaje = Mensajes.MensajeErrorBD;   
           return "no";
        }
    }
}
