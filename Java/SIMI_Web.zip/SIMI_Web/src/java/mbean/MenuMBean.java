package mbean; // Managed Bean que responde a las acciones del form Menu Principal

import bll.Funciones;

public class MenuMBean {

    private boolean ActivarCampo = false;
    private String Usuario = "Bienvenido: " + " " + Funciones.NombreUsuario; 
    
    public MenuMBean() 
    {
        if (Funciones.PerfilAcceso != 1)
        {
            this.ActivarCampo= true;
        }
        Funciones.ParametroBuscar = 0;   
        Funciones.arListadoGeneral= null;
        Funciones.Busqueda =null;
    }        

    public boolean isActivarCampo() {
        return ActivarCampo;
    }

    public void setActivarCampo(boolean ActivarCampo) {
        this.ActivarCampo = ActivarCampo;
    }
    
    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }

            
    public String forma(String valor)
    {       
        if (Funciones.PerfilAcceso != 1)
        {
            Funciones.ParametroBuscar = Funciones.UsuarioConectado;
            valor = "PERFIL";
        }  
        Funciones.Pagina = valor;        
        return Funciones.Pagina;
    }
    
   
}
