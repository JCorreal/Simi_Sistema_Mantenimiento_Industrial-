package bll; // Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones
   
import dal.Dao_Operario;
import dal.Dao_ListaValores;
import dal.Dao_Equipo;
import dal.Dao_Mantenimiento;

public class Funciones {  
    
    public static String Pagina = null;        
    public static int ParametroBuscar;    
    public static String NombreUsuario;
    public static int UsuarioConectado;
    public static int PerfilAcceso;
    public static String Busqueda = null;    
    
    private static Dao_Operario dao_operario;
    private static Dao_Equipo dao_equipo;
    private static Dao_Mantenimiento dao_mantenimiento;
    private static Dao_ListaValores dao_listavalores;
    
    
    public static Controlador_Equipo CrearControlador_Equipo()
    {
        dao_equipo = (Dao_Equipo) AccesoDatosFactory.ObtenerDao_Equipo();
        return new Controlador_Equipo(dao_equipo);        
    }
    
    public static Controlador_Mantenimiento CrearControlador_Mantenimiento()
    {
        dao_mantenimiento = (Dao_Mantenimiento) AccesoDatosFactory.ObtenerDao_Mantenimiento();
        return new Controlador_Mantenimiento(dao_mantenimiento);        
    }
    
    public static Controlador_Operario CrearControlador_Operario()
    {
        dao_operario = (Dao_Operario) AccesoDatosFactory.ObtenerDao_Operario();
        return new Controlador_Operario(dao_operario);        
    }
    
    public static Controlador_ListaValores CrearControlador_ListaValores()
    {
        dao_listavalores = (Dao_ListaValores) AccesoDatosFactory.ObtenerDao_ListaValores();
        return new Controlador_ListaValores(dao_listavalores);        
    }
    
    public static String NombreUsuarioConectado()
    {
        return NombreUsuario;
    }
    
    // Funcion para eliminar posibles espacios en blanco al inicio y fin de una cadena de texto
    public static String aplicarTrim(String cadena)
    {
      cadena = cadena.trim(); 
      return cadena;
    }
     
    // Funcion para validar que haya solo numeros en un campo de texto
    public static boolean verificar_SoloNumeros(String cadena)
    {            
        return (cadena.matches(".*\\D+.*"));            
    }
     
    // Funcion para validar direcciones de correo electronico
    public static boolean validar_Correo(String cadena)
    {
        boolean status = false;
        if (!cadena.matches("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*")) 
        {
            status = true;
        }
        return status;
    }
    
    // Funcion para eliminar posibles espacios de tabulacion en un campo de texto
    public static String eliminarTabulador(String cadena, String conversion)
    {
        cadena = cadena.trim();
        while (cadena.indexOf("  ", 0) != -1)
        {
           cadena = (cadena.replace("  ", " "));
        }
        if (conversion.equals("MAY"))
        {
           cadena = cadena.toUpperCase();
        }
        if (conversion.equals("1MAY")) // Organizar primera letra en Mayuscula y siguientes en Minuscula
        {
           cadena = cadena.toLowerCase();
        }
       return cadena;
    }
    
            
    public String ayuda()
    {
        try 
        {
         /*  Runtime run = Runtime.getRuntime();
             run.exec("hh.exe E:/Fuentes CM/ControlMantenimiento-JavaWeb/web/Ayudas/Ayuda.chm");
             run.freeMemory(); */

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }
        catch (Exception ex)
        {
            System.out.println("Error Llamando Ayuda: " +ex);
             
        }
        return null;        
    }
        
}
