package bll; // Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones
   
import bo.CargarListado;
import dal.Dao_Operario;
import dal.Dao_ListaValores;
import dal.Dao_Equipo;
import dal.Dao_Mantenimiento;
import java.io.IOException;
import java.util.ArrayList;

public class Funciones {  
    
    public static String Pagina = null;        
    public static int ParametroBuscar;    
    public static String NombreUsuario;
    public static int UsuarioConectado;
    public static int PerfilAcceso;
    public static String Busqueda = null;   
    public static ArrayList<CargarListado> arListadoGeneral;
    
    private static Dao_Operario dao_operario;
    private static Dao_Equipo dao_equipo;
    private static Dao_Mantenimiento dao_mantenimiento;
    private static Dao_ListaValores dao_listavalores;
    
    
    public static Controlador_Equipo CrearControlador_Equipo()
    {
        dao_equipo = (Dao_Equipo) AccesoDatosFactory.ObtenerDao_Equipo();
        return new Controlador_Equipo(dao_equipo);        
    }
    
    public static Controlador_Mantenimiento CrearControlador_Mantenimiento()
    {
        dao_mantenimiento = (Dao_Mantenimiento) AccesoDatosFactory.ObtenerDao_Mantenimiento();
        return new Controlador_Mantenimiento(dao_mantenimiento);        
    }
    
    public static Controlador_Operario CrearControlador_Operario()
    {
        dao_operario = (Dao_Operario) AccesoDatosFactory.ObtenerDao_Operario();
        return new Controlador_Operario(dao_operario);        
    }
    
    public static Controlador_ListaValores CrearControlador_ListaValores()
    {
        dao_listavalores = (Dao_ListaValores) AccesoDatosFactory.ObtenerDao_ListaValores();
        return new Controlador_ListaValores(dao_listavalores);        
    }
    
    public static String NombreUsuarioConectado()
    {
        return NombreUsuario;
    }
    
    // Funcion para eliminar posibles espacios en blanco al inicio y fin de una cadena de texto
    public static String aplicarTrim(String cadena)
    {
      cadena = cadena.trim(); 
      return cadena;
    }
     
    // Funcion para validar que haya solo numeros en un campo de texto
    public static boolean verificar_SoloNumeros(String cadena)
    {            
        return (cadena.matches(".*\\D+.*"));            
    }
     
    // Funcion para validar direcciones de correo electronico
    public static boolean validar_Correo(String cadena)
    {
        boolean status = false;
        if (!cadena.matches("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*")) 
        {
            status = true;
        }
        return status;
    }
    
    // Funcion para eliminar posibles espacios de tabulacion en un campo de texto
    public static String eliminarTabulador(String cadena, String conversion)
    {
        cadena = cadena.trim();
        while (cadena.indexOf("  ", 0) != -1)
        {
           cadena = (cadena.replace("  ", " "));
        }
        if (conversion.equals("MAY"))
        {
           cadena = cadena.toUpperCase();
        }
        if (conversion.equals("1MAY")) // Organizar primera letra en Mayuscula y siguientes en Minuscula
        {
           cadena = cadena.toLowerCase();
        }
       return cadena;
    }
    
            
    public void mostrarAyuda() throws IOException
    {
       /* Estas líneas son las encargadas de llamar el archivo de ayudas chm o PDF.
       Pero en algunos servidores no funciona, porque como mecanismo de protección
       impiden que se pueda ejecutar un archivo con extensión .chm alojado allí.
      
       La solución es ubicar el archivo Ayuda.chm en cualquier parte del disco duro 
       y modificar la ruta, en la variable destino. */ 
       String ruta =  (String)(getClass().getProtectionDomain().getCodeSource().getLocation()).toString();   
       String destino = ruta.substring(6,46) + "Ayudas/Ayuda.chm";  
      
        try 
        {
           Runtime run = Runtime.getRuntime();
           run.exec("hh.exe " + destino );
           run.freeMemory(); 
        }
        catch (Exception ex)
        {
            System.out.println("Error Llamando Ayuda: " +ex);             
        }        
    }
        
    public static ArrayList<CargarListado> cargarBusqueda(String criterio) 
    {        
     /* Función para buscar en el Array el criterio ingresado por el usuario, sin embargo hacerlo así
        tiene sus reparos, pues normalmente se cargan en pantalla a lo sumo unos 20 registros, que es 
        lo que cabe en un formulario, ya si se quiere buscar un registro específico, se consulta en BD.

        Porque en escenarios donde se manejen muchos registros como ventas-pedidos, eso implica cargar 
        millones de registros en un array, y se abusa de la RAM, generando tráfico de red innecesario. 
        
        De cualquier forma el Procedimiento Almacenado: SPR_R_CargarListado tiene implementado como 
        parámetro para hacer la búsqueda por el criterio elegido y devolver ese registro.  */  
        
      ArrayList<CargarListado> arlBusqueda = new ArrayList();
      for (int i = 0; i < arListadoGeneral.size(); i++)
      {
          if (arListadoGeneral.get(i).getColumna2().equals(criterio.toUpperCase()))
          {
             arlBusqueda.add(new CargarListado(arListadoGeneral.get(i).getColumna1(), arListadoGeneral.get(i).getColumna2(), arListadoGeneral.get(i).getColumna3(), arListadoGeneral.get(i).getColumna4(),arListadoGeneral.get(i).getColumna5(),arListadoGeneral.get(i).getColumna6()));
             break;
          }
      }
      return arlBusqueda;
    }
}
