package dal; // Interface que expone los métodos que implementa el DAO de Mantenimiento

import bo.CargarListado;
import bo.Mantenimiento;
import java.util.ArrayList;
import javax.faces.model.SelectItem;

public interface IDao_Mantenimiento {
   
    public Mantenimiento obtenerMantenimiento(int datoBuscar);
    public int guardarMantenimiento(Mantenimiento mantenimiento, int Usuario);
    public ArrayList<CargarListado> cargarListado();
    public ArrayList<SelectItem> controlarProgramacion(String tabla);  
    public int eliminarRegistro(int datoEliminar);       

}
