package dal; // Interface que expone los métodos que implementa el DAO de Marcas-Líneas

import bo.ListaValores;
import bo.CargarListado;
import java.util.ArrayList;

public interface IDao_ListaValores {
   
    public ListaValores obtenerListaValores(int datoBuscar);
    public int guardarListaValores(ListaValores listavalores, int Usuario);
    public ArrayList<CargarListado> cargarListado(String tabla, String condicion);
    public int eliminarRegistro(int datoEliminar);       

}
