package dal; // Capa Acceso Datos para programación de Mantenimiento

import bo.CargarListado;
import bo.Mantenimiento;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.faces.model.SelectItem;

public class Dao_Mantenimiento extends Dao_General implements IDao_Mantenimiento {
    
    @Override
    public synchronized Mantenimiento obtenerMantenimiento(int datoBuscar)
    {
        Mantenimiento mantenimiento = new Mantenimiento();
        try
        {
            buscarRegistro("TBL_MANTENIMIENTO", datoBuscar);
            if (Rset.next ())
            {
                mantenimiento.setMantenimiento_id(Rset.getInt(1));
                mantenimiento.setEquipo_id(Rset.getInt(2));
                mantenimiento.setOperario_id(Integer.parseInt(Rset.getString(3)));
                mantenimiento.setFecha(Rset.getDate(4));
                mantenimiento.setObservaciones(Rset.getString(5));
            } 
            else
            {
               mantenimiento = null; 
            }            
            Rset.close(); // Se cierra el ResultSet, aunque no es necesario   
        }
        catch (SQLException ex)
        {  
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex)
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        finally
        {
             liberarRecursos();
        }
        return mantenimiento;
    }

    @Override
    public synchronized int guardarMantenimiento(Mantenimiento mantenimiento, int Usuario)
    {
        int resultado = -1;  
        try
        {
            con = Conexion.obtenerConexion();           
            cst = con.prepareCall("{call SPR_IU_Mantenimiento (?, ?, ?, ?, ?, ?, ?)}");                  
            cst.setInt(1, mantenimiento.getMantenimiento_id());
            cst.setInt(2, mantenimiento.getEquipo_id());
            cst.setDouble(3, mantenimiento.getOperario_id());
            Date d = new Date();
            d = mantenimiento.getFecha();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");               
            String LaFecha = sdf.format(d);
            cst.setString(4, LaFecha);                          
            cst.setString(5,mantenimiento.getObservaciones());
            cst.setInt(6, Usuario);
            cst.registerOutParameter(7, java.sql.Types.INTEGER);
            cst.executeUpdate();
            resultado =cst.getByte(7);                                   
        }
        catch (SQLException ex) 
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex)
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        finally
        {
	    liberarRecursos();
	}
        return resultado;
    }

    
    @Override
    public synchronized ArrayList<CargarListado> cargarListado() 
    {
       ArrayList<CargarListado> arlListado=new ArrayList();
       arlListado = cargarListas("TBL_MANTENIMIENTO");
       return arlListado;
    }

    @Override
    public synchronized int eliminarRegistro(int datoEliminar) 
    {
      int resultado = borrarRegistro("TBL_MANTENIMIENTO", datoEliminar);
      return resultado;
    }
   
    @Override
    public synchronized ArrayList<SelectItem> controlarProgramacion(String tabla) 
    {
      ArrayList<SelectItem> arlListControlProgramacion = new ArrayList<>();   
      arlListControlProgramacion = ControlProgramacion(tabla);
      return arlListControlProgramacion; 
    }
    
}
