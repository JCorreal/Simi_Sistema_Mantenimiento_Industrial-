package bo; //  Clase que representa la estructura en BD Operarios

public class Operario {
   
    private int     operario_id = 0;
    private String  documento   = null;
    private String  nombres     = null;
    private String  apellidos   = null;
    private String  telefono    = null;
    private String  correo      = null;
    private int     clave;
    private int     perfil      = 3; 
    private String  foto        = null;

    public Operario() {}           
    
    public int getOperario_Id() {
        return operario_id;
    }

    public void setOperario_Id(int operario_id) {
        this.operario_id = operario_id;
    }
        
    
    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;                
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getClave() {
        return clave;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }

    public int getPerfil() {
        return perfil;
    }

    public void setPerfil(int perfil) {
        this.perfil = perfil;
    }
    
    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }   
   
}
