package bll; // Coleccion de mensajes lanzados por el sistema

public class Mensajes {
        public static String MensajeAplicacion = "SIMI - SISTEMA DE MANTENIMIENTO INDUSTRIAL";
        public static String MensajeGraba = "El registro ha sido grabado satisfactoriamente";
        public static String MensajeActualiza = "El registro ha sido modificado satisfactoriamente";
        public static String MensajeBorrado = "El registro ha sido eliminado satisfactoriamente";
        public static String MensajeConfirmarBorrado = "¿ Esta seguro que desea eliminar este registro ?";
        public static String MensajeCampoRequerido = "Error, este campo es requerido por favor ingresar la informacion";
        public static String MensajeErrorBD = "Se ha producido un error accesando la base de datos";
        public static String Mensaje2 = "Error, la clave es incorrecta, intente de nuevo";
        public static String Mensaje3 = "Error, esta no es su clave actual, reportese  con el administrador";
        public static String Mensaje4 = "Error, debe ingresar una clave diferente de la anterior";
        public static String Mensaje5 = "Error, esta no es la misma clave digitada en clave nueva";
        public static String Mensaje6 = "Error, primera cifra no puede ser 0";
        public static String Mensaje7 = "Error, esta serie ya esta asignada a otro equipo";
        public static String Mensaje8 = "Error, este nombre ya esta asignado";
        public static String Mensaje9 = "Error, este registro no se puede eliminar ya que esta relacionado en equipos";
        public static String Mensaje10 = "Error, ya existe una programacion para este operario en esta fecha";
        public static String Mensaje11 = "No existen Marcas disponibles para relacionar al equipo";
        public static String Mensaje12 = "No existen Lineas disponibles para relacionar al equipo";
        public static String Mensaje13 = "No existen Operarios disponibles para relacionar al mantenimiento";
        public static String Mensaje14 = "No existen Equipos disponibles para relacionar al mantenimiento";
        public static String Mensaje15 = "Error, documentos no pueden ser menores de 6 digitos";
        public static String Mensaje16 = "Error, correo con formato errado";
        public static String Mensaje17 = "Error, la longitud del telefono debe tener 7 o 10 dígitos";
        public static String Mensaje18 = "Error, no se encontro la foto referenciada en la ruta";
        public static String Mensaje19 = "Error, el formato de la imagen no es valido";
        public static String Mensaje20 = "Error, este operario no se puede eliminar ya que tiene programaciones pendientes";
        public static String Mensaje21 = "Error, por favor ingrese una clave que contenga al menos 6 digitos";
        public static String Mensaje22 = "Error, este equipo no se puede eliminar ya que tiene programacion pendiente por ejecutar";
        public static String Mensaje23 = "Error, existen caracteres numericos en este campo";
        public static String Mensaje24 = "Error, No se encontro la foto referenciada en la ruta";
        public static String Mensaje25 = "Error, caracteres no numericos en este campo";
        public static String Mensaje26 = "Error, este registro ya existe";
        public static String Mensaje27 = "Error, fecha no puede ser menor que la actual";
        public static String Mensaje28 = "Error, longitud del campo supera los caracteres permitidos";
        
        public static String Mensaje29 = "Error, No se encontro el archivo de ayuda";
        
}
