package dal; // Capa Acceso Datos para control de Operarios

import bo.CargarListado;
import bo.Operario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao_Operario extends Dao_General implements IDao_Operario {

      
    @Override
    public synchronized Operario obtenerAcceso (String datoBuscar, int clave)
    {
        Operario operario = new Operario();
        try
        {
            con = Conexion.obtenerConexion();
            cst = con.prepareCall("{call SPR_R_obtenerAcceso (?,?,?)}");
            cst.setString(1, datoBuscar);
            cst.setInt(2, clave);                                  
            cst.registerOutParameter(3, oracle.jdbc.OracleTypes.CURSOR);
            cst.execute();
            if (cst.getObject(3)!= null)
            {
                Rset = (ResultSet) cst.getObject(3);                             
            }
            if (Rset.next ())
            {                
                operario.setOperario_Id(Rset.getInt(1));
                operario.setNombres(Rset.getString(2));
                operario.setApellidos(Rset.getString(3));
                operario.setPerfil(Rset.getInt(4));    
            }   
            else
            {
                operario = null; 
            }            
            Rset.close(); // Se cierra el ResultSet, aunque no es necesario    
        }
        catch (SQLException ex)
        { 
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex) 
        {
            System.out.println("Error " +ex);
            liberarRecursos();
        }
        finally
        {
	     liberarRecursos();
	}
        return operario;
    }
   
    @Override
    public synchronized Operario obtenerOperario (int datoBuscar)
    {
        Operario operario = new Operario();
        try
        {
            buscarRegistro("TBL_OPERARIOS", datoBuscar);
            if (Rset.next ())
            {                
                operario.setOperario_Id(Rset.getInt(1));   
                operario.setDocumento(Rset.getString(2));
                operario.setNombres(Rset.getString(3));
                operario.setApellidos(Rset.getString(4));
                operario.setTelefono(Rset.getString(5));
                operario.setCorreo(Rset.getString(6));      
                operario.setFoto(Rset.getString(7)); 
            }    
            else
            {
               operario = null; 
            }            
            Rset.close(); // Se cierra el ResultSet, aunque no es necesario    
        }
        catch (SQLException ex)
        { 
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex) 
        {
           System.out.println("Error " +ex);
           liberarRecursos();
        }
        finally
        {
          liberarRecursos();
        }
        return operario;
    }

    @Override
    public synchronized int guardarOperario (Operario operario, int Usuario) 
    {
        int resultado = -1;
        try 
        {         
            con = Conexion.obtenerConexion();           
            cst = con.prepareCall("{call SPR_IU_Operarios (?, ?, ?, ?, ?, ?, ?, ?, ?)}");        
            cst.setInt(1, operario.getOperario_Id());
            cst.setString(2, operario.getDocumento());
            cst.setString(3, operario.getNombres());
            cst.setString(4, operario.getApellidos());
            cst.setString(5, operario.getTelefono());
            cst.setString(6, operario.getCorreo());                
            cst.setString(7, operario.getFoto());
            cst.setInt(8, Usuario);
            cst.registerOutParameter(9, java.sql.Types.INTEGER);
            cst.executeUpdate();
            resultado = cst.getByte(9);                        
        }
        catch (SQLException ex)
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex) 
        {
            System.out.println("Error " +ex);
            liberarRecursos();
        }
        finally
        {
	    liberarRecursos();
	}       
        return resultado; 
    }
    
    @Override
    public synchronized int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva) 
    {
        int resultado = -1;
        try 
        {            
            con = Conexion.obtenerConexion();           
            cst = con.prepareCall("{call SPR_U_CambioClave (?, ?, ?, ?)}");                 
            cst.setInt(1, Usuario);
            cst.setInt(2, claveAnterior);         
            cst.setInt(3, claveNueva);            
            cst.registerOutParameter(4, java.sql.Types.INTEGER);
            cst.executeUpdate();
            resultado = cst.getByte(4);            
        }
        catch (SQLException ex) 
        {
            System.out.println("Error : " +ex);              
            liberarRecursos();
        }
        catch (Exception ex) 
        {
            System.out.println("Error : " +ex);              
            liberarRecursos();
        }
        finally
        {
	    liberarRecursos();
	}  
        return resultado;
    }


    @Override
    public synchronized int eliminarRegistro(int datoEliminar) 
    {
        int resultado = borrarRegistro("TBL_OPERARIOS", datoEliminar);
        return resultado;
    }

    @Override
    public ArrayList<CargarListado> cargarListado(String condicion) {
       ArrayList<CargarListado> arlListado=new ArrayList();
       arlListado = cargarListas("TBL_OPERARIOS", condicion);
       return arlListado; 
    }
    
}
