/*======================================================================================
    La regla de negocio es que no puede haber sino una sola programación por equipo
    Un Operario no puede estar asignado en la misma fecha para varios mantenimientos
 =======================================================================================*/
package SIMI_Desktop;

import bll.Controlador_Mantenimiento;
import bll.Funciones;
import bll.Mensajes;
import bo.Mantenimiento;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class JFrame_Mantenimiento extends javax.swing.JFrame {
    private final Controlador_Mantenimiento _controlador = Funciones.crearControlador_Mantenimiento();
    int elMantenimiento = 0;
    boolean grabar ;
    Mantenimiento mantenimiento;   
    Date hoy = new Date();
       
    public JFrame_Mantenimiento() {
        initComponents();
        JComboBox_Documento.setVisible(false);   
        JComboBox_CodigoEquipo.setVisible(false);
        JCalendarComboBox_Fecha.setDate(hoy);      
        
        if (Funciones.Fuente.equals("PROGRAMAR"))
        {
          JButton_Buscar.setVisible(false);  
        }        
        else
        {
            JButton_Grabar.setEnabled(false);
        }     
        CargarCombos();   
    }
    
    
    private void CargarCombos()
    {           
      List listadeValores = new ArrayList();  
      JComboBox_Documento.removeAllItems();
      JComboBox_NombreOperario.removeAllItems();
      JComboBox_CodigoEquipo.removeAllItems();
      JComboBox_NombreEquipo.removeAllItems();
      
      listadeValores = _controlador.cargarCombosEM(Funciones.Fuente); 
      int tamano = listadeValores.size();
      for(int i=0; i < tamano; i++)
      {           
            switch (listadeValores.get(i).toString()) {
                case "OPERARIOS":
                    i++;
                    JComboBox_Documento.addItem(listadeValores.get(i).toString());
                    i++;
                    JComboBox_NombreOperario.addItem(listadeValores.get(i).toString());
                    break;
                case "EQUIPOS":
                    i++;
                    JComboBox_CodigoEquipo.addItem(listadeValores.get(i).toString());
                    i++;
                    JComboBox_NombreEquipo.addItem(listadeValores.get(i).toString());
                    break;                
            }
      }        
    }


    private void Limpiar()
    {
      elMantenimiento=0;
      JTextArea_Observaciones.setText("");
      JButton_Eliminar.setEnabled(false);
      JComboBox_NombreEquipo.setEnabled(true);
      if (Funciones.Fuente.equals("PROGRAMACION"))
      {       
         JButton_Grabar.setEnabled(false);
      }
      if (JComboBox_CodigoEquipo.getItemCount() == 0)
      {      
          dispose();
      }
      else
      {
        JComboBox_NombreEquipo.requestFocus();
      }
    }
    
    private void LlenarCampos()
    {
             
       mantenimiento = (Mantenimiento) _controlador.obtenerMantenimiento(Integer.parseInt(JComboBox_CodigoEquipo.getSelectedItem().toString()));
       if (mantenimiento  != null)
        {
          elMantenimiento =  mantenimiento.getMantenimiento_id();
          JComboBox_CodigoEquipo.setSelectedItem(mantenimiento.getEquipo_id());
          JComboBox_NombreEquipo.setSelectedIndex(JComboBox_CodigoEquipo.getSelectedIndex());
          BigDecimal bigDecimal = new BigDecimal(mantenimiento.getOperario_id());
          JComboBox_Documento.setSelectedItem(bigDecimal.toString());          
          JComboBox_NombreOperario.setSelectedIndex(JComboBox_Documento.getSelectedIndex());
          JTextArea_Observaciones.setText(mantenimiento.getObservaciones());
          JComboBox_NombreEquipo.setEnabled(false);  
          JButton_Eliminar.setEnabled(true);
          JCalendarComboBox_Fecha.setDate(mantenimiento.getFecha());
          JButton_Grabar.setEnabled(true);
        }
    }
    private void guardar(String Mensaje )
    {
      int resultado;  
      Mantenimiento mantenimiento = new Mantenimiento();
      mantenimiento.setMantenimiento_id(elMantenimiento);
      mantenimiento.setEquipo_id(Integer.parseInt(JComboBox_CodigoEquipo.getSelectedItem().toString()));
      mantenimiento.setOperario_id(Integer.parseInt(JComboBox_Documento.getSelectedItem().toString()));      
      mantenimiento.setFecha(JCalendarComboBox_Fecha.getDate());
      mantenimiento.setObservaciones(JTextArea_Observaciones.getText());
      
       
      resultado = _controlador.guardarMantenimiento(mantenimiento);
        switch (resultado) {
            case 0:
                JOptionPane.showMessageDialog(rootPane, Mensaje, Mensajes.MensajeAplicacion, WIDTH);
                CargarCombos();
                Limpiar();
                break;
            case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje10, Mensajes.MensajeAplicacion, javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
            default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
        }
       
    }
    
    private void validarFecha()
    {
      Date Fecha = new Date();
      if (JCalendarComboBox_Fecha.getDate().before(Fecha))
      {
          grabar = false;
          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje27, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);              
      }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Eliminar = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        JButton_Ayuda = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        JComboBox_NombreEquipo = new javax.swing.JComboBox();
        JButton_Buscar = new javax.swing.JButton();
        JComboBox_CodigoEquipo = new javax.swing.JComboBox();
        JComboBox_Documento = new javax.swing.JComboBox();
        JComboBox_NombreOperario = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTextArea_Observaciones = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        JCalendarComboBox_Fecha = new de.wannawork.jcalendar.JCalendarComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SAVE.jpg"))); // NOI18N
        JButton_Grabar.setText("Grabar");
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });

        JButton_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Borrar.jpg"))); // NOI18N
        JButton_Eliminar.setText("Eliminar");
        JButton_Eliminar.setEnabled(false);
        JButton_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EliminarActionPerformed(evt);
            }
        });

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });

        JButton_Ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HELP.jpg"))); // NOI18N
        JButton_Ayuda.setText("Ayuda");
        JButton_Ayuda.setToolTipText("");
        JButton_Ayuda.setPreferredSize(new java.awt.Dimension(85, 23));
        JButton_Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AyudaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(JButton_Grabar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Ayuda, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JButton_Salir, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {JButton_Cancelar, JButton_Eliminar, JButton_Grabar, JButton_Salir});

        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JButton_Grabar)
                    .addComponent(JButton_Cancelar)
                    .addComponent(JButton_Eliminar)
                    .addComponent(JButton_Salir)
                    .addComponent(JButton_Ayuda, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {JButton_Cancelar, JButton_Eliminar, JButton_Grabar, JButton_Salir});

        jLabel2.setText("Equipo");

        JComboBox_NombreEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreEquipoActionPerformed(evt);
            }
        });

        JButton_Buscar.setText("...");
        JButton_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_BuscarActionPerformed(evt);
            }
        });

        JComboBox_NombreOperario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreOperarioActionPerformed(evt);
            }
        });

        jLabel1.setText("Operario");

        jLabel3.setText("Fecha");

        JTextArea_Observaciones.setColumns(20);
        JTextArea_Observaciones.setRows(5);
        jScrollPane1.setViewportView(JTextArea_Observaciones);

        jLabel4.setText("Observaciones");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JComboBox_NombreOperario, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JComboBox_NombreEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(JButton_Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(JComboBox_CodigoEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(JComboBox_Documento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JCalendarComboBox_Fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JComboBox_NombreEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(JComboBox_CodigoEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JButton_Buscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JComboBox_NombreOperario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JComboBox_Documento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(JCalendarComboBox_Fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel4)))
                .addGap(46, 46, 46)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(625, 418));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JComboBox_NombreEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreEquipoActionPerformed
        JComboBox_CodigoEquipo.setSelectedIndex(JComboBox_NombreEquipo.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreEquipoActionPerformed

    private void JButton_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_BuscarActionPerformed
        LlenarCampos();
    }//GEN-LAST:event_JButton_BuscarActionPerformed

    private void JComboBox_NombreOperarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreOperarioActionPerformed
        JComboBox_Documento.setSelectedIndex(JComboBox_NombreOperario.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreOperarioActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        validarFecha();
        if (grabar)
        {
            if (JTextArea_Observaciones.getText().length()>255)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextArea_Observaciones.requestFocus();
            }

            if (grabar)
            {
                if (Funciones.Fuente.equals("PROGRAMAR"))
                {
                    guardar( Mensajes.MensajeGraba);
                }
                else
                {
                    guardar( Mensajes.MensajeActualiza);
                }
            }
        }

    }//GEN-LAST:event_JButton_GrabarActionPerformed

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
        Limpiar();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EliminarActionPerformed
        if (JOptionPane.showConfirmDialog(rootPane, Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, JOptionPane.YES_NO_OPTION)==0)
        {
           
           if (_controlador.eliminarRegistro(elMantenimiento)==0)
           {
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, WIDTH);                
                CargarCombos();
                Limpiar();               
           }          
           else
           {
               JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
           }
        }
    }//GEN-LAST:event_JButton_EliminarActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

    private void JButton_AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AyudaActionPerformed
        try {
           /* Runtime run = Runtime.getRuntime();
             run.exec("hh.exe E:/Fuentes CM/ControlMantenimiento-JavaDesktop/ControlMantenimiento-JavaDesktop/Ayudas/Ayuda.chm");
             run.freeMemory();*/
             
            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje29, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_JButton_AyudaActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Ayuda;
    private javax.swing.JButton JButton_Buscar;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Eliminar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private de.wannawork.jcalendar.JCalendarComboBox JCalendarComboBox_Fecha;
    private javax.swing.JComboBox JComboBox_CodigoEquipo;
    private javax.swing.JComboBox JComboBox_Documento;
    private javax.swing.JComboBox JComboBox_NombreEquipo;
    private javax.swing.JComboBox JComboBox_NombreOperario;
    private javax.swing.JTextArea JTextArea_Observaciones;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
