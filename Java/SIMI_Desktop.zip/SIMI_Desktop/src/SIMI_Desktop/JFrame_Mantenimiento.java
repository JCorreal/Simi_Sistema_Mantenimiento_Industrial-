/*======================================================================================
    La regla de negocio es que no puede haber sino una sola programación por equipo
    Un Operario no puede estar asignado en la misma fecha para varios mantenimientos
 =======================================================================================*/
package SIMI_Desktop;

import bll.Controlador_Mantenimiento;
import bll.Funciones;
import bll.Mensajes;
import bo.Mantenimiento;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class JFrame_Mantenimiento extends javax.swing.JFrame {
 private final Controlador_Mantenimiento _controlador = Funciones.crearControlador_Mantenimiento();    
    boolean grabar ;
    Mantenimiento mantenimiento;   
    Date hoy = new Date();
    public JFrame_Mantenimiento() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        JComboBox_Documento.setVisible(false);   
        JComboBox_CodigoEquipo.setVisible(false);
        JCalendarComboBox_Fecha.setDate(hoy);      
        CargarCombos();   
        if (Funciones.ParametroBuscar != 0)
        {
           consultarBD();
        }
    }

    private void CargarCombos()
    {           
      List listadeValores = new ArrayList();  
      JComboBox_Documento.removeAllItems();
      JComboBox_NombreOperario.removeAllItems();
      JComboBox_CodigoEquipo.removeAllItems();
      JComboBox_NombreEquipo.removeAllItems();
      String fuente = "PROGRAMAR";
      if (Funciones.ParametroBuscar != 0)
      {
       fuente = "PROGRAMACION";
      }     
      listadeValores = _controlador.cargarCombosEM(fuente); 
      int tamano = listadeValores.size();
      for(int i=0; i < tamano; i++)
      {           
            switch (listadeValores.get(i).toString()) {
                case "OPERARIOS":
                    i++;
                    JComboBox_Documento.addItem(listadeValores.get(i).toString());
                    i++;
                    JComboBox_NombreOperario.addItem(listadeValores.get(i).toString());
                    break;
                case "EQUIPOS":
                    i++;
                    JComboBox_CodigoEquipo.addItem(listadeValores.get(i).toString());
                    i++;
                    JComboBox_NombreEquipo.addItem(listadeValores.get(i).toString());
                    break;                
            }
      }        
    }

    private void consultarBD()
    {
       mantenimiento = (Mantenimiento) _controlador.obtenerMantenimiento(Integer.parseInt(JComboBox_CodigoEquipo.getSelectedItem().toString()));
       if (mantenimiento  != null)
       {     
           poblarFormulario(); 
       }
    }
    
    private void poblarFormulario()
    {           
          int Position=0;
          for (int i = 0; i < JComboBox_CodigoEquipo.getItemCount(); i++)
          {
               JComboBox_CodigoEquipo.setSelectedIndex(i);
               if (Integer.parseInt(JComboBox_CodigoEquipo.getSelectedItem().toString()) == mantenimiento.getEquipo_id())
               {
                 Position = JComboBox_CodigoEquipo.getSelectedIndex();             
                 JComboBox_NombreEquipo.setSelectedIndex(Position); 
                break;
               }
          }
          for (int i = 0; i < JComboBox_Documento.getItemCount(); i++)
          {
               JComboBox_Documento.setSelectedIndex(i);
               if (Integer.parseInt(JComboBox_Documento.getSelectedItem().toString()) == mantenimiento.getOperario_id())
               {
                 Position = JComboBox_Documento.getSelectedIndex();                 
                 JComboBox_NombreOperario.setSelectedIndex(Position); 
                break;
               }
          }
          
          JComboBox_NombreEquipo.setEnabled(false);  
          JTextArea_Observaciones.setText(mantenimiento.getObservaciones());         
          JCalendarComboBox_Fecha.setDate(mantenimiento.getFecha());
          JButton_Eliminar.setEnabled(true);
    }
     
    private void Limpiar()
    {
      if (Funciones.ParametroBuscar == 0)  
      {
        JTextArea_Observaciones.setText("");
        JButton_Eliminar.setEnabled(false);
        JComboBox_NombreEquipo.setEnabled(true);       
        if (JComboBox_CodigoEquipo.getItemCount() == 0)
        {      
            dispose();
        }
        else
        {
          JComboBox_NombreEquipo.requestFocus();
        }
      }    
    }
    
   
    private void guardar()
    {
      int resultado;  
      Mantenimiento mantenimiento = new Mantenimiento();
      mantenimiento.setMantenimiento_id(Funciones.ParametroBuscar);
      mantenimiento.setEquipo_id(Integer.parseInt(JComboBox_CodigoEquipo.getSelectedItem().toString()));
      mantenimiento.setOperario_id(Integer.parseInt(JComboBox_Documento.getSelectedItem().toString()));      
      mantenimiento.setFecha(JCalendarComboBox_Fecha.getDate());
      mantenimiento.setObservaciones(JTextArea_Observaciones.getText());
      
       
      resultado = _controlador.guardarMantenimiento(mantenimiento);
        switch (resultado) {
            case 0:
                if (Funciones.ParametroBuscar == 0)
                {
                  JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, WIDTH);     
                  CargarCombos();
                  Limpiar();
                }
                else
                {
                  JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, WIDTH);     
                  dispose();
                }
                break;
            case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje10, Mensajes.MensajeAplicacion, javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
            default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
        }
       
    }
    
    private void validarFecha()
    {
      Date Fecha = new Date();
      if (JCalendarComboBox_Fecha.getDate().before(Fecha))
      {
          grabar = false;
          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje27, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);              
      }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        JComboBox_NombreEquipo = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        JComboBox_NombreOperario = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        JCalendarComboBox_Fecha = new de.wannawork.jcalendar.JCalendarComboBox();
        JComboBox_Documento = new javax.swing.JComboBox();
        JComboBox_CodigoEquipo = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTextArea_Observaciones = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Eliminar = new javax.swing.JButton();
        JButton_Ayuda = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icotiempo.jpg"))); // NOI18N
        jLabel10.setText("Mantenimiento");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(435, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 210, 560, -1));

        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 210, 560, 340));

        jLabel2.setText("Equipo");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 270, -1, -1));

        JComboBox_NombreEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreEquipoActionPerformed(evt);
            }
        });
        getContentPane().add(JComboBox_NombreEquipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 220, -1));

        jLabel3.setText("Operario");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 310, -1, -1));

        JComboBox_NombreOperario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreOperarioActionPerformed(evt);
            }
        });
        getContentPane().add(JComboBox_NombreOperario, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 310, 220, -1));

        jLabel4.setText("Fecha");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 350, -1, -1));
        getContentPane().add(JCalendarComboBox_Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 350, -1, -1));

        getContentPane().add(JComboBox_Documento, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 310, -1, -1));

        getContentPane().add(JComboBox_CodigoEquipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 270, -1, -1));

        JTextArea_Observaciones.setColumns(20);
        JTextArea_Observaciones.setRows(5);
        jScrollPane1.setViewportView(JTextArea_Observaciones);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 400, 220, 70));

        jLabel5.setText("Observaciones");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 430, -1, -1));

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SAVE.jpg"))); // NOI18N
        JButton_Grabar.setText("Grabar");
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Grabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 500, 107, 29));

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 500, 107, 29));

        JButton_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Borrar.jpg"))); // NOI18N
        JButton_Eliminar.setText("Eliminar");
        JButton_Eliminar.setEnabled(false);
        JButton_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EliminarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 500, 107, -1));

        JButton_Ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HELP.jpg"))); // NOI18N
        JButton_Ayuda.setText("Ayuda");
        JButton_Ayuda.setToolTipText("");
        JButton_Ayuda.setPreferredSize(new java.awt.Dimension(85, 23));
        JButton_Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AyudaActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 500, 107, 29));

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 500, 107, 29));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JComboBox_NombreEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreEquipoActionPerformed
        JComboBox_CodigoEquipo.setSelectedIndex(JComboBox_NombreEquipo.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreEquipoActionPerformed

    private void JComboBox_NombreOperarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreOperarioActionPerformed
        JComboBox_Documento.setSelectedIndex(JComboBox_NombreOperario.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreOperarioActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        validarFecha();
        if (grabar)
        {
            if (JTextArea_Observaciones.getText().length()>255)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextArea_Observaciones.requestFocus();
            }

            if (grabar)
            {
                if (Funciones.ParametroBuscar ==0)
                {
                    guardar();
                }
            }
        }
    }//GEN-LAST:event_JButton_GrabarActionPerformed

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
        Limpiar();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EliminarActionPerformed
        int resultado;
        if (JOptionPane.showConfirmDialog(rootPane, Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, JOptionPane.YES_NO_OPTION )==0)
        {
            resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar);
            switch (resultado) {
                case 0:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, WIDTH);

                Limpiar();
                break;
                case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje20, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
                default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
            }
        }
    }//GEN-LAST:event_JButton_EliminarActionPerformed

    private void JButton_AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AyudaActionPerformed
        try {
            /* Runtime run = Runtime.getRuntime();
            run.exec("hh.exe E:/Fuentes CM/ControlMantenimiento-JavaDesktop/ControlMantenimiento-JavaDesktop/Ayudas/Ayuda.chm");
            run.freeMemory();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje29, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_JButton_AyudaActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Ayuda;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Eliminar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private de.wannawork.jcalendar.JCalendarComboBox JCalendarComboBox_Fecha;
    private javax.swing.JComboBox JComboBox_CodigoEquipo;
    private javax.swing.JComboBox JComboBox_Documento;
    private javax.swing.JComboBox JComboBox_NombreEquipo;
    private javax.swing.JComboBox JComboBox_NombreOperario;
    private javax.swing.JTextArea JTextArea_Observaciones;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
