package SIMI_Desktop;

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bo.Operario;
import javax.swing.JOptionPane;

public class JFrame_CambioClave extends javax.swing.JFrame {

    boolean grabar;  
    Operario operario;
    
    public JFrame_CambioClave() {
        initComponents();        
        this.setExtendedState(MAXIMIZED_BOTH);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        JPasswordField_Clave = new javax.swing.JPasswordField();
        JPasswordField_ClaveNueva = new javax.swing.JPasswordField();
        JPasswordField_Confirmar = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cambio Clave");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/EDITAR.jpg"))); // NOI18N
        JButton_Grabar.setText("Modificar");
        JButton_Grabar.setToolTipText("");
        JButton_Grabar.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Grabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 370, -1, -1));

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 370, 99, 29));

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 370, 99, 29));

        JPasswordField_Clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ClaveActionPerformed(evt);
            }
        });
        JPasswordField_Clave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyTyped(evt);
            }
        });
        getContentPane().add(JPasswordField_Clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 270, 55, -1));

        JPasswordField_ClaveNueva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ClaveNuevaActionPerformed(evt);
            }
        });
        JPasswordField_ClaveNueva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveNuevaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveNuevaKeyTyped(evt);
            }
        });
        getContentPane().add(JPasswordField_ClaveNueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 300, 55, -1));

        JPasswordField_Confirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ConfirmarActionPerformed(evt);
            }
        });
        JPasswordField_Confirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ConfirmarKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ConfirmarKeyTyped(evt);
            }
        });
        getContentPane().add(JPasswordField_Confirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 330, 55, -1));

        jLabel1.setText("Clave Actual");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, -1, -1));

        jLabel6.setText("Clave Nueva");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 300, -1, -1));

        jLabel7.setText("Confirmar");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 330, -1, -1));

        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 240, 420, 180));

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel8.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoclave.jpg"))); // NOI18N
        jLabel8.setText("Cambio Clave");
        jLabel8.setToolTipText("");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(295, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 190, 420, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        setSize(new java.awt.Dimension(1275, 578));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JPasswordField_ClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_Clave.getPassword())))
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else if (JPasswordField_Clave.getPassword().length != 6) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else {
            JPasswordField_ClaveNueva.requestFocus();
        }

    }//GEN-LAST:event_JPasswordField_ClaveActionPerformed

    private void JPasswordField_ClaveNuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveNuevaActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_ClaveNueva.getPassword())))
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_ClaveNueva.requestFocus();
        } else if (JPasswordField_ClaveNueva.getPassword().length != 6 ) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_ClaveNueva.requestFocus();
        }else if  (String.valueOf(JPasswordField_Clave.getPassword()).equals(String.valueOf(JPasswordField_ClaveNueva.getPassword()))) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje4, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_ClaveNueva.requestFocus();
        } else {
            JPasswordField_Confirmar.requestFocus();
        }
    }//GEN-LAST:event_JPasswordField_ClaveNuevaActionPerformed

    private void JPasswordField_ConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ConfirmarActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_Confirmar.getPassword())))
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Confirmar.requestFocus();
        } else if (JPasswordField_Confirmar.getPassword().length !=  6 ) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Confirmar.requestFocus();
        }else   if (!String.valueOf(JPasswordField_Confirmar.getPassword()).equals(String.valueOf(JPasswordField_ClaveNueva.getPassword())))         {   
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje5, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Confirmar.requestFocus();
        } else {
            JButton_Grabar.requestFocus();
        }
    }//GEN-LAST:event_JPasswordField_ConfirmarActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        JPasswordField_ClaveActionPerformed(evt); // Revisar Clave Actual
        if (grabar) {
            JPasswordField_ClaveNuevaActionPerformed(evt); // Revisar Nueva Clave
            if (grabar) {
                JPasswordField_ConfirmarActionPerformed(evt); // Confirmar Clave
                if (grabar) {
                    guardar();
                }
            }
        }
    }//GEN-LAST:event_JButton_GrabarActionPerformed
    
    private void guardar()
    {
      Controlador_Operario _controlador = Funciones.crearControlador_Operario();
      int Resultado = (_controlador.guardarCambioClave(Funciones.UsuarioConectado,Integer.parseInt(String.valueOf(JPasswordField_Clave.getPassword()).trim()), Integer.parseInt(String.valueOf(JPasswordField_ClaveNueva.getPassword()).trim())));
        switch (Resultado) {
            case 0:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, WIDTH);
                break;
            case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje3, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
            default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
        }      
        dispose();
    }

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
      Funciones.limpiar(rootPane);
      JPasswordField_Clave.requestFocus();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
      dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

    private void JPasswordField_ClaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ClaveKeyPressed

    private void JPasswordField_ClaveNuevaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveNuevaKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ClaveNuevaKeyPressed

    private void JPasswordField_ConfirmarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ConfirmarKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ConfirmarKeyPressed

    private void JPasswordField_ClaveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_Clave.getPassword().length;
        if (longitud > 0)
        {
          Funciones.controlarLongitud(6, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ClaveKeyTyped

    private void JPasswordField_ClaveNuevaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveNuevaKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_ClaveNueva.getPassword().length;
        if (longitud > 0)
        {
          Funciones.controlarLongitud(6, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ClaveNuevaKeyTyped

    private void JPasswordField_ConfirmarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ConfirmarKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_Confirmar.getPassword().length;
        if (longitud > 0)
        {
          Funciones.controlarLongitud(6, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ConfirmarKeyTyped
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private javax.swing.JPasswordField JPasswordField_Clave;
    private javax.swing.JPasswordField JPasswordField_ClaveNueva;
    private javax.swing.JPasswordField JPasswordField_Confirmar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
