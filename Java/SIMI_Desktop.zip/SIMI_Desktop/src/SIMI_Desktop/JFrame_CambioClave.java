package SIMI_Desktop;

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bo.Operario;
import javax.swing.JOptionPane;

public class JFrame_CambioClave extends javax.swing.JFrame {

    boolean grabar;  
    Operario operario;
    
    public JFrame_CambioClave() {
        initComponents();            
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        JPasswordField_Clave = new javax.swing.JPasswordField();
        JPasswordField_ClaveNueva = new javax.swing.JPasswordField();
        JPasswordField_Confirmar = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cambio Clave");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/EDITAR.jpg"))); // NOI18N
        JButton_Grabar.setText("Modificar");
        JButton_Grabar.setToolTipText("");
        JButton_Grabar.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(JButton_Grabar)
                .addGap(2, 2, 2)
                .addComponent(JButton_Cancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JButton_Salir, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {JButton_Cancelar, JButton_Grabar, JButton_Salir});

        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JButton_Cancelar)
                    .addComponent(JButton_Salir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(JButton_Grabar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel4Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {JButton_Cancelar, JButton_Grabar, JButton_Salir});

        jLabel1.setText("Clave Actual");

        jLabel6.setText("Clave Nueva");

        jLabel7.setText("Confirmar");

        JPasswordField_Clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ClaveActionPerformed(evt);
            }
        });
        JPasswordField_Clave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyTyped(evt);
            }
        });

        JPasswordField_ClaveNueva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ClaveNuevaActionPerformed(evt);
            }
        });
        JPasswordField_ClaveNueva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveNuevaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveNuevaKeyTyped(evt);
            }
        });

        JPasswordField_Confirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ConfirmarActionPerformed(evt);
            }
        });
        JPasswordField_Confirmar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ConfirmarKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ConfirmarKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(JPasswordField_Clave, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                            .addComponent(JPasswordField_ClaveNueva, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JPasswordField_Confirmar, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(145, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JPasswordField_Clave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JPasswordField_ClaveNueva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JPasswordField_Confirmar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(19, 19, 19)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(449, 270));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JPasswordField_ClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_Clave.getPassword())))
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else if (JPasswordField_Clave.getPassword().length != 6) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else {
            JPasswordField_ClaveNueva.requestFocus();
        }

    }//GEN-LAST:event_JPasswordField_ClaveActionPerformed

    private void JPasswordField_ClaveNuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveNuevaActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_ClaveNueva.getPassword())))
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_ClaveNueva.requestFocus();
        } else if (JPasswordField_ClaveNueva.getPassword().length != 6 ) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_ClaveNueva.requestFocus();
        }else if  (String.valueOf(JPasswordField_Clave.getPassword()).equals(String.valueOf(JPasswordField_ClaveNueva.getPassword()))) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje4, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_ClaveNueva.requestFocus();
        } else {
            JPasswordField_Confirmar.requestFocus();
        }
    }//GEN-LAST:event_JPasswordField_ClaveNuevaActionPerformed

    private void JPasswordField_ConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ConfirmarActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_Confirmar.getPassword())))
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Confirmar.requestFocus();
        } else if (JPasswordField_Confirmar.getPassword().length !=  6 ) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Confirmar.requestFocus();
        }else   if (!String.valueOf(JPasswordField_Confirmar.getPassword()).equals(String.valueOf(JPasswordField_ClaveNueva.getPassword())))         {   
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje5, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Confirmar.requestFocus();
        } else {
            JButton_Grabar.requestFocus();
        }
    }//GEN-LAST:event_JPasswordField_ConfirmarActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        JPasswordField_ClaveActionPerformed(evt); // Revisar Clave Actual
        if (grabar) {
            JPasswordField_ClaveNuevaActionPerformed(evt); // Revisar Nueva Clave
            if (grabar) {
                JPasswordField_ConfirmarActionPerformed(evt); // Confirmar Clave
                if (grabar) {
                    guardar();
                }
            }
        }
    }//GEN-LAST:event_JButton_GrabarActionPerformed
    
    private void guardar()
    {
      Controlador_Operario _controlador = Funciones.crearControlador_Operario();
      int Resultado = (_controlador.guardarCambioClave(Funciones.UsuarioConectado,Integer.parseInt(String.valueOf(JPasswordField_Clave.getPassword()).trim()), Integer.parseInt(String.valueOf(JPasswordField_ClaveNueva.getPassword()).trim())));
        switch (Resultado) {
            case 0:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, WIDTH);
                break;
            case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje3, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
            default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
        }      
        dispose();
    }

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
      Funciones.limpiar(rootPane);
      JPasswordField_Clave.requestFocus();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
      dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

    private void JPasswordField_ClaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ClaveKeyPressed

    private void JPasswordField_ClaveNuevaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveNuevaKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ClaveNuevaKeyPressed

    private void JPasswordField_ConfirmarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ConfirmarKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ConfirmarKeyPressed

    private void JPasswordField_ClaveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_Clave.getPassword().length;
        if (longitud > 0)
        {
          Funciones.controlarLongitud(5, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ClaveKeyTyped

    private void JPasswordField_ClaveNuevaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveNuevaKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_ClaveNueva.getPassword().length;
        if (longitud > 0)
        {
          Funciones.controlarLongitud(5, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ClaveNuevaKeyTyped

    private void JPasswordField_ConfirmarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ConfirmarKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_Confirmar.getPassword().length;
        if (longitud > 0)
        {
          Funciones.controlarLongitud(5, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ConfirmarKeyTyped
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private javax.swing.JPasswordField JPasswordField_Clave;
    private javax.swing.JPasswordField JPasswordField_ClaveNueva;
    private javax.swing.JPasswordField JPasswordField_Confirmar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
