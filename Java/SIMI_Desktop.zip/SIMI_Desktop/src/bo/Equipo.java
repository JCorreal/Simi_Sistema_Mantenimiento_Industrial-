package bo; // Clase que representa la estructura en BD para Equipos

public class Equipo {
 
  private int     equipo_id = 0;
  private String  nombre_equipo;
  private int     marca;
  private String  serie;
  private int     linea;
  private int     lubricacion;
  
  public Equipo(){}

    public int getEquipo_id() {
        return equipo_id;
    }

    public void setEquipo_id(int equipo_id) {
        this.equipo_id = equipo_id;
    }

    public String getNombre_equipo() {
        return nombre_equipo;
    }

    public void setNombre_equipo(String nombre_equipo) {
        this.nombre_equipo = nombre_equipo;
    }

    public int getMarca() {
        return marca;
    }

    public void setMarca(int marca) {
        this.marca = marca;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public int getLinea() {
        return linea;
    }

    public void setLinea(int linea) {
        this.linea = linea;
    }

    public int getLubricacion() {
        return lubricacion;
    }

    public void setLubricacion(int lubricacion) {
        this.lubricacion = lubricacion;
    }

  
}
