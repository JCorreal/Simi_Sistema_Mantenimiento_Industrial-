package bo; // Clase que representa la estructura en BD para control de Mantenimiento

import java.util.Date;

public class Mantenimiento {
   
    private int     mantenimiento_id =0;
    private int     operario_id;
    private int     equipo_id;
    private Date    fecha         = null;
    private String  observaciones = null;
    
    public Mantenimiento() {}

    public int getMantenimiento_id() {
        return mantenimiento_id;
    }

    public void setMantenimiento_id(int mantenimiento_id) {
        this.mantenimiento_id = mantenimiento_id;
    }

    public int getOperario_id() {
        return operario_id;
    }

    public void setOperario_id(int operario_id) {
        this.operario_id = operario_id;
    }

    public int getEquipo_id() {
        return equipo_id;
    }

    public void setEquipo_id(int equipo_id) {
        this.equipo_id = equipo_id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

        
    
}
