package simi_desktop;

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bo.Operario;
import javax.swing.JOptionPane;

public class JFrame_Acceso extends javax.swing.JFrame  {

    Operario operario;
    boolean  ingresar;    
    int      contadorIntentos;
    
    public JFrame_Acceso() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        JTextField_Documento.setText("123456");
        JPasswordField_Clave.setText("123456");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        JTextField_Documento = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        JPasswordField_Clave = new javax.swing.JPasswordField();
        JButton_Aceptar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 240, 420, 190));

        jLabel2.setText("Documento");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 270, -1, -1));

        JTextField_Documento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_DocumentoActionPerformed(evt);
            }
        });
        JTextField_Documento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JTextField_DocumentoAnularPegado(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTextField_DocumentoValidar_SoloNumeros(evt);
            }
        });
        getContentPane().add(JTextField_Documento, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 270, 90, -1));

        jLabel3.setText("Clave");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 310, -1, -1));

        JPasswordField_Clave.setToolTipText("");
        JPasswordField_Clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordField_ClaveActionPerformed(evt);
            }
        });
        JPasswordField_Clave.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JPasswordField_ClaveKeyTyped(evt);
            }
        });
        getContentPane().add(JPasswordField_Clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 310, 50, 20));

        JButton_Aceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/SECUR05.jpg"))); // NOI18N
        JButton_Aceptar.setText("Aceptar");
        JButton_Aceptar.setPreferredSize(new java.awt.Dimension(98, 25));
        JButton_Aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AceptarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Aceptar, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 360, 120, 30));

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.setPreferredSize(new java.awt.Dimension(98, 25));
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 360, 120, 30));

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoclave.jpg"))); // NOI18N
        jLabel6.setText("Acceso ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(326, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 190, 420, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
             Funciones.limpiar(rootPane);
             JTextField_Documento.requestFocus();            
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_AceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AceptarActionPerformed
        Intentos(); // Incrementar contador de intentos de acceso
        ingresar = true;
        JTextField_DocumentoActionPerformed(evt); // Revisar Documento
        if (ingresar)
        {
            JPasswordField_ClaveActionPerformed(evt); // Revisar Clave
            if (ingresar)
            {
                Controlador_Operario _controlador = Funciones.crearControlador_Operario();
                operario = (Operario) _controlador.obtenerAcceso(JTextField_Documento.getText(),  Integer.parseInt(String.valueOf(JPasswordField_Clave.getPassword()).trim()));
                if (operario != null)
                {
                    Funciones.UsuarioConectado = operario.getOperario_Id();
                    Funciones.PerfilAcceso = operario.getPerfil();
                    Funciones.NombreUsuario = operario.getNombres() + ' ' + operario.getApellidos();
                    dispose(); // Descargar Formulario Acceso e invocar Menú Principal
                    JFrame_Menu oforma = new JFrame_Menu();
                    oforma.setVisible(true);
                }
                else
                {
                    JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje2, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
                    JPasswordField_Clave.requestFocus();
                }
            }
        }
    }//GEN-LAST:event_JButton_AceptarActionPerformed

    private void JTextField_DocumentoValidar_SoloNumeros(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTextField_DocumentoValidar_SoloNumeros
        Funciones.validar_SoloNumeros(evt);
    }//GEN-LAST:event_JTextField_DocumentoValidar_SoloNumeros

    private void JTextField_DocumentoAnularPegado(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTextField_DocumentoAnularPegado
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JTextField_DocumentoAnularPegado

    private void JTextField_DocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_DocumentoActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Documento.getText())) // Validar Campo en blanco
        {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Documento.requestFocus();
        } else if (JTextField_Documento.getText().length()<6 || JTextField_Documento.getText().length()>10) {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje15, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Documento.requestFocus();
        } else {
            JPasswordField_Clave.requestFocus();
        }
    }//GEN-LAST:event_JTextField_DocumentoActionPerformed

    private void JPasswordField_ClaveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyTyped
        Funciones.validar_SoloNumeros(evt);
        int longitud = JPasswordField_Clave.getPassword().length;
        if (longitud > 0)
        {
            Funciones.controlarLongitud(6, longitud, evt);
        }
    }//GEN-LAST:event_JPasswordField_ClaveKeyTyped

    private void JPasswordField_ClaveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveKeyPressed
        Funciones.anularPegado(evt);
    }//GEN-LAST:event_JPasswordField_ClaveKeyPressed

    private void JPasswordField_ClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordField_ClaveActionPerformed
        if (Funciones.validar_CampoVacio(String.valueOf(JPasswordField_Clave.getPassword())))
        {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else if (JPasswordField_Clave.getPassword().length != 6  ) {
            ingresar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje21, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JPasswordField_Clave.requestFocus();
        } else {
            JButton_Aceptar.requestFocus();
        }
    }//GEN-LAST:event_JPasswordField_ClaveActionPerformed
          
    

    private void Validar_SoloNumeros(java.awt.event.KeyEvent evt) {                                     
        Funciones.validar_SoloNumeros(evt);
    }    
    
    private void Intentos() {
       contadorIntentos = (contadorIntentos + 1);
       if (contadorIntentos == 3)
       {
          System.exit(0); // Usuario desconocido luego de 3 intentos, finalizar
       }
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Aceptar;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JPasswordField JPasswordField_Clave;
    private javax.swing.JTextField JTextField_Documento;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables

    
}
