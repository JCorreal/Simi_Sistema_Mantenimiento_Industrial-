package simi_desktop;

import bll.Controlador_Equipo;
import bll.Controlador_ListaValores;
import bll.Controlador_Mantenimiento;
import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bo.CargarListado; 
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
 
public class JFrame_Listados extends javax.swing.JFrame {
    String col_Operarios[] = {"OPERARIO_ID","DOCUMENTO","NOMBRE_COMPLETO","TELEFONO","CORREO"};       
    String col_Equipos[] = {"EQUIPO_ID","SERIE","NOMBRE_EQUIPO","MARCA","LINEA","LUBRICACION"};  
    String col_Mantenimiento[] = {"MANTENIMIENTO_ID","SERIE","NOMBRE_EQUIPO","FECHA","OPERARIO"};  
    String col_Marcas[] = {"LISTAVALORES_ID","NOMBRE","DESCRIPCION","TIPO"};  
    String encabezados[];
    ArrayList<CargarListado> lista;
    String source=null;
    
    public JFrame_Listados(String listar) {
        initComponents();
        source = listar;
        this.setExtendedState(MAXIMIZED_BOTH);
        traerDatos(listar);        
    }

    private void traerDatos(String listar)
    {
     jLabel_Titulo.setText("Listado " + listar);   
     switch (listar) {
            case "Operarios":
                 encabezados = col_Operarios;
                 Controlador_Operario _controlador = Funciones.crearControlador_Operario();
                 lista  = _controlador.cargarListado(); 
                 break;
            case "Equipos":                 
                 jLabel_Buscar.setText("Equipo se busca por Serie");
                 encabezados = col_Equipos;
                 Controlador_Equipo _controladore = Funciones.crearControlador_Equipo();
                 lista  = _controladore.cargarListado(); 
                 break;
            case "Mantenimiento":
                 jLabel_Buscar.setText("Mantenimiento se busca por Serie de Equipo");
                 encabezados = col_Mantenimiento;
                 Controlador_Mantenimiento _controladormt = Funciones.crearControlador_Mantenimiento();
                 lista  = _controladormt.cargarListado(); 
                 break;
            case "Marcas":
                 jLabel_Buscar.setText("Marca se busca por su Nombre");
                 encabezados = col_Marcas;
                 Controlador_ListaValores _controladorlm = Funciones.crearControlador_ListaValores();                
                 lista  = _controladorlm.cargarListado("MARCAS"); 
                 break;    
            default:
                 jLabel_Buscar.setText("Linea se busca por su Nombre");
                 encabezados = col_Marcas;
                 Controlador_ListaValores _controladorll = Funciones.crearControlador_ListaValores();                  
                 lista  = _controladorll.cargarListado("LINEAS"); 
                 break;   
        }
     cargarLista();
    }
    
    private void cargarLista()
    {               
        try {
              DefaultTableModel modelo = new DefaultTableModel(encabezados,0);
             
                for (int j = 0; j < lista.size(); j++)
                {
                  Object[] filas = new Object[6];                 
                  filas[0] = lista.get(j).getColumna1();
                  filas[1] = lista.get(j).getColumna2();
                  filas[2] = lista.get(j).getColumna3();
                  filas[3] = lista.get(j).getColumna4();
                  filas[4] = lista.get(j).getColumna5();
                  filas[5] = lista.get(j).getColumna6();
                  modelo.addRow(filas); 
                }
             
            jTableListado.setModel(modelo);
            // Ocultar Columna ID
            jTableListado.getColumnModel().getColumn(0).setMaxWidth(0);
            jTableListado.getColumnModel().getColumn(0).setMinWidth(0);
            jTableListado.getTableHeader().getColumnModel().getColumn(0).setMaxWidth(0);
            jTableListado.getTableHeader().getColumnModel().getColumn(0).setMinWidth(0);
 
        } catch (Exception ex) {
            System.err.println(ex.toString());
        }        
    }
    
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableListado = new javax.swing.JTable();
        jButton_Buscar = new javax.swing.JButton();
        jButton_Nuevo = new javax.swing.JButton();
        jTextField_Buscar = new javax.swing.JTextField();
        jButton_Menu = new javax.swing.JButton();
        jLabel_Buscar = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel_Titulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTableListado.setToolTipText("Hacer click sobre el registro deseado para actualizar");
        jTableListado.setName(""); // NOI18N
        jTableListado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableListadoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableListado);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 220, 580, -1));

        jButton_Buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Consulta.jpg"))); // NOI18N
        jButton_Buscar.setText("Buscar");
        jButton_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BuscarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 130, -1, -1));

        jButton_Nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Nuevo.png"))); // NOI18N
        jButton_Nuevo.setText("Nuevo");
        jButton_Nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_NuevoActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Nuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(523, 130, 100, -1));
        getContentPane().add(jTextField_Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 130, 170, 30));

        jButton_Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/casa.jpg"))); // NOI18N
        jButton_Menu.setText("Menú Principal");
        jButton_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_MenuActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, 30));

        jLabel_Buscar.setFont(new java.awt.Font("Arial", 2, 11)); // NOI18N
        jLabel_Buscar.setForeground(new java.awt.Color(0, 153, 153));
        jLabel_Buscar.setText("Operario se busca por Documento");
        getContentPane().add(jLabel_Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 110, -1, -1));

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel_Titulo.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel_Titulo.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_Titulo.setText("Listado Operarios");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(219, 219, 219)
                .addComponent(jLabel_Titulo)
                .addContainerGap(257, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(jLabel_Titulo)
                .addContainerGap())
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, 580, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_NuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_NuevoActionPerformed
       Funciones.ParametroBuscar =0;
       llamarFormulario();
    }//GEN-LAST:event_jButton_NuevoActionPerformed

    private void jButton_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BuscarActionPerformed
      String cadena = jTextField_Buscar.getText().trim();
      if (!"".equals(cadena))
      {
          if (!source.equals("Operarios"))
          {
               cadena = cadena.toUpperCase();
          }                  
        
         for (int i = 0; i < jTableListado.getRowCount(); i++)
         {
            if(jTableListado.getValueAt(i, 1).toString().equals(cadena))
            {
              jTableListado.changeSelection(i, 1, false, false);
              break;
            }
         }
      }
    }//GEN-LAST:event_jButton_BuscarActionPerformed

    private void jTableListadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableListadoMouseClicked
       Funciones.ParametroBuscar = Integer.parseInt(jTableListado.getValueAt(jTableListado.getSelectedRow(), 0).toString());
       if (Funciones.ParametroBuscar != 0)
       {        
           llamarFormulario();
       }
    }//GEN-LAST:event_jTableListadoMouseClicked

    private void llamarFormulario()
    {        
     this.dispose();   
     switch (source) {
                case "Operarios":
                    {                       
                        JFrame_Operarios oforma = new JFrame_Operarios();                        
                        oforma.setVisible(true);
                        break;
                    }
                case "Equipos":
                    {   
                        Funciones.Lista1 = new ArrayList();
                        Funciones.Lista2 = new ArrayList();
                        ArrayList arlListado = new ArrayList();
                        Controlador_Equipo _controladore = Funciones.crearControlador_Equipo();
                        arlListado = _controladore.cargarCombosEM("CONTROLEQUIPOS");
                        
                        for (int i = 0; i < arlListado.size(); i++)
                        {
                            if ("MARCAS".equals(arlListado.get(i)))
                            {  
                             i++;
                             Funciones.Lista1.add(arlListado.get(i).toString());
                             i++;
                             Funciones.Lista1.add(arlListado.get(i).toString());
                            }
                            else // Lineas
                            {
                             i++;
                             Funciones.Lista2.add(arlListado.get(i).toString());
                             i++;
                             Funciones.Lista2.add(arlListado.get(i).toString());
                            }
                         }
                        
                        if (Funciones.Lista1.isEmpty())
                        {
                          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje11, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);         
                          Funciones.Lista1.clear();
                          Funciones.Lista2.clear();
                        }
                        else if (Funciones.Lista2.isEmpty())
                        {
                          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje12, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);         
                          Funciones.Lista1.clear();
                          Funciones.Lista2.clear();
                        }
                        else
                        {
                            JFrame_Equipos oforma = new JFrame_Equipos();                     
                            oforma.setVisible(true);                            
                        }
                        break; 
                    }
                case "Mantenimiento":
                    {     
                        Funciones.Lista1 = new ArrayList();
                        Funciones.Lista2 = new ArrayList();
                        ArrayList arlListado = new ArrayList();
                        Controlador_Mantenimiento _controladormt = Funciones.crearControlador_Mantenimiento();
                        if (Funciones.ParametroBuscar == 0)
                        {
                            arlListado = _controladormt.cargarCombosEM("PROGRAMAR");
                        }
                        else
                        {
                            arlListado = _controladormt.cargarCombosEM("PROGRAMACION");  
                        }
                        
                        for (int i = 0; i < arlListado.size(); i++)
                        {
                            if ("EQUIPOS".equals(arlListado.get(i)))
                            {  
                             i++;
                             Funciones.Lista1.add(arlListado.get(i).toString());
                             i++;
                             Funciones.Lista1.add(arlListado.get(i).toString());
                            }
                            else // Operarios
                            {
                             i++;
                             Funciones.Lista2.add(arlListado.get(i).toString());
                             i++;
                             Funciones.Lista2.add(arlListado.get(i).toString());
                            }                         
                        }
                        if (Funciones.Lista1.isEmpty())
                        {
                          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje14, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);         
                          Funciones.Lista1.clear();
                          Funciones.Lista2.clear();
                        }
                        else if (Funciones.Lista2.isEmpty())
                        {
                          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje13, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);         
                          Funciones.Lista1.clear();
                          Funciones.Lista2.clear();
                        }
                        else
                        {
                            JFrame_Mantenimiento oforma  = new JFrame_Mantenimiento();  
                            oforma.setVisible(true);    
                        }     
                        break;
                    }
                case "Marcas":
                    {                                 
                        Funciones.ValorTipo = "MARCAS";                      
                        JFrame_ListaValores oforma  = new JFrame_ListaValores();
                        oforma.setTitle(Funciones.ValorTipo);                      
                        oforma.setVisible(true);
                        break;
                    }
                default:
                    {                        
                        Funciones.ValorTipo = "LINEAS";
                        JFrame_ListaValores oforma  = new JFrame_ListaValores();
                        oforma.setTitle(Funciones.ValorTipo);                     
                        oforma.setVisible(true);
                        break;
                    }
            }  
    }
    
      
    private void jButton_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_MenuActionPerformed
        dispose();
    }//GEN-LAST:event_jButton_MenuActionPerformed
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Buscar;
    private javax.swing.JButton jButton_Menu;
    private javax.swing.JButton jButton_Nuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel_Buscar;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableListado;
    private javax.swing.JTextField jTextField_Buscar;
    // End of variables declaration//GEN-END:variables
}
