package simi_desktop;

import bll.Controlador_Operario;
import bll.Funciones;
import bll.Mensajes;
import bo.Operario;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class JFrame_Operarios extends javax.swing.JFrame {
    private final Controlador_Operario _controlador = Funciones.crearControlador_Operario();
    boolean grabar;  
    Operario operario;
    String rutaFoto = null;  
   
    public JFrame_Operarios()
    {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH); 
        if (Funciones.ParametroBuscar != 0)
        {
           consultarBD();
        }
    }
    
    private void consultarBD()
    {
      operario = (Operario) _controlador.obtenerOperario(Funciones.ParametroBuscar);      
      if (operario != null)
      {         
         poblarFormulario();
      }
    }        
      
    private void poblarFormulario() // Volcar Información desde BD sobre el formulario
    {                            
           JtextField_Documento.setText(operario.getDocumento());
           JtextField_Nombres.setText(operario.getNombres());
           JtextField_Apellidos.setText(operario.getApellidos());   
           JtextField_Telefono.setText(operario.getTelefono());
           JtextField_Correo.setText(operario.getCorreo());
           rutaFoto = operario.getFoto();
           if ((!"".equals(operario.getFoto())) && (operario.getFoto() != null))   
           {  
             File file = new File(System.getProperty("user.dir")+ "/src/Fotos_Operarios/" +operario.getFoto());
             if (file.canRead())
             {
               JLabel_Foto.setIcon(new ImageIcon(System.getProperty("user.dir")+ "/src/Fotos_Operarios/" + operario.getFoto()));             
             }
             else
             {
                 JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje24, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);                  
             }
           }           
           JtextField_Documento.setEditable(false);       
           if (Funciones.PerfilAcceso == 1)
           {
               JButton_Eliminar.setEnabled(true);
           }          
           JtextField_Nombres.requestFocus();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        JLabel_Foto = new javax.swing.JLabel();
        JLabel_BorrarFoto = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        JtextField_Telefono = new javax.swing.JTextField();
        JtextField_Apellidos = new javax.swing.JTextField();
        JtextField_Nombres = new javax.swing.JTextField();
        JtextField_Documento = new javax.swing.JTextField();
        JtextField_Correo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Eliminar = new javax.swing.JButton();
        JButton_Ayuda = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Operarios");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        JLabel_Foto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JLabel_Foto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLabel_FotoMouseClicked(evt);
            }
        });
        getContentPane().add(JLabel_Foto, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 200, 180, 200));

        JLabel_BorrarFoto.setText("Borrar Foto");
        JLabel_BorrarFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JLabel_BorrarFoto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLabel_BorrarFotoMouseClicked(evt);
            }
        });
        getContentPane().add(JLabel_BorrarFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 410, -1, -1));

        jLabel1.setText("Documento");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 220, -1, -1));

        jLabel2.setText("Nombres");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, -1, 20));

        jLabel3.setText("Apellidos");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 300, -1, -1));

        jLabel4.setText("Telefono");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 340, -1, -1));

        JtextField_Telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtextField_TelefonoActionPerformed(evt);
            }
        });
        JtextField_Telefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AnularPegado(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Validar_SoloNumeros(evt);
            }
        });
        getContentPane().add(JtextField_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, 86, -1));

        JtextField_Apellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtextField_ApellidosActionPerformed(evt);
            }
        });
        JtextField_Apellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AnularPegado(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Validar_SoloLetras(evt);
            }
        });
        getContentPane().add(JtextField_Apellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 300, 184, -1));

        JtextField_Nombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtextField_NombresActionPerformed(evt);
            }
        });
        JtextField_Nombres.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AnularPegado(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Validar_SoloLetras(evt);
            }
        });
        getContentPane().add(JtextField_Nombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 260, 184, -1));

        JtextField_Documento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtextField_DocumentoActionPerformed(evt);
            }
        });
        JtextField_Documento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                AnularPegado(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                Validar_SoloNumeros(evt);
            }
        });
        getContentPane().add(JtextField_Documento, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 220, 71, -1));

        JtextField_Correo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JtextField_CorreoActionPerformed(evt);
            }
        });
        getContentPane().add(JtextField_Correo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 380, 184, -1));

        jLabel5.setText("Correo");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 380, -1, -1));

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/SAVE.jpg"))); // NOI18N
        JButton_Grabar.setText("Grabar");
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Grabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 500, 120, 30));

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 500, 120, 30));

        JButton_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Borrar.jpg"))); // NOI18N
        JButton_Eliminar.setText("Eliminar");
        JButton_Eliminar.setEnabled(false);
        JButton_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EliminarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 500, 120, 30));

        JButton_Ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/HELP.jpg"))); // NOI18N
        JButton_Ayuda.setText("Ayuda");
        JButton_Ayuda.setToolTipText("");
        JButton_Ayuda.setPreferredSize(new java.awt.Dimension(85, 23));
        JButton_Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AyudaActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 500, 120, 30));

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 500, 120, 30));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoequipos.jpg"))); // NOI18N
        jLabel10.setText("Mantenimiento");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(503, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 140, 630, -1));

        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, 630, 360));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        setSize(new java.awt.Dimension(1227, 587));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    private void JtextField_DocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtextField_DocumentoActionPerformed
        if (Funciones.validar_CampoVacio(JtextField_Documento.getText()))    // Validar Campo en blanco
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion ,javax.swing.JOptionPane.ERROR_MESSAGE);
            JtextField_Documento.requestFocus();
        }else if("0".equals(JtextField_Documento.getText().substring(0,1))) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje6, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JtextField_Documento.selectAll();
            JtextField_Documento.requestFocus();         
        } else if ((JtextField_Documento.getText().length()<6) || (JtextField_Documento.getText().length()>10)) {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje15, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JtextField_Documento.selectAll();
            JtextField_Documento.requestFocus();
        } else {
            
            JtextField_Nombres.requestFocus();
        }
        
    }//GEN-LAST:event_JtextField_DocumentoActionPerformed
    
    private void JtextField_NombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtextField_NombresActionPerformed
       if (Funciones.validar_CampoVacio(JtextField_Nombres.getText()))    // Validar Campo en blanco
       {
           grabar = false;
           JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
           JtextField_Nombres.requestFocus();
       }                 
       else
       {  
           JtextField_Nombres.setText(Funciones.eliminarTabulador(JtextField_Nombres.getText(), "1MAY"));
           if (JtextField_Nombres.getText().length()>25)
           {                         
             grabar = false;
             JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
             JtextField_Nombres.requestFocus();          
           }
           JtextField_Apellidos.requestFocus();
       }
    }//GEN-LAST:event_JtextField_NombresActionPerformed

    private void JtextField_ApellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtextField_ApellidosActionPerformed
       if (Funciones.validar_CampoVacio(JtextField_Apellidos.getText()))    // Validar Campo en blanco
       {
           grabar = false;
           JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
           JtextField_Apellidos.requestFocus();
       }                 
       else
       {           
         JtextField_Apellidos.setText(Funciones.eliminarTabulador(JtextField_Apellidos.getText(), "1MAY"));           
         if (JtextField_Apellidos.getText().length()>25)
         {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JtextField_Apellidos.requestFocus();          
         }
         JtextField_Telefono.requestFocus();
       }
    }//GEN-LAST:event_JtextField_ApellidosActionPerformed

    private void JtextField_TelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtextField_TelefonoActionPerformed
       if (Funciones.validar_CampoVacio(JtextField_Telefono.getText()))    // Validar Campo en blanco
       {
          grabar = false;
          JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
          JtextField_Telefono.requestFocus();
       }
       else if("0".equals(JtextField_Telefono.getText().substring(0,1)))
       {
           grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje6, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JtextField_Telefono.selectAll();
            JtextField_Telefono.requestFocus();  
       }       
       else if((JtextField_Telefono.getText().length()!=7) && (JtextField_Telefono.getText().length()!=10))
       {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje17, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JtextField_Telefono.selectAll();
            JtextField_Telefono.requestFocus();
       }
       else
       {
           JtextField_Correo.requestFocus();
       }       
    }//GEN-LAST:event_JtextField_TelefonoActionPerformed

    private void Validar_SoloNumeros(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Validar_SoloNumeros
        Funciones.validar_SoloNumeros(evt);
    }//GEN-LAST:event_Validar_SoloNumeros
            
    private void JtextField_CorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JtextField_CorreoActionPerformed
        if (JtextField_Correo.getText().length()>0) {           
            if (Funciones.validar_Correo(JtextField_Correo.getText())) {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje16, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);               
                JtextField_Correo.selectAll();            
                JtextField_Correo.requestFocus();
            }
            else
            {   
                if (JtextField_Correo.getText().length()>50)
                {
                  grabar = false;
                  JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);               
                  JtextField_Correo.selectAll();
                  JtextField_Correo.requestFocus();           
                }
                else
                {
                  JtextField_Correo.setText(JtextField_Correo.getText().toLowerCase());
                  JButton_Grabar.requestFocus();
                }
            }
        }     
        else
            {                
                JButton_Grabar.requestFocus();
            }
    }//GEN-LAST:event_JtextField_CorreoActionPerformed

    private void Validar_SoloLetras(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Validar_SoloLetras
        Funciones.validar_SoloLetras(evt);
    }//GEN-LAST:event_Validar_SoloLetras

    private void AnularPegado(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AnularPegado
      Funciones.anularPegado(evt);
    }//GEN-LAST:event_AnularPegado

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
        Limpiar();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;       
            JtextField_NombresActionPerformed(evt); // Revisar Nombres
            if (grabar) {
                JtextField_ApellidosActionPerformed(evt); // Revisar Apellidos
                if (grabar) {
                    JtextField_TelefonoActionPerformed(evt); // Revisar Telefono
                    if (grabar) {
                        JtextField_CorreoActionPerformed(evt);// Revisar Correo
                        if (grabar) 
                        {                            
                           if (Funciones.ParametroBuscar == 0)
                           {
                                JtextField_DocumentoActionPerformed(evt); // Revisar Documento
                                if (grabar) 
                                {
                                    guardar(); 
                                }                                
                           }
                           else
                           {
                             guardar();
                           }
                        }
                    }
                }
            }        
    }//GEN-LAST:event_JButton_GrabarActionPerformed

    private void guardar()
    {
        int Resultado; 
        operario = new Operario();
        operario.setOperario_Id(Funciones.ParametroBuscar);
        operario.setDocumento(JtextField_Documento.getText());        
        operario.setNombres(JtextField_Nombres.getText().trim());
        operario.setApellidos(JtextField_Apellidos.getText().trim());
        operario.setTelefono(JtextField_Telefono.getText());
        operario.setCorreo(JtextField_Correo.getText().trim());       
        operario.setFoto(rutaFoto);     
        Resultado = _controlador.guardarOperario(operario);
        if ( Resultado == 0)
        {
            if (Funciones.ParametroBuscar == 0)
            {
              JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, WIDTH); 
              Limpiar();              
            }
            else
            {
              JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, WIDTH); 
              dispose();
            }
        }  
        else if (Resultado == 1)
        {
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje26, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);            
        }
        else
        {
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);            
        }
    }
     
    private void JButton_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EliminarActionPerformed
        int resultado;
        if (JOptionPane.showConfirmDialog(rootPane, Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, JOptionPane.YES_NO_OPTION )==0)
        {         
          resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar);
            switch (resultado) {
                case 0:
                    JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, WIDTH);
                  
                    Limpiar();
                    break;
                case 1:
                    JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje20, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }   
    }//GEN-LAST:event_JButton_EliminarActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
      dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

    private void JLabel_BorrarFotoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLabel_BorrarFotoMouseClicked
      JLabel_Foto.setIcon(new ImageIcon("")); 
      rutaFoto=null;      
    }//GEN-LAST:event_JLabel_BorrarFotoMouseClicked

    private void JButton_AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AyudaActionPerformed
      Funciones.MostrarAyuda();
    }//GEN-LAST:event_JButton_AyudaActionPerformed

    private void JLabel_FotoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLabel_FotoMouseClicked
      try
      {
            JFileChooser fc = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF", "jpg", "gif");
            fc.setFileFilter(filter);
            int returnVal = fc.showOpenDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File archivo = fc.getSelectedFile();
                String Dest = System.getProperty("user.dir")+ "/Fotos_Operarios/"+archivo.getName();
                Path Destino = Paths.get(Dest);
                String orig = archivo.getPath();
                Path Origen = Paths.get(orig);
                if (Funciones.validar_CampoVacio(JtextField_Documento.getText()))  
                {
                    JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje29, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    JLabel_Foto.setIcon(new ImageIcon(archivo.getPath()));
                    Files.copy(Origen, Destino);  
                    String elarchivo = archivo.getName();
                    int i = elarchivo.lastIndexOf('.');
                    String extension = elarchivo.substring(i,elarchivo.length());
                    File oldfile = new File(System.getProperty("user.dir")+ "/Fotos_Operarios/"+archivo.getName());
                    File newfile = new File(System.getProperty("user.dir")+ "/Fotos_Operarios/"+JtextField_Documento.getText() + extension );
                    oldfile.renameTo(newfile);
                    rutaFoto = JtextField_Documento.getText() + extension;
                }
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje19, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_JLabel_FotoMouseClicked

    private void Limpiar()
    {
      if (Funciones.ParametroBuscar == 0)
      {
        Funciones.limpiar(rootPane);
        JLabel_Foto.setIcon(new ImageIcon("")); 
        rutaFoto=null;          
        JtextField_Documento.requestFocus();
      }
      else
      {
         poblarFormulario();
      }
    }
    
    
    
   
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Ayuda;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Eliminar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private javax.swing.JLabel JLabel_BorrarFoto;
    private javax.swing.JLabel JLabel_Foto;
    private javax.swing.JTextField JtextField_Apellidos;
    private javax.swing.JTextField JtextField_Correo;
    private javax.swing.JTextField JtextField_Documento;
    private javax.swing.JTextField JtextField_Nombres;
    private javax.swing.JTextField JtextField_Telefono;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
