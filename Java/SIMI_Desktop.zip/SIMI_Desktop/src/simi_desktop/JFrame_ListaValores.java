package SIMI_Desktop;

import bll.Controlador_ListaValores;
import bll.Funciones;
import bll.Mensajes;
import bo.ListaValores; 
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class JFrame_ListaValores extends javax.swing.JFrame {
    private final Controlador_ListaValores _controlador = Funciones.crearControlador_ListaValores();
    boolean grabar;     
    ListaValores listavalores;
    
    
    public JFrame_ListaValores() {
        initComponents();       
        this.setExtendedState(MAXIMIZED_BOTH); 
        if (Funciones.ValorTipo.equals("LINEAS"))
        { 
          jLabel_Marcas.setVisible(false);
          jLabel_Lineas.setVisible(true);
        }
        else
        { 
          jLabel_Marcas.setVisible(true);
          jLabel_Lineas.setVisible(false);
        }    
    
        if (Funciones.ParametroBuscar != 0) 
        {  
          consultarBD();
        }         
    }
    
    private void consultarBD()
    {
       listavalores = (ListaValores) _controlador.obtenerListaValores(Funciones.ParametroBuscar);
       if (listavalores  != null)
       {     
           poblarFormulario(); 
       }
    }
    private void poblarFormulario()
    { 
       JTextField_Nombre.setText(listavalores.getNombre().trim());
       JTextArea_Descripcion.setText(listavalores.getDescripcion());  
       JButton_Eliminar.setEnabled(true);
       JTextField_Nombre.requestFocus();         
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        JTextField_Nombre = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTextArea_Descripcion = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel_Marcas = new javax.swing.JLabel();
        jLabel_Lineas = new javax.swing.JLabel();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Eliminar = new javax.swing.JButton();
        JButton_Ayuda = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Nombre");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 230, -1, -1));

        JTextField_Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_NombreActionPerformed(evt);
            }
        });
        getContentPane().add(JTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 230, 256, -1));

        JTextArea_Descripcion.setColumns(20);
        JTextArea_Descripcion.setRows(5);
        JTextArea_Descripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JTextArea_DescripcionKeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(JTextArea_Descripcion);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 256, 70));

        jLabel3.setText("Descripción");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 300, -1, -1));

        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 570, 220));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel_Marcas.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel_Marcas.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_Marcas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icomarca.jpg"))); // NOI18N
        jLabel_Marcas.setText("Marcas");
        jPanel4.add(jLabel_Marcas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel_Lineas.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel_Lineas.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_Lineas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icolineas.jpg"))); // NOI18N
        jLabel_Lineas.setText("Lineas");
        jPanel4.add(jLabel_Lineas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 140, 570, 50));

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SAVE.jpg"))); // NOI18N
        JButton_Grabar.setText("Grabar");
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Grabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 370, 107, 29));

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 370, 107, 29));

        JButton_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Borrar.jpg"))); // NOI18N
        JButton_Eliminar.setText("Eliminar");
        JButton_Eliminar.setEnabled(false);
        JButton_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EliminarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 370, 107, -1));

        JButton_Ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/HELP.jpg"))); // NOI18N
        JButton_Ayuda.setText("Ayuda");
        JButton_Ayuda.setToolTipText("");
        JButton_Ayuda.setPreferredSize(new java.awt.Dimension(85, 23));
        JButton_Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AyudaActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 370, 107, 29));

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 370, 107, 29));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        setSize(new java.awt.Dimension(1049, 573));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void guardar()
    {
       int resultado; 
       listavalores = new ListaValores();     
       listavalores.setListavalores_id(Funciones.ParametroBuscar);
       listavalores.setNombre(JTextField_Nombre.getText());
       listavalores.setDescripcion(JTextArea_Descripcion.getText());
       listavalores.setTipo(Funciones.ValorTipo);
       resultado = _controlador.guardarListaValores(listavalores);
       if (resultado == 0)
       {
            if (Funciones.ParametroBuscar == 0)
            {
              JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, WIDTH);     
              Limpiar();
            }
            else
            {
              JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, WIDTH);     
              dispose();
            }  
       }
       else if (resultado == 1)
       {
         JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje8, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
         JTextField_Nombre.requestFocus();     
       }
       else
       {
             JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);            
       }           
    }
        
    private void Limpiar()
    {
      if (Funciones.ParametroBuscar == 0)
      {
        Funciones.limpiar(rootPane);
        JTextArea_Descripcion.setText("");        
        JTextField_Nombre.requestFocus();
      }
      else
      {
       poblarFormulario(); 
      }
    }
    
   
    
    private void JTextField_NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_NombreActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Nombre.getText()))    // Validar Campo en blanco
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Nombre.requestFocus();
        }
        else
        {
            JTextField_Nombre.setText(Funciones.eliminarTabulador(JTextField_Nombre.getText(), "MAY"));
            if (JTextField_Nombre.getText().length()>50)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextField_Nombre.requestFocus();
            }
            else
            {
                JTextArea_Descripcion.requestFocus();                
            }
        }

    }//GEN-LAST:event_JTextField_NombreActionPerformed
      
    private void JTextArea_DescripcionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTextArea_DescripcionKeyTyped
        char a=evt.getKeyChar();
        if (a==KeyEvent.VK_ENTER)
        {
            JButton_Grabar.requestFocus();
        }
    }//GEN-LAST:event_JTextArea_DescripcionKeyTyped

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        if (JTextArea_Descripcion.getText().length()>255)
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextArea_Descripcion.requestFocus();
        }
        else
        {
            JTextField_NombreActionPerformed(evt);
            if (grabar)
            {
              guardar();              
            }
        }
    }//GEN-LAST:event_JButton_GrabarActionPerformed

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
        Limpiar();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EliminarActionPerformed
        int resultado;
        if (JOptionPane.showConfirmDialog(rootPane, Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, JOptionPane.YES_NO_OPTION )==0)
        {
            resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar);
            switch (resultado) {
                case 0:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, WIDTH);
                dispose();
                break;
                case 1:
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje20, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
                default:
                JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                break;
            }
        }
    }//GEN-LAST:event_JButton_EliminarActionPerformed

    private void JButton_AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AyudaActionPerformed
       Funciones.MostrarAyuda();
    }//GEN-LAST:event_JButton_AyudaActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Ayuda;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Eliminar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private javax.swing.JTextArea JTextArea_Descripcion;
    private javax.swing.JTextField JTextField_Nombre;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_Lineas;
    private javax.swing.JLabel jLabel_Marcas;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
