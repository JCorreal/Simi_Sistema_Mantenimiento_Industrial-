package simi_desktop;

import bll.Controlador_Equipo;
import bll.Funciones;
import bll.Mensajes;
import bo.Equipo;
import javax.swing.JOptionPane;

public class JFrame_Equipos extends javax.swing.JFrame {
    private final Controlador_Equipo _controlador = Funciones.crearControlador_Equipo();
        
    boolean grabar;  
    Equipo equipo;
     
    public JFrame_Equipos() {
           initComponents();
           this.setExtendedState(MAXIMIZED_BOTH);           
           JComboBox_CodigoMarca.setVisible(false);
           JComboBox_CodigoLinea.setVisible(false);
      
           Funciones.cargarCombos(JComboBox_CodigoMarca, JComboBox_NombreMarca, Funciones.Lista1);
           Funciones.Lista1.clear();
           Funciones.cargarCombos(JComboBox_CodigoLinea, JComboBox_NombreLinea, Funciones.Lista2);
           Funciones.Lista2.clear();
            if (Funciones.ParametroBuscar != 0)
            {
               consultarBD();
            }                    
    }
        
    private void consultarBD()
    {
      equipo = (Equipo) _controlador.obtenerEquipo(Funciones.ParametroBuscar);     
      if (equipo != null) 
      { 
        poblarFormulario(); 
        JButton_Eliminar.setEnabled(true);
      } 
    }

    private void poblarFormulario()
    {      
            JTextField_Nombre.setText(equipo.getNombre_equipo().trim());  
            JComboBox_NombreMarca.setSelectedIndex(JComboBox_CodigoMarca.getSelectedIndex()); 
            JTextField_Serie.setText(equipo.getSerie().trim());
            JCheckBox_Lubricacion.setSelected((equipo.getLubricacion() == 1));     
            int Position=0;
            for (int i = 0; i < JComboBox_CodigoMarca.getItemCount(); i++)
            {
               JComboBox_CodigoMarca.setSelectedIndex(i);
               if (Integer.parseInt(JComboBox_CodigoMarca.getSelectedItem().toString()) == equipo.getMarca())
               {
                 Position = JComboBox_CodigoMarca.getSelectedIndex();             
                 JComboBox_NombreMarca.setSelectedIndex(Position); 
                break;
               }
            }
            for (int i = 0; i < JComboBox_CodigoLinea.getItemCount(); i++)
            {
               JComboBox_CodigoLinea.setSelectedIndex(i);
               if (Integer.parseInt(JComboBox_CodigoLinea.getSelectedItem().toString()) == equipo.getLinea())
               {
                 Position = JComboBox_CodigoLinea.getSelectedIndex();                
                 JComboBox_NombreLinea.setSelectedIndex(Position); 
                break;
               }
            }        
             
    }
    
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JCheckBox_Lubricacion = new javax.swing.JCheckBox();
        JTextField_Nombre = new javax.swing.JTextField();
        JComboBox_NombreMarca = new javax.swing.JComboBox();
        JTextField_Serie = new javax.swing.JTextField();
        JComboBox_NombreLinea = new javax.swing.JComboBox();
        JComboBox_CodigoLinea = new javax.swing.JComboBox();
        JComboBox_CodigoMarca = new javax.swing.JComboBox();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        JButton_Grabar = new javax.swing.JButton();
        JButton_Cancelar = new javax.swing.JButton();
        JButton_Eliminar = new javax.swing.JButton();
        JButton_Ayuda = new javax.swing.JButton();
        JButton_Salir = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Nombre");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 260, -1, -1));

        jLabel3.setText("Marca");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 290, -1, -1));

        jLabel4.setText("Serie");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 320, -1, -1));

        jLabel5.setText("Linea");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, -1, -1));

        JCheckBox_Lubricacion.setText("Lubricación   ");
        JCheckBox_Lubricacion.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        getContentPane().add(JCheckBox_Lubricacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 380, 130, -1));

        JTextField_Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_NombreActionPerformed(evt);
            }
        });
        getContentPane().add(JTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 260, 256, -1));

        JComboBox_NombreMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreMarcaActionPerformed(evt);
            }
        });
        getContentPane().add(JComboBox_NombreMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 290, 165, -1));

        JTextField_Serie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextField_SerieActionPerformed(evt);
            }
        });
        getContentPane().add(JTextField_Serie, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 320, 108, -1));

        JComboBox_NombreLinea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JComboBox_NombreLineaActionPerformed(evt);
            }
        });
        getContentPane().add(JComboBox_NombreLinea, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 350, 168, -1));

        getContentPane().add(JComboBox_CodigoLinea, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 350, -1, -1));

        getContentPane().add(JComboBox_CodigoMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 290, -1, -1));

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoequipos.jpg"))); // NOI18N
        jLabel10.setText("Equipos");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(515, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 190, 610, -1));

        JButton_Grabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/SAVE.jpg"))); // NOI18N
        JButton_Grabar.setText("Grabar");
        JButton_Grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_GrabarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Grabar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 420, 120, 30));

        JButton_Cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Cancelar.jpg"))); // NOI18N
        JButton_Cancelar.setText("Cancelar");
        JButton_Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_CancelarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 420, 120, 30));

        JButton_Eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Borrar.jpg"))); // NOI18N
        JButton_Eliminar.setText("Eliminar");
        JButton_Eliminar.setEnabled(false);
        JButton_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_EliminarActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 420, 120, 30));

        JButton_Ayuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/HELP.jpg"))); // NOI18N
        JButton_Ayuda.setText("Ayuda");
        JButton_Ayuda.setToolTipText("");
        JButton_Ayuda.setPreferredSize(new java.awt.Dimension(85, 23));
        JButton_Ayuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_AyudaActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Ayuda, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 420, 120, 30));

        JButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Salir.jpg"))); // NOI18N
        JButton_Salir.setText("Salir");
        JButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(JButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 420, 120, 30));

        jLabel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 102)));
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 230, 610, 230));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla.png"))); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        setSize(new java.awt.Dimension(1312, 807));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void guardar()
    {
     int Resultado;   
     equipo = new Equipo();
     equipo.setEquipo_id(Funciones.ParametroBuscar); 
     equipo.setNombre_equipo(JTextField_Nombre.getText().trim());
     equipo.setMarca(Integer.parseInt(JComboBox_CodigoMarca.getSelectedItem().toString()));
     equipo.setSerie(JTextField_Serie.getText().trim());
     equipo.setLinea(Integer.parseInt(JComboBox_CodigoLinea.getSelectedItem().toString()));
     equipo.setLubricacion(JCheckBox_Lubricacion.isSelected() ? 1:0 );   
     
      Resultado = _controlador.guardarEquipo(equipo);
      if (Resultado == 0) 
      {
          if (Funciones.ParametroBuscar == 0)
          {
              JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, WIDTH);     
              Limpiar();
          }
          else
          {
              JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, WIDTH);     
              dispose();
          }                
      }
      else if (Resultado == 1) 
      {
          JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje7, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
          JTextField_Serie.requestFocus();
      }
      else
      {    
         JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
              
      }      
    }

    private void JTextField_NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_NombreActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Nombre.getText()))    // Validar Campo en blanco
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Nombre.requestFocus();
        }
        else
        {
            JTextField_Nombre.setText(Funciones.eliminarTabulador(JTextField_Nombre.getText(), "1MAY"));
            if (JTextField_Nombre.getText().length() > 50)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextField_Nombre.requestFocus();
            }
            else
            {
                JComboBox_NombreMarca.requestFocus();
            }
        }
    }//GEN-LAST:event_JTextField_NombreActionPerformed

    private void JComboBox_NombreMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreMarcaActionPerformed
        JComboBox_CodigoMarca.setSelectedIndex(JComboBox_NombreMarca.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreMarcaActionPerformed

    private void JTextField_SerieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextField_SerieActionPerformed
        if (Funciones.validar_CampoVacio(JTextField_Serie.getText()))    // Validar Campo en blanco
        {
            grabar = false;
            JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
            JTextField_Serie.requestFocus();
        }
        else
        {
            JTextField_Serie.setText(Funciones.eliminarTabulador(JTextField_Serie.getText(), "MAY"));
            if (JTextField_Serie.getText().length()>20)
            {
                grabar = false;
                JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje28, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                JTextField_Serie.requestFocus();
            }
            else
            {
                JComboBox_NombreLinea.requestFocus();
            }            
        }
    }//GEN-LAST:event_JTextField_SerieActionPerformed

    private void JComboBox_NombreLineaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JComboBox_NombreLineaActionPerformed
        JComboBox_CodigoLinea.setSelectedIndex(JComboBox_NombreLinea.getSelectedIndex());
    }//GEN-LAST:event_JComboBox_NombreLineaActionPerformed

    private void JButton_GrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_GrabarActionPerformed
        grabar = true;
        JTextField_NombreActionPerformed(evt);
        if (grabar)
        {
            JTextField_SerieActionPerformed(evt);
            if (grabar)
            {
              guardar();             
            }
        }
    }//GEN-LAST:event_JButton_GrabarActionPerformed

    private void JButton_CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_CancelarActionPerformed
        Limpiar();
    }//GEN-LAST:event_JButton_CancelarActionPerformed

    private void JButton_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_EliminarActionPerformed
        int resultado;
        if (JOptionPane.showConfirmDialog(rootPane, Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, JOptionPane.YES_NO_OPTION )==0)
        {
            resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar);
            switch (resultado) {
                case 0:
                       JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, WIDTH);
                       dispose();
                break;
                case 1:
                       JOptionPane.showMessageDialog(rootPane, Mensajes.Mensaje20, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                       break;
                default:
                        JOptionPane.showMessageDialog(rootPane, Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion,javax.swing.JOptionPane.ERROR_MESSAGE);
                        break;
            }
        }
    }//GEN-LAST:event_JButton_EliminarActionPerformed

    private void JButton_AyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_AyudaActionPerformed
       Funciones.MostrarAyuda();
    }//GEN-LAST:event_JButton_AyudaActionPerformed

    private void JButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JButton_SalirActionPerformed
        Funciones.Lista1.clear();
        Funciones.Lista2.clear();
        dispose();
    }//GEN-LAST:event_JButton_SalirActionPerformed

    private void Limpiar()
    {
      if (Funciones.ParametroBuscar == 0)
      {
        Funciones.limpiar(rootPane);   
        JCheckBox_Lubricacion.setSelected(false);      
        JTextField_Nombre.requestFocus();
      }
      else
      {
        poblarFormulario(); 
      }
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JButton_Ayuda;
    private javax.swing.JButton JButton_Cancelar;
    private javax.swing.JButton JButton_Eliminar;
    private javax.swing.JButton JButton_Grabar;
    private javax.swing.JButton JButton_Salir;
    private javax.swing.JCheckBox JCheckBox_Lubricacion;
    private javax.swing.JComboBox JComboBox_CodigoLinea;
    private javax.swing.JComboBox JComboBox_CodigoMarca;
    private javax.swing.JComboBox JComboBox_NombreLinea;
    private javax.swing.JComboBox JComboBox_NombreMarca;
    private javax.swing.JTextField JTextField_Nombre;
    private javax.swing.JTextField JTextField_Serie;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel4;
    // End of variables declaration//GEN-END:variables
}
