package simi_desktop;

import bll.Funciones;
import java.awt.Color;
import javax.swing.UIManager;


public class JFrame_Menu extends javax.swing.JFrame {
  
    public JFrame_Menu() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        if (Funciones.PerfilAcceso==1)
        {          
           jButton_Equipos.setEnabled(true);
           jButton_Mantenimiento.setEnabled(true);           
           jButton_Marcas.setEnabled(true);
           jButton_Lineas.setEnabled(true);           
        }
        JLabel_UsuarioConectado.setText("Bienvenido: " +" "+ Funciones.NombreUsuario);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Equipos = new javax.swing.JButton();
        jButton_Marcas = new javax.swing.JButton();
        jButton_Lineas = new javax.swing.JButton();
        jButton_Mantenimiento = new javax.swing.JButton();
        jButton_Clave = new javax.swing.JButton();
        jButton_Operarios = new javax.swing.JButton();
        JLabel_UsuarioConectado = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Equipos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoequipos.jpg"))); // NOI18N
        jButton_Equipos.setText("Equipos");
        jButton_Equipos.setEnabled(false);
        jButton_Equipos.setPreferredSize(new java.awt.Dimension(115, 39));
        jButton_Equipos.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton_EquiposMouseMoved(evt);
            }
        });
        jButton_Equipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_EquiposActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Equipos, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, 170, 40));

        jButton_Marcas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icomarca.jpg"))); // NOI18N
        jButton_Marcas.setText("Marcas");
        jButton_Marcas.setEnabled(false);
        jButton_Marcas.setPreferredSize(new java.awt.Dimension(115, 39));
        jButton_Marcas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton_MarcasMouseMoved(evt);
            }
        });
        jButton_Marcas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_MarcasActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Marcas, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 170, 40));

        jButton_Lineas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icolineas.jpg"))); // NOI18N
        jButton_Lineas.setText("Lineas");
        jButton_Lineas.setEnabled(false);
        jButton_Lineas.setPreferredSize(new java.awt.Dimension(115, 39));
        jButton_Lineas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton_LineasMouseMoved(evt);
            }
        });
        jButton_Lineas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_LineasActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Lineas, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, 170, 40));

        jButton_Mantenimiento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icotiempo.jpg"))); // NOI18N
        jButton_Mantenimiento.setText("Mantenimiento");
        jButton_Mantenimiento.setEnabled(false);
        jButton_Mantenimiento.setPreferredSize(new java.awt.Dimension(115, 39));
        jButton_Mantenimiento.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton_MantenimientoMouseMoved(evt);
            }
        });
        jButton_Mantenimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_MantenimientoActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Mantenimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 170, 40));

        jButton_Clave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoclave.jpg"))); // NOI18N
        jButton_Clave.setText("Cambiar Clave");
        jButton_Clave.setPreferredSize(new java.awt.Dimension(115, 39));
        jButton_Clave.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton_ClaveMouseMoved(evt);
            }
        });
        jButton_Clave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ClaveActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Clave, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, 170, 40));

        jButton_Operarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icoperarios.jpg"))); // NOI18N
        jButton_Operarios.setText("Operarios");
        jButton_Operarios.setFocusCycleRoot(true);
        jButton_Operarios.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jButton_OperariosMouseMoved(evt);
            }
        });
        jButton_Operarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_OperariosActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Operarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 170, 40));

        JLabel_UsuarioConectado.setForeground(new java.awt.Color(255, 255, 255));
        JLabel_UsuarioConectado.setText("Bienvenido: ");
        JLabel_UsuarioConectado.setToolTipText("");
        getContentPane().add(JLabel_UsuarioConectado, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Plantilla_Menu.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseMoved
         jButton_Operarios.setBackground(UIManager.getColor("control"));
         jButton_Equipos.setBackground(UIManager.getColor("control"));
         jButton_Marcas.setBackground(UIManager.getColor("control"));
         jButton_Lineas.setBackground(UIManager.getColor("control"));
         jButton_Mantenimiento.setBackground(UIManager.getColor("control"));
         jButton_Clave.setBackground(UIManager.getColor("control"));
    }//GEN-LAST:event_formMouseMoved

    private void jButton_EquiposMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton_EquiposMouseMoved
        jButton_Equipos.setBackground(Color.WHITE);
    }//GEN-LAST:event_jButton_EquiposMouseMoved

    private void jButton_MarcasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton_MarcasMouseMoved
        jButton_Marcas.setBackground(Color.WHITE); 
    }//GEN-LAST:event_jButton_MarcasMouseMoved

    private void jButton_LineasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton_LineasMouseMoved
        jButton_Lineas.setBackground(Color.WHITE); 
    }//GEN-LAST:event_jButton_LineasMouseMoved

    private void jButton_MantenimientoMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton_MantenimientoMouseMoved
       jButton_Mantenimiento.setBackground(Color.WHITE); 
    }//GEN-LAST:event_jButton_MantenimientoMouseMoved

    private void jButton_ClaveMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton_ClaveMouseMoved
        jButton_Clave.setBackground(Color.WHITE); 
    }//GEN-LAST:event_jButton_ClaveMouseMoved

    private void jButton_OperariosMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton_OperariosMouseMoved
        jButton_Operarios.setBackground(Color.WHITE); 
    }//GEN-LAST:event_jButton_OperariosMouseMoved

    private void jButton_OperariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_OperariosActionPerformed
      if (Funciones.PerfilAcceso == 1)
      {
       JFrame_Listados oforma = new JFrame_Listados("Operarios");     
       oforma.setVisible(true);
      }
      else
      {
       Funciones.ParametroBuscar =  Funciones.UsuarioConectado; 
       JFrame_Operarios oforma = new JFrame_Operarios();     
       oforma.setVisible(true);
      }    
    }//GEN-LAST:event_jButton_OperariosActionPerformed

    private void jButton_EquiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_EquiposActionPerformed
       JFrame_Listados oforma = new JFrame_Listados("Equipos");     
       oforma.setVisible(true);
    }//GEN-LAST:event_jButton_EquiposActionPerformed

    private void jButton_MarcasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_MarcasActionPerformed
       JFrame_Listados oforma = new JFrame_Listados("Marcas");     
       oforma.setVisible(true);
    }//GEN-LAST:event_jButton_MarcasActionPerformed

    private void jButton_LineasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_LineasActionPerformed
       JFrame_Listados oforma = new JFrame_Listados("Lineas");     
       oforma.setVisible(true);
    }//GEN-LAST:event_jButton_LineasActionPerformed

    private void jButton_MantenimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_MantenimientoActionPerformed
        JFrame_Listados oforma = new JFrame_Listados("Mantenimiento");     
        oforma.setVisible(true);
    }//GEN-LAST:event_jButton_MantenimientoActionPerformed

    private void jButton_ClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ClaveActionPerformed
       JFrame_CambioClave oforma  = new JFrame_CambioClave();      
       oforma.setVisible(true); 
    }//GEN-LAST:event_jButton_ClaveActionPerformed

   
 
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel_UsuarioConectado;
    private javax.swing.JButton jButton_Clave;
    private javax.swing.JButton jButton_Equipos;
    private javax.swing.JButton jButton_Lineas;
    private javax.swing.JButton jButton_Mantenimiento;
    private javax.swing.JButton jButton_Marcas;
    private javax.swing.JButton jButton_Operarios;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
