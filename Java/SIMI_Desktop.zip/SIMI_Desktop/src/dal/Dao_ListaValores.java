package dal; // Capa Acceso Datos para Marcas y Líneas

import bo.CargarListado;
import bo.ListaValores;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao_ListaValores extends Dao_General implements IDao_ListaValores {

     
    @Override
    public synchronized ListaValores obtenerListaValores (int datoBuscar)
    {
        ListaValores listavalores = new ListaValores();
            try
            {
               buscarRegistro("TBL_LISTAVALORES", datoBuscar);
               if (Rset.next ())
               {
                    listavalores.setListavalores_id(Rset.getInt(1));
                    listavalores.setNombre(Rset.getString(2));
                    listavalores.setDescripcion(Rset.getString(3));                   
               }               
               else
               {
                   listavalores = null; 
               }            
               Rset.close(); // Se cierra el ResultSet, aunque no es necesario    
            }
            catch (SQLException  ex)
            {  
                System.out.println("Error : " +ex);
                liberarRecursos();
            }
            catch (Exception  ex)
            {  
                System.out.println("Error : " +ex);
                liberarRecursos();
            }
            finally
            {
	        liberarRecursos();
	    }
            return listavalores;
    }
   
    @Override
    public synchronized int guardarListaValores (ListaValores listavalores, int Usuario) 
    {
        int resultado = -1;
        try 
        {
            con = Conexion.obtenerConexion();           
            cst = con.prepareCall("{call SPR_IU_ListaValores (?, ?, ?, ?, ?, ?)}");                  
            cst.setInt(1, listavalores.getListavalores_id());
            cst.setString(2, listavalores.getNombre());
            cst.setString(3, listavalores.getDescripcion());
            cst.setString(4, listavalores.getTipo());
            cst.setInt(5, Usuario);
            cst.registerOutParameter(6, java.sql.Types.INTEGER);
            cst.executeUpdate();
            resultado = cst.getByte(6);           
        }
        catch (SQLException ex) 
        {
            System.out.println("Error : " +ex);            
        } 
        catch (Exception ex) 
        {
            System.out.println("Error : " +ex);            
        } 
        finally
        {
	    liberarRecursos();
	}
        return resultado;
    }


    @Override
    public synchronized int eliminarRegistro(int datoEliminar)
    {
        int resultado = borrarRegistro("TBL_LISTAVALORES", datoEliminar);
        return resultado;
    }
    
    @Override
    public ArrayList<CargarListado> cargarListado(String tabla, String condicion)
    {
       ArrayList<CargarListado> arlListado=new ArrayList();
       arlListado = cargarListas(tabla, condicion);
       return arlListado; 
    }
}
