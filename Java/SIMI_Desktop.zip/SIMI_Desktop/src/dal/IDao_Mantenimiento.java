package dal; // Interface que expone los métodos que implementa el DAO de Mantenimiento

import bo.Mantenimiento;
import java.util.List;

public interface IDao_Mantenimiento {
  
  public Mantenimiento obtenerMantenimiento(int datoBuscar);
  public int guardarMantenimiento(Mantenimiento mantenimiento, int Usuario);
  public int eliminarRegistro(int datoEliminar);   
  public List cargarEquiposOperarios(String tabla, String combo); 
 

}
