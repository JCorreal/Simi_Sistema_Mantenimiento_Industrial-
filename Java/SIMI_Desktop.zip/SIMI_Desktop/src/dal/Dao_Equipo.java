package dal; // Capa Acceso Datos para Equipos-Maquinaria

import bo.Equipo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao_Equipo extends Dao_General implements IDao_Equipo 
{

    @Override
    public synchronized Equipo obtenerEquipo(int datoBuscar) 
    {
        Equipo equipo = new Equipo();
        try
        {
            buscarRegistro("TBL_EQUIPOS", datoBuscar);
            if (Rset.next ())
            {                
                equipo.setEquipo_id(Rset.getInt(1));
                equipo.setNombre_equipo(Rset.getString(2));
                equipo.setMarca(Rset.getInt(3));
                equipo.setSerie(Rset.getString(4));
                equipo.setLinea(Rset.getInt(5));
                equipo.setLubricacion(Rset.getInt(6));    
            }               
            else
            {
                equipo = null; 
            }            
            Rset.close(); // Se cierra el ResultSet, aunque no es necesario    
        }
        catch (SQLException  e)
        {  
            System.out.println("Error : " +e);
            liberarRecursos();
        }
        catch (Exception  e)
        {  
            System.out.println("Error : " +e);
            liberarRecursos();
        }
        finally
        {
	    liberarRecursos();
	}
        return equipo;     
    }

    @Override
    public synchronized int guardarEquipo(Equipo equipo, int Usuario) 
    {
        int resultado =  -1;
        try
        {
            con = Conexion.obtenerConexion();           
            cst = con.prepareCall("{call SPR_IU_Equipos (?, ?, ?, ?, ?, ?, ?, ?)}");
            cst.setInt(1, equipo.getEquipo_id());
            cst.setString(2, equipo.getNombre_equipo());
            cst.setInt(3, equipo.getMarca());
            cst.setString(4, equipo.getSerie());
            cst.setInt(5, equipo.getLinea());
            cst.setInt(6, equipo.getLubricacion());
            cst.setInt(7, Usuario);
            cst.registerOutParameter(8, java.sql.Types.INTEGER);
            cst.executeUpdate();
            resultado = cst.getByte(8);            
        }
        catch (SQLException ex) 
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }           
        catch (Exception ex)
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }   
        finally
        {
	    liberarRecursos();
	}
        return resultado;
    }

    @Override
    public synchronized List cargarMarcasLineas(String tabla, String combo)
    {
        List listaElementos = new ArrayList();
        listaElementos = cargarCombosListas(tabla, combo);
        return listaElementos;
    }
    
    @Override
    public synchronized int eliminarRegistro(int datoEliminar)
    {
        int resultado = borrarRegistro("TBL_EQUIPOS", datoEliminar);
        return resultado;
    }
}
