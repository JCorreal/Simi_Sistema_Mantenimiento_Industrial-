package dal; // Interface que expone los métodos que implementa el DAO de Equipos

import bo.CargarListado;
import bo.Equipo;
import java.util.ArrayList;
import java.util.List;

public interface IDao_Equipo {
 
  public Equipo obtenerEquipo(int datoBuscar);
  public int guardarEquipo(Equipo equipo, int Usuario);  
  public int eliminarRegistro(int datoEliminar);  
  public List cargarMarcasLineas(String tabla); 
  public ArrayList<CargarListado> cargarListado(String condicion);

}
