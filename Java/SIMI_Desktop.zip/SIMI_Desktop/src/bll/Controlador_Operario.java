package bll; // Este es el Controlador para el registro de Operarios
     
import bo.Operario;
import dal.IDao_Operario;
import java.util.List;

public class Controlador_Operario {
    
    protected IDao_Operario _dao_operario; 
    
    public Controlador_Operario(IDao_Operario dao_operario) {
      _dao_operario = dao_operario;
    }    
    
    public List cargarOperarios() {
        return _dao_operario.cargarOperarios();
    }
    
    public Object obtenerAcceso(String datoBuscar,  int clave) {
        return _dao_operario.obtenerAcceso(datoBuscar, clave);    
    }    
        
    public Object obtenerOperario(int datoBuscar) { 
     return _dao_operario.obtenerOperario(datoBuscar);
    }
    
    public int guardarOperario(Operario operario)
    {
        int status = 0;   
        status = _dao_operario.guardarOperario((Operario) operario, Funciones.UsuarioConectado);
        return status;
    }
    
    public int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva) {
         return _dao_operario.guardarCambioClave(Usuario, claveAnterior, claveNueva);
    }
        
    public int eliminarRegistro(int datoEliminar) {
        return _dao_operario.eliminarRegistro(datoEliminar);
    }
    
}
