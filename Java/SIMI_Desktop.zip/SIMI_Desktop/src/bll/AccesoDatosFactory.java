package bll; 

/*  Aquí emplearemos el patrón de Creación: Factory Method al cual la pasaremos
    como argumento la Interfaz del Object implicado, e invocaremos los métodos:
    CrearControlador_Object alojados en la clase Funciones, que nos devolverá
    el DAO correspondiente ya instanciado.
 
    Este patrón nos ahorra trabajo, puesto que nos libera sobre la forma 
    correcta de crear objetos, dada su flexibilidad al utilizar una clase 
    constructora (al estilo del Abstract Factory). 
 */

import dal.IDao_Operario;
import dal.Dao_Operario;
import dal.IDao_ListaValores;
import dal.Dao_ListaValores;
import dal.IDao_Equipo;
import dal.Dao_Equipo;
import dal.IDao_Mantenimiento;
import dal.Dao_Mantenimiento;

public class AccesoDatosFactory {
      
    public static IDao_Operario obtenerDao_Operario()
    {
     return new Dao_Operario();
    }
    
    public static IDao_Equipo obtenerDao_Equipo()
    {
     return new Dao_Equipo();
    }
    
    public static IDao_ListaValores obtenerDao_ListaValores()
    {
     return new Dao_ListaValores();
    }
    
    public static IDao_Mantenimiento obtenerDao_Mantenimiento()
    {
     return new Dao_Mantenimiento();
    }
    
}
