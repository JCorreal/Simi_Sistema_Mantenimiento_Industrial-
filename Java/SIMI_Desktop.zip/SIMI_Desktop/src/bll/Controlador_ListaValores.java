package bll; // Este es el Controlador para el registro de Marcas y Lineas

import bo.CargarListado;
import bo.ListaValores;
import dal.IDao_ListaValores;
import java.util.ArrayList;

public class Controlador_ListaValores {
    
    protected IDao_ListaValores _dao_listavalores; 
    
    public Controlador_ListaValores(IDao_ListaValores dao_listavalores) {
      _dao_listavalores = dao_listavalores;
    }
    
    public ArrayList<CargarListado> cargarListado(String tabla)
    {
        return _dao_listavalores.cargarListado(tabla);
    }
     
    public Object obtenerListaValores(int datoBuscar) { 
     return _dao_listavalores.obtenerListaValores(datoBuscar);
    }
    
    public int guardarListaValores(ListaValores listavalores) 
    {
        int status = 0;   
        status = _dao_listavalores.guardarListaValores((ListaValores) listavalores, Funciones.UsuarioConectado);
        return status;
    }
    
    public int eliminarRegistro(int datoEliminar) {
        return _dao_listavalores.eliminarRegistro(datoEliminar);
    }
}
