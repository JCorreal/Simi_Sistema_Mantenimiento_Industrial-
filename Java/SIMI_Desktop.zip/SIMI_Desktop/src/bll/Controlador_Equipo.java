package bll; // Este es el Controlador para el registro de Equipos            
    
import bo.CargarListado;
import bo.Equipo;
import dal.IDao_Equipo;
import java.util.ArrayList;

public class Controlador_Equipo {
    
    protected IDao_Equipo _dao_equipo; 
    
    public Controlador_Equipo(IDao_Equipo dao_equipo)
    {
      _dao_equipo = dao_equipo;
    }
    
    public ArrayList<CargarListado> cargarListado()
    {
        return _dao_equipo.cargarListado();
    }
    
    public Object obtenerEquipo(int datoBuscar) { 
      return _dao_equipo.obtenerEquipo(datoBuscar);
    }
    
    public ArrayList cargarCombosEM(String tabla) {
        return _dao_equipo.cargarMarcasLineas( tabla);
    }
     
    public int guardarEquipo(Equipo equipo) 
    {
        int status = 0;   
        status = _dao_equipo.guardarEquipo((Equipo) equipo, Funciones.UsuarioConectado);
        return status;
    } 
     
    public int eliminarRegistro(int datoEliminar) {
        return _dao_equipo.eliminarRegistro(datoEliminar);
    } 
   
}

