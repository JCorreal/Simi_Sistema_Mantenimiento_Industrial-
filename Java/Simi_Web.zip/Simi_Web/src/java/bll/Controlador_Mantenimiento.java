package bll; // Este es el Controlador para el registro del Mantenimiento

import bo.CargarListado;
import bo.Mantenimiento;
import dal.IDao_Mantenimiento;
import java.util.ArrayList;
import javax.faces.model.SelectItem;

public class Controlador_Mantenimiento {
    
    protected IDao_Mantenimiento _dao_mantenimiento; 
    
    public Controlador_Mantenimiento(IDao_Mantenimiento dao_mantenimiento)
    {
      _dao_mantenimiento = dao_mantenimiento;
    }
    
    public ArrayList<CargarListado> cargarListado(String Condicion)
    {
        return _dao_mantenimiento.cargarListado(Condicion);
    }
    
    public ArrayList<SelectItem> controlarProgramacion(String tabla)
    {
      return  _dao_mantenimiento.controlarProgramacion(tabla);
    }
    
    public Object obtenerMantenimiento(int datoBuscar)
    { 
        return _dao_mantenimiento.obtenerMantenimiento(datoBuscar);
    }
    
    public int guardarMantenimiento(Mantenimiento mantenimiento) 
    {
        int status = 0;   
        status = _dao_mantenimiento.guardarMantenimiento((Mantenimiento) mantenimiento, Funciones.UsuarioConectado);
        return status;
    }

    public int eliminarRegistro(int datoEliminar) 
    {
        return _dao_mantenimiento.eliminarRegistro(datoEliminar);
    }
}
