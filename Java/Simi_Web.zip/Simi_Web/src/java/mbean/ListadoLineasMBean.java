package mbean; // Managed Bean que responde a las acciones del form Listado_Lineas

import bll.Controlador_ListaValores;
import bll.Funciones;
import bll.Mensajes;
import bll.Error;
import bo.CargarListado;
import java.util.ArrayList;

public class ListadoLineasMBean {
    
    private final Controlador_ListaValores _controlador = Funciones.CrearControlador_ListaValores();   
    private ArrayList<CargarListado> listadoGeneral;
    private String datoBuscar = null;
  
    public ListadoLineasMBean()
    {
        Error.ElMensaje = null;      
        if (Funciones.Busqueda != null)
        {
          listadoGeneral = _controlador.CargarListado("LINEAS", Funciones.Busqueda);   
        }
        else
        {
            listadoGeneral = _controlador.CargarListado("LINEAS", null);
        }
    }
 
    public ArrayList<CargarListado> getListadoGeneral() {
        return listadoGeneral;
    }  

    public String getDatoBuscar() {
        return datoBuscar;
    }

    public void setDatoBuscar(String datoBuscar) {
        this.datoBuscar = datoBuscar;
    }
            
    public String buscarInformacion() throws Throwable
    {         
        String respuesta = null; 
        if (datoBuscar != null) 
        {          
            listadoGeneral = _controlador.CargarListado("LINEAS", datoBuscar);
            if (listadoGeneral != null)
            {
               Funciones.Busqueda = datoBuscar;
            }
            respuesta = "Filtro";
        }    
        else
        {
          Error.ElMensaje = Mensajes.Mensaje29; 
          respuesta = "NOSELECCION";
        }
        return respuesta;
    }
   
    public String actualizar(int codigo)
    {    
        Funciones.ParametroBuscar = codigo;
        return "LINEAS"; 
    }
    
    public String nuevoRegistro()
    {                
      Funciones.ParametroBuscar = 0;           
      return "LINEAS";   
    }
    
    public String eliminarRegistro(String codigo)
    {    
        String respuesta = null;
        Error.ElMensaje = null;
        int resultado;                           
        resultado = _controlador.eliminarRegistro(Integer.parseInt(codigo));
        if (resultado == 0)
        {
            Funciones.ParametroBuscar = 0;
            respuesta = "si";
        } 
        else if (resultado == 1)
        {          
             Error.ElMensaje = Mensajes.Mensaje9;    
        }              
        else
        {
          Error.ElMensaje = Mensajes.MensajeErrorBD;             
          respuesta = "no";  
        }            
     
     return respuesta;
    }
 
}
