﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormOperarios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormOperarios))
        Me.lblBorrarFoto = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.TextBoxTelefono = New System.Windows.Forms.TextBox()
        Me.ButtonSalir = New System.Windows.Forms.Button()
        Me.ButtonAyuda = New System.Windows.Forms.Button()
        Me.ButtonEliminar = New System.Windows.Forms.Button()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        Me.ButtonGrabar = New System.Windows.Forms.Button()
        Me.label2 = New System.Windows.Forms.Label()
        Me.PictureBoxFotoUsuario = New System.Windows.Forms.PictureBox()
        Me.TextBoxCorreo = New System.Windows.Forms.TextBox()
        Me.TextBoxApellidos = New System.Windows.Forms.TextBox()
        Me.TextBoxNombres = New System.Windows.Forms.TextBox()
        Me.TextBoxDocumento = New System.Windows.Forms.TextBox()
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.errorPro = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.Label_Titulo = New System.Windows.Forms.Label()
        CType(Me.PictureBoxFotoUsuario, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel2.SuspendLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblBorrarFoto
        '
        Me.lblBorrarFoto.AutoSize = True
        Me.lblBorrarFoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBorrarFoto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBorrarFoto.Location = New System.Drawing.Point(457, 171)
        Me.lblBorrarFoto.Name = "lblBorrarFoto"
        Me.lblBorrarFoto.Size = New System.Drawing.Size(72, 15)
        Me.lblBorrarFoto.TabIndex = 325
        Me.lblBorrarFoto.Text = "Borrar Foto"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.Location = New System.Drawing.Point(113, 196)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(57, 13)
        Me.label5.TabIndex = 285
        Me.label5.Text = "Telefono"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(114, 164)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(44, 13)
        Me.label4.TabIndex = 284
        Me.label4.Text = "Correo"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(114, 132)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(58, 13)
        Me.label3.TabIndex = 283
        Me.label3.Text = "Apellidos"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(114, 68)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(71, 13)
        Me.label1.TabIndex = 281
        Me.label1.Text = "Documento"
        '
        'TextBoxTelefono
        '
        Me.TextBoxTelefono.Location = New System.Drawing.Point(211, 193)
        Me.TextBoxTelefono.MaxLength = 10
        Me.TextBoxTelefono.Name = "TextBoxTelefono"
        Me.TextBoxTelefono.Size = New System.Drawing.Size(72, 20)
        Me.TextBoxTelefono.TabIndex = 4
        Me.TextBoxTelefono.TabStop = False
        '
        'ButtonSalir
        '
        Me.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSalir.ForeColor = System.Drawing.Color.Black
        Me.ButtonSalir.Image = CType(resources.GetObject("ButtonSalir.Image"), System.Drawing.Image)
        Me.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonSalir.Location = New System.Drawing.Point(360, 284)
        Me.ButtonSalir.Name = "ButtonSalir"
        Me.ButtonSalir.Size = New System.Drawing.Size(60, 35)
        Me.ButtonSalir.TabIndex = 11
        Me.ButtonSalir.TabStop = False
        Me.ButtonSalir.Text = "Salir"
        Me.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonSalir.UseVisualStyleBackColor = False
        '
        'ButtonAyuda
        '
        Me.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonAyuda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAyuda.ForeColor = System.Drawing.Color.Black
        Me.ButtonAyuda.Image = CType(resources.GetObject("ButtonAyuda.Image"), System.Drawing.Image)
        Me.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonAyuda.Location = New System.Drawing.Point(303, 284)
        Me.ButtonAyuda.Name = "ButtonAyuda"
        Me.ButtonAyuda.Size = New System.Drawing.Size(60, 35)
        Me.ButtonAyuda.TabIndex = 10
        Me.ButtonAyuda.TabStop = False
        Me.ButtonAyuda.Text = "Ayuda"
        Me.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonAyuda.UseVisualStyleBackColor = False
        '
        'ButtonEliminar
        '
        Me.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonEliminar.Enabled = False
        Me.ButtonEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEliminar.ForeColor = System.Drawing.Color.Black
        Me.ButtonEliminar.Image = CType(resources.GetObject("ButtonEliminar.Image"), System.Drawing.Image)
        Me.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonEliminar.Location = New System.Drawing.Point(245, 284)
        Me.ButtonEliminar.Name = "ButtonEliminar"
        Me.ButtonEliminar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonEliminar.TabIndex = 9
        Me.ButtonEliminar.TabStop = False
        Me.ButtonEliminar.Text = "Eliminar"
        Me.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonEliminar.UseVisualStyleBackColor = False
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCancelar.ForeColor = System.Drawing.Color.Black
        Me.ButtonCancelar.Image = CType(resources.GetObject("ButtonCancelar.Image"), System.Drawing.Image)
        Me.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonCancelar.Location = New System.Drawing.Point(188, 284)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonCancelar.TabIndex = 8
        Me.ButtonCancelar.TabStop = False
        Me.ButtonCancelar.Text = "Cancelar"
        Me.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonCancelar.UseVisualStyleBackColor = False
        '
        'ButtonGrabar
        '
        Me.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonGrabar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGrabar.ForeColor = System.Drawing.Color.Black
        Me.ButtonGrabar.Image = CType(resources.GetObject("ButtonGrabar.Image"), System.Drawing.Image)
        Me.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonGrabar.Location = New System.Drawing.Point(132, 284)
        Me.ButtonGrabar.Name = "ButtonGrabar"
        Me.ButtonGrabar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonGrabar.TabIndex = 7
        Me.ButtonGrabar.TabStop = False
        Me.ButtonGrabar.Text = "Grabar"
        Me.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonGrabar.UseVisualStyleBackColor = False
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(113, 100)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(56, 13)
        Me.label2.TabIndex = 282
        Me.label2.Text = "Nombres"
        '
        'PictureBoxFotoUsuario
        '
        Me.PictureBoxFotoUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxFotoUsuario.Location = New System.Drawing.Point(435, 29)
        Me.PictureBoxFotoUsuario.Name = "PictureBoxFotoUsuario"
        Me.PictureBoxFotoUsuario.Size = New System.Drawing.Size(116, 132)
        Me.PictureBoxFotoUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBoxFotoUsuario.TabIndex = 280
        Me.PictureBoxFotoUsuario.TabStop = False
        '
        'TextBoxCorreo
        '
        Me.TextBoxCorreo.Location = New System.Drawing.Point(211, 161)
        Me.TextBoxCorreo.MaxLength = 50
        Me.TextBoxCorreo.Name = "TextBoxCorreo"
        Me.TextBoxCorreo.Size = New System.Drawing.Size(161, 20)
        Me.TextBoxCorreo.TabIndex = 3
        Me.TextBoxCorreo.TabStop = False
        '
        'TextBoxApellidos
        '
        Me.TextBoxApellidos.Location = New System.Drawing.Point(211, 129)
        Me.TextBoxApellidos.MaxLength = 25
        Me.TextBoxApellidos.Name = "TextBoxApellidos"
        Me.TextBoxApellidos.Size = New System.Drawing.Size(161, 20)
        Me.TextBoxApellidos.TabIndex = 2
        Me.TextBoxApellidos.TabStop = False
        '
        'TextBoxNombres
        '
        Me.TextBoxNombres.Location = New System.Drawing.Point(211, 97)
        Me.TextBoxNombres.MaxLength = 25
        Me.TextBoxNombres.Name = "TextBoxNombres"
        Me.TextBoxNombres.Size = New System.Drawing.Size(161, 20)
        Me.TextBoxNombres.TabIndex = 1
        Me.TextBoxNombres.TabStop = False
        '
        'TextBoxDocumento
        '
        Me.TextBoxDocumento.Location = New System.Drawing.Point(211, 65)
        Me.TextBoxDocumento.MaxLength = 10
        Me.TextBoxDocumento.Name = "TextBoxDocumento"
        Me.TextBoxDocumento.Size = New System.Drawing.Size(72, 20)
        Me.TextBoxDocumento.TabIndex = 0
        Me.TextBoxDocumento.TabStop = False
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.Color.White
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.ButtonSalir)
        Me.panel2.Controls.Add(Me.ButtonAyuda)
        Me.panel2.Controls.Add(Me.lblBorrarFoto)
        Me.panel2.Controls.Add(Me.label5)
        Me.panel2.Controls.Add(Me.ButtonEliminar)
        Me.panel2.Controls.Add(Me.label4)
        Me.panel2.Controls.Add(Me.ButtonGrabar)
        Me.panel2.Controls.Add(Me.label3)
        Me.panel2.Controls.Add(Me.ButtonCancelar)
        Me.panel2.Controls.Add(Me.label2)
        Me.panel2.Controls.Add(Me.label1)
        Me.panel2.Controls.Add(Me.PictureBoxFotoUsuario)
        Me.panel2.Controls.Add(Me.TextBoxTelefono)
        Me.panel2.Controls.Add(Me.TextBoxCorreo)
        Me.panel2.Controls.Add(Me.TextBoxApellidos)
        Me.panel2.Controls.Add(Me.TextBoxNombres)
        Me.panel2.Controls.Add(Me.TextBoxDocumento)
        Me.panel2.Location = New System.Drawing.Point(415, 232)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(576, 370)
        Me.panel2.TabIndex = 277
        '
        'errorPro
        '
        Me.errorPro.ContainerControl = Me
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.Teal
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.Label_Titulo)
        Me.panel1.Location = New System.Drawing.Point(415, 187)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(576, 60)
        Me.panel1.TabIndex = 332
        '
        'Label_Titulo
        '
        Me.Label_Titulo.AutoSize = True
        Me.Label_Titulo.BackColor = System.Drawing.Color.Transparent
        Me.Label_Titulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Titulo.ForeColor = System.Drawing.Color.White
        Me.Label_Titulo.Image = Global.SIMI_Desktop.My.Resources.Resources.icoperarios
        Me.Label_Titulo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label_Titulo.Location = New System.Drawing.Point(3, 16)
        Me.Label_Titulo.Name = "Label_Titulo"
        Me.Label_Titulo.Size = New System.Drawing.Size(133, 25)
        Me.Label_Titulo.TabIndex = 0
        Me.Label_Titulo.Text = "       Operarios"
        Me.Label_Titulo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'FormOperarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.SIMI_Desktop.My.Resources.Resources.Plantilla
        Me.ClientSize = New System.Drawing.Size(1096, 655)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "FormOperarios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Operarios"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PictureBoxFotoUsuario, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents lblBorrarFoto As System.Windows.Forms.Label
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents TextBoxTelefono As System.Windows.Forms.TextBox
    Private WithEvents ButtonSalir As System.Windows.Forms.Button
    Private WithEvents ButtonAyuda As System.Windows.Forms.Button
    Private WithEvents ButtonEliminar As System.Windows.Forms.Button
    Private WithEvents ButtonCancelar As System.Windows.Forms.Button
    Private WithEvents ButtonGrabar As System.Windows.Forms.Button
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents PictureBoxFotoUsuario As System.Windows.Forms.PictureBox
    Private WithEvents TextBoxCorreo As System.Windows.Forms.TextBox
    Private WithEvents TextBoxApellidos As System.Windows.Forms.TextBox
    Private WithEvents TextBoxNombres As System.Windows.Forms.TextBox
    Private WithEvents TextBoxDocumento As System.Windows.Forms.TextBox
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents errorPro As System.Windows.Forms.ErrorProvider
    Private WithEvents panel1 As Panel
    Friend WithEvents Label_Titulo As Label
End Class
