﻿' Clase que nos devuelve la conexion con el proveedor que se desee
Public Class Conexion
    Public Shared Function obtenerConexion()
        Dim CadenaConexion As String = System.Configuration.ConfigurationManager.ConnectionStrings("Conexion").ToString
        Return CadenaConexion
    End Function
End Class
