﻿namespace SIMI_Desktop
{
    partial class FormEquipos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEquipos));
            this.panel2 = new System.Windows.Forms.Panel();
            this.CheckBoxLubricacion = new System.Windows.Forms.CheckBox();
            this.TextBoxSerie = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DropDownListLineas = new System.Windows.Forms.ComboBox();
            this.DropDownListMarcas = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TextBoxNombreEquipo = new System.Windows.Forms.TextBox();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonAyuda = new System.Windows.Forms.Button();
            this.ButtonGrabar = new System.Windows.Forms.Button();
            this.ButtonEliminar = new System.Windows.Forms.Button();
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.ButtonCancelar);
            this.panel2.Controls.Add(this.CheckBoxLubricacion);
            this.panel2.Controls.Add(this.ButtonSalir);
            this.panel2.Controls.Add(this.ButtonAyuda);
            this.panel2.Controls.Add(this.TextBoxSerie);
            this.panel2.Controls.Add(this.ButtonGrabar);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.ButtonEliminar);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.DropDownListLineas);
            this.panel2.Controls.Add(this.DropDownListMarcas);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.TextBoxNombreEquipo);
            this.panel2.Location = new System.Drawing.Point(424, 200);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(493, 336);
            this.panel2.TabIndex = 280;
            // 
            // CheckBoxLubricacion
            // 
            this.CheckBoxLubricacion.AutoSize = true;
            this.CheckBoxLubricacion.CheckAlign = System.Drawing.ContentAlignment.BottomRight;
            this.CheckBoxLubricacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBoxLubricacion.Location = new System.Drawing.Point(96, 238);
            this.CheckBoxLubricacion.Name = "CheckBoxLubricacion";
            this.CheckBoxLubricacion.Size = new System.Drawing.Size(92, 17);
            this.CheckBoxLubricacion.TabIndex = 5;
            this.CheckBoxLubricacion.TabStop = false;
            this.CheckBoxLubricacion.Text = "Lubricacion";
            this.CheckBoxLubricacion.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.CheckBoxLubricacion.UseVisualStyleBackColor = true;
            // 
            // TextBoxSerie
            // 
            this.TextBoxSerie.Location = new System.Drawing.Point(174, 163);
            this.TextBoxSerie.MaxLength = 20;
            this.TextBoxSerie.Name = "TextBoxSerie";
            this.TextBoxSerie.Size = new System.Drawing.Size(121, 20);
            this.TextBoxSerie.TabIndex = 3;
            this.TextBoxSerie.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(93, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 330;
            this.label5.Text = "Serie";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(93, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 329;
            this.label4.Text = "LIneas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(93, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 328;
            this.label3.Text = "Marca";
            // 
            // DropDownListLineas
            // 
            this.DropDownListLineas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DropDownListLineas.FormattingEnabled = true;
            this.DropDownListLineas.Location = new System.Drawing.Point(174, 195);
            this.DropDownListLineas.Name = "DropDownListLineas";
            this.DropDownListLineas.Size = new System.Drawing.Size(121, 21);
            this.DropDownListLineas.TabIndex = 4;
            this.DropDownListLineas.TabStop = false;
            // 
            // DropDownListMarcas
            // 
            this.DropDownListMarcas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DropDownListMarcas.FormattingEnabled = true;
            this.DropDownListMarcas.Location = new System.Drawing.Point(174, 129);
            this.DropDownListMarcas.Name = "DropDownListMarcas";
            this.DropDownListMarcas.Size = new System.Drawing.Size(121, 21);
            this.DropDownListMarcas.TabIndex = 2;
            this.DropDownListMarcas.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(93, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 282;
            this.label2.Text = "Nombre";
            // 
            // TextBoxNombreEquipo
            // 
            this.TextBoxNombreEquipo.Location = new System.Drawing.Point(174, 98);
            this.TextBoxNombreEquipo.MaxLength = 50;
            this.TextBoxNombreEquipo.Name = "TextBoxNombreEquipo";
            this.TextBoxNombreEquipo.Size = new System.Drawing.Size(208, 20);
            this.TextBoxNombreEquipo.TabIndex = 1;
            this.TextBoxNombreEquipo.TabStop = false;
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(151, 273);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(60, 35);
            this.ButtonCancelar.TabIndex = 7;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(322, 273);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(60, 35);
            this.ButtonSalir.TabIndex = 10;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonAyuda
            // 
            this.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAyuda.ForeColor = System.Drawing.Color.Black;
            this.ButtonAyuda.Image = ((System.Drawing.Image)(resources.GetObject("ButtonAyuda.Image")));
            this.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonAyuda.Location = new System.Drawing.Point(265, 273);
            this.ButtonAyuda.Name = "ButtonAyuda";
            this.ButtonAyuda.Size = new System.Drawing.Size(60, 35);
            this.ButtonAyuda.TabIndex = 9;
            this.ButtonAyuda.TabStop = false;
            this.ButtonAyuda.Text = "Ayuda";
            this.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonAyuda.UseVisualStyleBackColor = false;
            this.ButtonAyuda.Click += new System.EventHandler(this.ButtonAyuda_Click);
            // 
            // ButtonGrabar
            // 
            this.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonGrabar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGrabar.ForeColor = System.Drawing.Color.Black;
            this.ButtonGrabar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonGrabar.Image")));
            this.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonGrabar.Location = new System.Drawing.Point(95, 273);
            this.ButtonGrabar.Name = "ButtonGrabar";
            this.ButtonGrabar.Size = new System.Drawing.Size(60, 35);
            this.ButtonGrabar.TabIndex = 6;
            this.ButtonGrabar.TabStop = false;
            this.ButtonGrabar.Text = "Grabar";
            this.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonGrabar.UseVisualStyleBackColor = false;
            this.ButtonGrabar.Click += new System.EventHandler(this.ButtonGrabar_Click);
            // 
            // ButtonEliminar
            // 
            this.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonEliminar.Enabled = false;
            this.ButtonEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonEliminar.ForeColor = System.Drawing.Color.Black;
            this.ButtonEliminar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonEliminar.Image")));
            this.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonEliminar.Location = new System.Drawing.Point(208, 273);
            this.ButtonEliminar.Name = "ButtonEliminar";
            this.ButtonEliminar.Size = new System.Drawing.Size(60, 35);
            this.ButtonEliminar.TabIndex = 8;
            this.ButtonEliminar.TabStop = false;
            this.ButtonEliminar.Text = "Eliminar";
            this.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonEliminar.UseVisualStyleBackColor = false;
            this.ButtonEliminar.Click += new System.EventHandler(this.ButtonEliminar_Click);
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(424, 147);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(493, 60);
            this.panel1.TabIndex = 344;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::SIMI_Desktop.Properties.Resources.icoequipos;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 25);
            this.label1.TabIndex = 343;
            this.label1.Text = "     Equipos";
            // 
            // FormEquipos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIMI_Desktop.Properties.Resources.Plantilla;
            this.ClientSize = new System.Drawing.Size(1247, 493);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormEquipos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "   Equipos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormEquipos_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBoxNombreEquipo;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonAyuda;
        private System.Windows.Forms.Button ButtonGrabar;
        private System.Windows.Forms.Button ButtonEliminar;
        private System.Windows.Forms.CheckBox CheckBoxLubricacion;
        private System.Windows.Forms.TextBox TextBoxSerie;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox DropDownListLineas;
        private System.Windows.Forms.ComboBox DropDownListMarcas;
        private System.Windows.Forms.ErrorProvider errorPro;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}