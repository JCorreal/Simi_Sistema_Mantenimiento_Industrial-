﻿using System;
using ControlMantenimiento_NetWeb.BLL;

public partial class Forms_WebFormError : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Funciones.MensajeError != null)
        {
            TextBoxMensajeError.Text = Funciones.MensajeError;
        }
    }
}