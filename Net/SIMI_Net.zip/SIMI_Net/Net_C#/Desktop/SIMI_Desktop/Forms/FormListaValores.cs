﻿using SIMI_Desktop.BLL;
using SIMI_Desktop.BO;
using System;
using System.Windows.Forms;

namespace SIMI_Desktop
{
    public partial class FormListaValores : Form
    {
        public FormListaValores()
        {
            InitializeComponent();
            this.TextBoxNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNombre_KeyPress);
            this.TextBoxDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxDescripcion_KeyPress);

        }
        //private Controlador_Equipo _controlador = Funciones.crearControlador_Equipo();

        private Controlador_ListaValores _controlador = Funciones.crearControlador_ListaValores();
        private bool grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter
        private ListaValores listavalores;

        private void FrmListaValores_Load(object sender, EventArgs e)
        {
            if (Funciones.ValorTipo == "MARCAS")
            {
                label_Marcas.Visible = true;
                label_Lineas.Visible = false;
            }
            else 
            {
                label_Marcas.Visible = false;
                label_Lineas.Visible = true;
            }
            this.Text = Funciones.ValorTipo.ToLower();
            this.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(this.Text);
            if (Funciones.ParametroBuscar != 0)
            {
                consultarBD();
            }
        }

        private void consultarBD()
        {
            listavalores = (ListaValores)_controlador.obtenerListaValores(Funciones.ParametroBuscar);
            if (listavalores != null)
            {
                poblarFormulario();
            }
        }

        private void poblarFormulario()
        {
            ButtonEliminar.Enabled = true;
            TextBoxNombre.Text = listavalores.Nombre;
            TextBoxDescripcion.Text = listavalores.Descripcion;
            TextBoxNombre.Focus();
        }

        private void TextBoxNombre_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxNombre.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxNombre.Focus();
                    errorPro.SetError(TextBoxNombre, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxDescripcion.Focus();
                }
            }
        }

        private void TextBoxDescripcion_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                Funciones.eliminarTabulador(TextBoxDescripcion.Text, "");
                ButtonGrabar.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            grabar = true;
            TextBoxNombre_KeyPress(ButtonGrabar, Tecla);
            if (grabar)
            {
                Guardar();
            }
        }

        private void Guardar()
        {
            int resultado;
            listavalores = new ListaValores();
            listavalores.Listavalores_id = Funciones.ParametroBuscar;
            listavalores.Nombre = TextBoxNombre.Text.Trim();
            listavalores.Descripcion = TextBoxDescripcion.Text.Trim();
            listavalores.Tipo = Funciones.ValorTipo;

            resultado = _controlador.guardarListaValores(listavalores);
            if (resultado == 0)
            {
                if (Funciones.ParametroBuscar == 0)
                {
                    MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Limpiar();
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ButtonSalir.PerformClick();
                }
            }
            else if (resultado == 1)
            {
                MessageBox.Show(Mensajes.Mensaje8, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TextBoxNombre.Focus();
                errorPro.SetError(TextBoxNombre, Mensajes.Mensaje8);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Limpiar()
        {
            if (Funciones.ParametroBuscar == 0)
            {
                Funciones.limpiarForma(panel2);
                ButtonEliminar.Enabled = false;
                errorPro.Clear();
                TextBoxNombre.Focus();
            }
            else 
            { 
                poblarFormulario(); 
            }
            
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            int resultado;
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar);
                if (resultado == 0)
                {
                    MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
					ButtonSalir.PerformClick();
                }
                else if (resultado == 1)
                {
                    MessageBox.Show(Mensajes.Mensaje9, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            Funciones.mostararAyuda();
        }
    }
}
