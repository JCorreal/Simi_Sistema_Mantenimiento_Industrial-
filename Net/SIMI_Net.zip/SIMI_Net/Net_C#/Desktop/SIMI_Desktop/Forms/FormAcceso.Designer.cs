﻿namespace SIMI_Desktop
{
    partial class FormAcceso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAcceso));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonIngresar = new System.Windows.Forms.Button();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.TextBoxClave = new System.Windows.Forms.TextBox();
            this.TextBoxDocumento = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(451, 216);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(490, 60);
            this.panel1.TabIndex = 345;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = global::SIMI_Desktop.Properties.Resources.icoclave;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Location = new System.Drawing.Point(3, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 25);
            this.label2.TabIndex = 343;
            this.label2.Text = "      Acceso";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.ButtonSalir);
            this.panel2.Controls.Add(this.ButtonIngresar);
            this.panel2.Controls.Add(this.ButtonCancelar);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.TextBoxClave);
            this.panel2.Controls.Add(this.TextBoxDocumento);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(451, 264);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(486, 218);
            this.panel2.TabIndex = 346;
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(252, 134);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(60, 35);
            this.ButtonSalir.TabIndex = 352;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonIngresar
            // 
            this.ButtonIngresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonIngresar.ForeColor = System.Drawing.Color.Black;
            this.ButtonIngresar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonIngresar.Image")));
            this.ButtonIngresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonIngresar.Location = new System.Drawing.Point(136, 134);
            this.ButtonIngresar.Name = "ButtonIngresar";
            this.ButtonIngresar.Size = new System.Drawing.Size(60, 35);
            this.ButtonIngresar.TabIndex = 349;
            this.ButtonIngresar.TabStop = false;
            this.ButtonIngresar.Text = "Ingresar";
            this.ButtonIngresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonIngresar.UseVisualStyleBackColor = false;
            this.ButtonIngresar.Click += new System.EventHandler(this.ButtonIngresar_Click);
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(194, 134);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(60, 35);
            this.ButtonCancelar.TabIndex = 350;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(146, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 348;
            this.label4.Text = "Clave";
            // 
            // TextBoxClave
            // 
            this.TextBoxClave.Location = new System.Drawing.Point(202, 77);
            this.TextBoxClave.MaxLength = 6;
            this.TextBoxClave.Name = "TextBoxClave";
            this.TextBoxClave.PasswordChar = '*';
            this.TextBoxClave.Size = new System.Drawing.Size(33, 20);
            this.TextBoxClave.TabIndex = 342;
            this.TextBoxClave.TabStop = false;
            // 
            // TextBoxDocumento
            // 
            this.TextBoxDocumento.Location = new System.Drawing.Point(202, 44);
            this.TextBoxDocumento.MaxLength = 10;
            this.TextBoxDocumento.Name = "TextBoxDocumento";
            this.TextBoxDocumento.Size = new System.Drawing.Size(72, 20);
            this.TextBoxDocumento.TabIndex = 341;
            this.TextBoxDocumento.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(146, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 347;
            this.label1.Text = "Usuario";
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // FormAcceso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIMI_Desktop.Properties.Resources.Plantilla;
            this.ClientSize = new System.Drawing.Size(1300, 530);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "FormAcceso";
            this.Text = "Acceso Simi";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonIngresar;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TextBoxClave;
        private System.Windows.Forms.TextBox TextBoxDocumento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorPro;
    }
}