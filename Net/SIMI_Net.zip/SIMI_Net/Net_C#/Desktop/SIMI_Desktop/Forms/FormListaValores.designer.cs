﻿namespace SIMI_Desktop
{
    partial class FormListaValores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormListaValores));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TextBoxDescripcion = new System.Windows.Forms.TextBox();
            this.TextBoxNombre = new System.Windows.Forms.TextBox();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonAyuda = new System.Windows.Forms.Button();
            this.ButtonGrabar = new System.Windows.Forms.Button();
            this.ButtonEliminar = new System.Windows.Forms.Button();
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Lineas = new System.Windows.Forms.Label();
            this.label_Marcas = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.ButtonCancelar);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.ButtonSalir);
            this.panel2.Controls.Add(this.ButtonAyuda);
            this.panel2.Controls.Add(this.ButtonGrabar);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.ButtonEliminar);
            this.panel2.Controls.Add(this.TextBoxDescripcion);
            this.panel2.Controls.Add(this.TextBoxNombre);
            this.panel2.Location = new System.Drawing.Point(458, 219);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(493, 241);
            this.panel2.TabIndex = 278;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(93, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 283;
            this.label3.Text = "Descripcion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(93, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 282;
            this.label2.Text = "Nombre";
            // 
            // TextBoxDescripcion
            // 
            this.TextBoxDescripcion.Location = new System.Drawing.Point(181, 76);
            this.TextBoxDescripcion.MaxLength = 255;
            this.TextBoxDescripcion.Multiline = true;
            this.TextBoxDescripcion.Name = "TextBoxDescripcion";
            this.TextBoxDescripcion.Size = new System.Drawing.Size(208, 65);
            this.TextBoxDescripcion.TabIndex = 2;
            this.TextBoxDescripcion.TabStop = false;
            // 
            // TextBoxNombre
            // 
            this.TextBoxNombre.Location = new System.Drawing.Point(181, 39);
            this.TextBoxNombre.MaxLength = 50;
            this.TextBoxNombre.Name = "TextBoxNombre";
            this.TextBoxNombre.Size = new System.Drawing.Size(208, 20);
            this.TextBoxNombre.TabIndex = 1;
            this.TextBoxNombre.TabStop = false;
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(163, 169);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(60, 35);
            this.ButtonCancelar.TabIndex = 4;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(334, 169);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(60, 35);
            this.ButtonSalir.TabIndex = 7;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonAyuda
            // 
            this.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAyuda.ForeColor = System.Drawing.Color.Black;
            this.ButtonAyuda.Image = ((System.Drawing.Image)(resources.GetObject("ButtonAyuda.Image")));
            this.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonAyuda.Location = new System.Drawing.Point(277, 169);
            this.ButtonAyuda.Name = "ButtonAyuda";
            this.ButtonAyuda.Size = new System.Drawing.Size(60, 35);
            this.ButtonAyuda.TabIndex = 6;
            this.ButtonAyuda.TabStop = false;
            this.ButtonAyuda.Text = "Ayuda";
            this.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonAyuda.UseVisualStyleBackColor = false;
            this.ButtonAyuda.Click += new System.EventHandler(this.ButtonAyuda_Click);
            // 
            // ButtonGrabar
            // 
            this.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonGrabar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGrabar.ForeColor = System.Drawing.Color.Black;
            this.ButtonGrabar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonGrabar.Image")));
            this.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonGrabar.Location = new System.Drawing.Point(107, 169);
            this.ButtonGrabar.Name = "ButtonGrabar";
            this.ButtonGrabar.Size = new System.Drawing.Size(60, 35);
            this.ButtonGrabar.TabIndex = 3;
            this.ButtonGrabar.TabStop = false;
            this.ButtonGrabar.Text = "Grabar";
            this.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonGrabar.UseVisualStyleBackColor = false;
            this.ButtonGrabar.Click += new System.EventHandler(this.ButtonGrabar_Click);
            // 
            // ButtonEliminar
            // 
            this.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonEliminar.Enabled = false;
            this.ButtonEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonEliminar.ForeColor = System.Drawing.Color.Black;
            this.ButtonEliminar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonEliminar.Image")));
            this.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonEliminar.Location = new System.Drawing.Point(220, 169);
            this.ButtonEliminar.Name = "ButtonEliminar";
            this.ButtonEliminar.Size = new System.Drawing.Size(60, 35);
            this.ButtonEliminar.TabIndex = 5;
            this.ButtonEliminar.TabStop = false;
            this.ButtonEliminar.Text = "Eliminar";
            this.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonEliminar.UseVisualStyleBackColor = false;
            this.ButtonEliminar.Click += new System.EventHandler(this.ButtonEliminar_Click);
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label_Marcas);
            this.panel1.Controls.Add(this.label_Lineas);
            this.panel1.Location = new System.Drawing.Point(458, 171);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(493, 60);
            this.panel1.TabIndex = 344;
            // 
            // label_Lineas
            // 
            this.label_Lineas.AutoSize = true;
            this.label_Lineas.BackColor = System.Drawing.Color.Transparent;
            this.label_Lineas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Lineas.ForeColor = System.Drawing.Color.White;
            this.label_Lineas.Image = global::SIMI_Desktop.Properties.Resources.icolineas;
            this.label_Lineas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_Lineas.Location = new System.Drawing.Point(3, 10);
            this.label_Lineas.Name = "label_Lineas";
            this.label_Lineas.Size = new System.Drawing.Size(100, 25);
            this.label_Lineas.TabIndex = 343;
            this.label_Lineas.Text = "      Lineas";
            // 
            // label_Marcas
            // 
            this.label_Marcas.AutoSize = true;
            this.label_Marcas.BackColor = System.Drawing.Color.Transparent;
            this.label_Marcas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Marcas.ForeColor = System.Drawing.Color.White;
            this.label_Marcas.Image = global::SIMI_Desktop.Properties.Resources.icomarca;
            this.label_Marcas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_Marcas.Location = new System.Drawing.Point(3, 10);
            this.label_Marcas.Name = "label_Marcas";
            this.label_Marcas.Size = new System.Drawing.Size(107, 25);
            this.label_Marcas.TabIndex = 344;
            this.label_Marcas.Text = "      Marcas";
            // 
            // FormListaValores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIMI_Desktop.Properties.Resources.Plantilla;
            this.ClientSize = new System.Drawing.Size(1154, 590);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormListaValores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmListaValores_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBoxDescripcion;
        private System.Windows.Forms.TextBox TextBoxNombre;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonAyuda;
        private System.Windows.Forms.Button ButtonGrabar;
        private System.Windows.Forms.Button ButtonEliminar;
        private System.Windows.Forms.ErrorProvider errorPro;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Lineas;
        private System.Windows.Forms.Label label_Marcas;
    }
}