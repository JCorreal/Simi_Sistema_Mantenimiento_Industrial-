﻿using SIMI_Desktop.BLL;
using SIMI_Desktop.BO;
using System;
using System.Collections;
using System.Windows.Forms;

namespace SIMI_Desktop
{
    public partial class FormEquipos : Form
    {
        public FormEquipos()
        {
            InitializeComponent();
            this.TextBoxNombreEquipo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNombreEquipo_KeyPress);
            this.TextBoxSerie.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxSerie_KeyPress);
            this.DropDownListMarcas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListMarcas_KeyPress);
            this.DropDownListLineas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListLineas_KeyPress);
        }

        private Controlador_Equipo _controlador = Funciones.crearControlador_Equipo();
        private bool grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter        
        private Equipo equipo;

        private void FormEquipos_Load(object sender, EventArgs e)
        {         
            DropDownListLineas.ValueMember = "CODIGO";
            DropDownListLineas.DisplayMember = "DETALLE";
            DropDownListLineas.DataSource = Funciones.Lista1;

            DropDownListMarcas.ValueMember = "CODIGO";
            DropDownListMarcas.DisplayMember = "DETALLE";
            DropDownListMarcas.DataSource = Funciones.Lista2;

            if (Funciones.ParametroBuscar != 0)
            {
                consultarBD();
            }
        }

        private void consultarBD()
        {
            equipo = (Equipo)_controlador.obtenerEquipo(Funciones.ParametroBuscar);
            if (equipo != null)
            {
                poblarFormulario();
            }
        }

        private void poblarFormulario()
        {
            ButtonEliminar.Enabled = true;
            TextBoxNombreEquipo.Text = equipo.Nombre_equipo;
            DropDownListMarcas.SelectedValue = equipo.Marca.ToString();
            TextBoxSerie.Text = equipo.Serie;
            DropDownListLineas.SelectedValue = equipo.Linea.ToString();
            CheckBoxLubricacion.Checked = equipo.Lubricacion == 1 ? true : false;
            TextBoxNombreEquipo.Focus();
        }

        private void TextBoxNombreEquipo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (string.IsNullOrEmpty(TextBoxNombreEquipo.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxNombreEquipo.Focus();
                    errorPro.SetError(TextBoxNombreEquipo, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxNombreEquipo.Text = Funciones.eliminarTabulador(TextBoxNombreEquipo.Text, "MAY");
                    DropDownListMarcas.Focus();
                }
            }
        }

        private void TextBoxSerie_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (string.IsNullOrEmpty(TextBoxSerie.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxSerie.Focus();
                    errorPro.SetError(TextBoxSerie, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    DropDownListLineas.Focus();
                }
            }
        }

        private void DropDownListMarcas_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                TextBoxSerie.Focus();
            }
        }

        private void DropDownListLineas_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                CheckBoxLubricacion.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            grabar = true;
            TextBoxNombreEquipo_KeyPress(ButtonGrabar, Tecla);
            if (grabar)
            {
                TextBoxSerie_KeyPress(ButtonGrabar, Tecla);
                if (grabar)
                {
                    Guardar();
                }
            }
        }
        private void Guardar()
        {
            int resultado;
            Equipo equipo = new Equipo();
            equipo.Equipo_id = Funciones.ParametroBuscar;
            equipo.Nombre_equipo = TextBoxNombreEquipo.Text.Trim();
            equipo.Marca = Convert.ToInt32(DropDownListMarcas.SelectedValue.ToString());
            equipo.Serie = TextBoxSerie.Text.Trim();
            equipo.Linea = Convert.ToInt32(DropDownListLineas.SelectedValue.ToString());
            equipo.Lubricacion = CheckBoxLubricacion.Checked ? 1 : 0;

            resultado = _controlador.guardarEquipo(equipo);
            if (resultado == 0)
            {
                if (Funciones.ParametroBuscar == 0)
                {
                    MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Limpiar();
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ButtonSalir.PerformClick();
                }
            }
            else if (resultado == 1)
            {
                MessageBox.Show(Mensajes.Mensaje7, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                TextBoxSerie.Focus();
                errorPro.SetError(TextBoxSerie, Mensajes.Mensaje7);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Limpiar()
        {
            if (Funciones.ParametroBuscar == 0)
            {
                Funciones.limpiarForma(panel2);
                ButtonEliminar.Enabled = false;
                errorPro.Clear();
                CheckBoxLubricacion.Checked = false;
                TextBoxNombreEquipo.Focus();
            }
            else
            {
                poblarFormulario();
            }
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            Funciones.Lista1 = null;
            Funciones.Lista2 = null;
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                if (_controlador.eliminarRegistro(Funciones.ParametroBuscar) == 0)
                {
                    MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Limpiar();
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            Funciones.mostararAyuda();
        }

    }
}



