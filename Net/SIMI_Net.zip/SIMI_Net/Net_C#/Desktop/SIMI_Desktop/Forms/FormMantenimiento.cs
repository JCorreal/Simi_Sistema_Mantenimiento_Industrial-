﻿
/*=================================================================================== 
 La norma es que no puede haber sino una sola programación por equipo
 Un Operario no puede estar asignado en la misma fecha para varios mantenimientos
 ==================================================================================== */

using SIMI_Desktop.BLL;
using SIMI_Desktop.BO;
using System;
using System.Collections;
using System.Windows.Forms;

namespace SIMI_Desktop
{
    public partial class FormMantenimiento : Form
    {
        public FormMantenimiento()
        {
            InitializeComponent();
            this.DropDownListEquipos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListEquipos_KeyPress);
            this.DropDownListOperarios.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListOperarios_KeyPress);
            this.DateTimePickerFecha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DateTimePickerFecha_KeyPress);
            this.TextBoxObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxObservaciones_KeyPress);
        }

        private Controlador_Mantenimiento _controlador = Funciones.crearControlador_Mantenimiento();
        private bool grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter       
        private Mantenimiento mantenimiento;
        private ArrayList arlListadoEquipos = new ArrayList();

        private void FormMantenimiento_Load(object sender, EventArgs e)
        {           
            CargarCombos();
            if (Funciones.ParametroBuscar != 0)
            {
                consultarBD();
            }
        }

        private void consultarBD()
        {
            mantenimiento = (Mantenimiento)_controlador.obtenerMantenimiento(Funciones.ParametroBuscar);           
            if (mantenimiento != null)
            {
                poblarFormulario();
            }
        }

        private void poblarFormulario()
        {
            ButtonEliminar.Enabled = true;
            DropDownListEquipos.Enabled = false;
            DropDownListEquipos.SelectedValue = mantenimiento.Equipo_id.ToString();
            DropDownListOperarios.SelectedValue = mantenimiento.Operario_id.ToString();            
            DateTimePickerFecha.Value = mantenimiento.Fecha;
            TextBoxObservaciones.Text = mantenimiento.Observaciones;
            ButtonGrabar.Enabled = true;
            DropDownListOperarios.Focus();
        }

        private void CargarCombos()
        {
            DropDownListEquipos.ValueMember = "CODIGO";
            DropDownListEquipos.DisplayMember = "DETALLE";
            DropDownListEquipos.DataSource = Funciones.Lista1; 

            DropDownListOperarios.ValueMember = "CODIGO";
            DropDownListOperarios.DisplayMember = "DETALLE";
            DropDownListOperarios.DataSource = Funciones.Lista2;
        }

        private void DropDownListEquipos_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DropDownListOperarios.Focus();
            }
        }

        private void DropDownListOperarios_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DateTimePickerFecha.Focus();
            }
        }

        private void DateTimePickerFecha_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DateTimePickerFecha_ValueChanged(DateTimePickerFecha, e);
            }
        }

        private void TextBoxObservaciones_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                Funciones.eliminarTabulador(TextBoxObservaciones.Text, "");
                ButtonGrabar.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            grabar = true;
            DateTimePickerFecha_KeyPress(ButtonGrabar, Tecla);
            if (grabar)
            {               
                Guardar();
            }
        }

        private void Guardar()
        {
            int resultado;
            Mantenimiento mantenimiento = new Mantenimiento();
            mantenimiento.Mantenimiento_id = Funciones.ParametroBuscar;
            mantenimiento.Equipo_id = Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString());
            mantenimiento.Operario_id = Convert.ToInt32(DropDownListOperarios.SelectedValue.ToString());
            mantenimiento.Fecha = Convert.ToDateTime(DateTimePickerFecha.Value);
            mantenimiento.Observaciones = TextBoxObservaciones.Text;

            resultado = _controlador.guardarMantenimiento(mantenimiento);
            if (resultado == 0)
            {
                if (Funciones.ParametroBuscar == 0)
                {
                    MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefrescarCombos();
                    if (DropDownListEquipos.Items.Count <= 0)
                    {
                        ButtonSalir.PerformClick();
                    }
                     else
                    {
                        Limpiar();
                    }
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ButtonSalir.PerformClick();
                }
            }
            else if (resultado == 1)
            {
                MessageBox.Show(Mensajes.Mensaje10, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DropDownListOperarios.Focus();
                errorPro.SetError(DropDownListOperarios, Mensajes.Mensaje10);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Limpiar()
        {
            if (Funciones.ParametroBuscar == 0)
            {     
                Funciones.limpiarForma(panel2);
                DateTimePickerFecha.Value = DateTime.Now.Date;
                errorPro.Clear();
                DropDownListEquipos.Focus();
            }
            else
            {
                poblarFormulario();
            }            
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            Funciones.Lista1 = null;
            Funciones.Lista2 = null;
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {

                if (_controlador.eliminarRegistro(Funciones.ParametroBuscar) == 0)
                {
                    MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
					ButtonSalir.PerformClick();
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }             
            }

        }

        private void DateTimePickerFecha_ValueChanged(object sender, EventArgs e)
        {
            if (DateTimePickerFecha.Value < DateTime.Now.Date)
            {
                grabar = false;
                MessageBox.Show(Mensajes.Mensaje27, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DateTimePickerFecha.Focus();
                errorPro.SetError(DateTimePickerFecha, Mensajes.Mensaje27);
            }
            else
            {
                errorPro.Clear();
                TextBoxObservaciones.Focus();
            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            Funciones.mostararAyuda();
        }

        private void RefrescarCombos()
        { // Este proceso elimina el equipo seleccionado de la lista, para evitar que vuelvan a programarle. Así evitamos ir a BD a recargar el DataSource
            CargaCombosListas _cb;
            string valor = DropDownListEquipos.SelectedValue.ToString();
            for (int i = 0; i < arlListadoEquipos.Count; i++)
            {
                _cb = new CargaCombosListas();
                _cb = (CargaCombosListas)arlListadoEquipos[i];
                if (_cb.Codigo == valor)
                {
                    arlListadoEquipos.RemoveAt(i);
                    break;
                }
            }
            // Ahora repoblar los combos nuevamente
            DropDownListEquipos.DataSource = null;
            DropDownListEquipos.Items.Clear();
            DropDownListEquipos.ValueMember = "CODIGO";
            DropDownListEquipos.DisplayMember = "DETALLE";
            DropDownListEquipos.DataSource = arlListadoEquipos;
            DropDownListEquipos.SelectedIndex = 0;
        }
    }
}
