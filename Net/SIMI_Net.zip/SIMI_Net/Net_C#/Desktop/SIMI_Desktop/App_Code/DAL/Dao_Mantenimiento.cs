﻿// DAL: Data Access Layer - Capa Acceso Datos Mantenimiento
using SIMI_Desktop.BO;
using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;

namespace SIMI_Desktop.DAL
{
    public class Dao_Mantenimiento : Dao_General, IDao_Mantenimiento
    {
        // Default Constructor
        public Dao_Mantenimiento() { }

        public Mantenimiento obtenerMantenimiento(int datoBuscar)
        {
            Mantenimiento mantenimiento = new Mantenimiento();
            try
            {
                buscarRegistro("TBL_MANTENIMIENTO", datoBuscar);
                if (sdr.Read())
                {
                    mantenimiento.Mantenimiento_id = Convert.ToInt32(sdr["MANTENIMIENTO_ID"].ToString());
                    mantenimiento.Equipo_id = Convert.ToInt32(sdr["EQUIPO_ID"].ToString());
                    mantenimiento.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    mantenimiento.Fecha = Convert.ToDateTime(sdr["FECHA"].ToString());
                    mantenimiento.Observaciones = sdr["OBSERVACIONES"].ToString();
                }
                else
                {
                    mantenimiento = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return mantenimiento;
        }

        public int guardarMantenimiento(Mantenimiento mantenimiento, int Usuario)
        {
            int resultado = -1;
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_IU_Mantenimiento", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_MANTENIMIENTO_ID", SqlDbType.Int, 4).Value = mantenimiento.Mantenimiento_id;
                    Cmd.Parameters.Add("p_EQUIPO_ID", SqlDbType.Int, 4).Value = mantenimiento.Equipo_id;
                    Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 4).Value = mantenimiento.Operario_id;
                    Cmd.Parameters.Add("p_FECHA", SqlDbType.DateTime, 10).Value = mantenimiento.Fecha;
                    Cmd.Parameters.Add("p_OBSERVACIONES", SqlDbType.VarChar, 255).Value = mantenimiento.Observaciones;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.Int, 4).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public ArrayList cargarDatosCombos(string tabla)
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarArray(tabla);
            return arlLista;
        }

        public ArrayList cargarListado()
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas("TBL_MANTENIMIENTO");
            return arlLista;
        }

        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_Mantenimiento");
            return resultado;
        }

       
    }
}