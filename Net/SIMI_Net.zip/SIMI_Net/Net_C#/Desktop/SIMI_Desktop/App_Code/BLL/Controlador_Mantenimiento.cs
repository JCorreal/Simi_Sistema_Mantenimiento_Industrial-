using SIMI_Desktop.BO;
using SIMI_Desktop.DAL;
using System.Collections;

namespace SIMI_Desktop.BLL
{
    public class Controlador_Mantenimiento
    {
        private readonly IDao_Mantenimiento _dao_mantenimiento;

        public Controlador_Mantenimiento(IDao_Mantenimiento dao_mantenimiento)
        {
            _dao_mantenimiento = dao_mantenimiento;
        }

        public ArrayList cargarListado()
        {
            return _dao_mantenimiento.cargarListado();
        }

        public ArrayList CargarDatosCombos(string tabla)
        {
            return _dao_mantenimiento.cargarDatosCombos(tabla);
        }

        public Mantenimiento obtenerMantenimiento(int datoBuscar)
        {
            Mantenimiento mantenimiento = new Mantenimiento();
            mantenimiento = _dao_mantenimiento.obtenerMantenimiento(datoBuscar);
            return mantenimiento;
        }

        public int guardarMantenimiento(Mantenimiento mantenimiento)
        {
            return _dao_mantenimiento.guardarMantenimiento(mantenimiento, Funciones.UsuarioConectado);
        }

        public int eliminarRegistro(int datoEliminar)
        {
            return _dao_mantenimiento.eliminarRegistro(datoEliminar);
        }
    }
}