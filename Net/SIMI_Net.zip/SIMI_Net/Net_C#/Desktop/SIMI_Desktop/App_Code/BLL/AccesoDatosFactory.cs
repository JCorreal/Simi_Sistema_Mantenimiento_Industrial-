﻿using SIMI_Desktop.DAL; // Patron de Creacion: Factory Method


namespace SIMI_Desktop.BLL
{
    public static class AccesoDatosFactory
    {
        public static IDao_Operario obtenerDao_Operario()
        {
            return new Dao_Operario();
        }

        public static IDao_Equipo obtenerDao_Equipo()
        {
            return new Dao_Equipo();
        }

        public static IDao_ListaValores obtenerDao_ListaValores()
        {
            return new Dao_ListaValores();
        }

        public static IDao_Mantenimiento obtenerDao_Mantenimiento()
        {
            return new Dao_Mantenimiento();
        }
    }
}
