﻿// DAL: Data Access Layer - Capa Acceso Datos Equipos
using System;
using Oracle.DataAccess.Client;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Dao_Equipo : Dao_General, IDao_Equipo
    {
        // Default Constructor
        public Dao_Equipo() { }

        public ArrayList cargarListado()
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas("TBL_EQUIPOS");
            return arlLista;
        }

        public void cargarDatosCombos (string tabla)
        {
            cargarArray(tabla);
        }
		
        public Equipo obtenerEquipo(int datoBuscar)
        {
            Equipo equipo = new Equipo();
            try
            {
                buscarRegistro("TBL_EQUIPOS", datoBuscar);
                if (sdr.Read())
                {
                    equipo.Equipo_id = Convert.ToInt32(sdr["EQUIPO_ID"].ToString());
                    equipo.Nombre_equipo = sdr["NOMBRE_EQUIPO"].ToString();
                    equipo.Marca = Convert.ToInt32(sdr["MARCA"].ToString());
                    equipo.Serie = sdr["SERIE"].ToString();
                    equipo.Linea = Convert.ToInt32(sdr["LINEA"].ToString());
                    if (sdr.GetBoolean(sdr.GetOrdinal("LUBRICACION"))) equipo.Lubricacion = 1;
                }
                else
                {
                    equipo = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return equipo;

        }


        public int guardarEquipo(Equipo equipo, int Usuario)
        {
            Int32 resultado = -1;
            try
            {
                using (Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("SPR_IU_Equipos", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_EQUIPO_ID", OracleDbType.Int32, 10).Value = equipo.Equipo_id;
                    Cmd.Parameters.Add("p_NOMBRE_EQUIPO", OracleDbType.Varchar2, 50).Value = equipo.Nombre_equipo;
                    Cmd.Parameters.Add("p_MARCA", OracleDbType.Int32, 10).Value = equipo.Marca;
                    Cmd.Parameters.Add("p_SERIE", OracleDbType.Varchar2, 20).Value = equipo.Serie;
                    Cmd.Parameters.Add("p_LINEA", OracleDbType.Int32, 10).Value = equipo.Linea;
                    Cmd.Parameters.Add("p_LUBRICACION", OracleDbType.Int32, 1).Value = equipo.Lubricacion;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", OracleDbType.Varchar2, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_resultado", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
		    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = (Int32)(Oracle.DataAccess.Types.OracleDecimal)Cmd.Parameters["p_resultado"].Value;
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }


        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_EQUIPOS");
            return resultado;
        }

    }
}