﻿// DAL: Data Access Layer - Capa Acceso Datos
using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Dao_General
    {
        // Default Constructor
        public Dao_General() { }

        public MySqlConnection Cn;
        public MySqlDataReader sdr;
        public MySqlCommand Cmd;

        public void buscarRegistro(string tabla, int datoBuscar)
        {
            try
            {
                Cn = new MySqlConnection(Conexion.obtenerConexion);
                Cmd = new MySqlCommand("SPR_R_BuscarRegistro", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_TABLA", MySqlDbType.VarChar, 20).Value = tabla;
                Cmd.Parameters.Add("p_DATOBUSCAR", MySqlDbType.VarChar, 50).Value = datoBuscar;                
                Cn.Open();
                sdr = Cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public ArrayList cargarListas(string tabla)
        {
            ArrayList arlLista = new ArrayList();
            try
            {
                using (MySqlConnection Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("SPR_R_CargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", MySqlDbType.VarChar, 30).Value = tabla;
                    Cn.Open();
                    sdr = Cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                         arlListado.Add(new CargarListado(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString(), sdr.GetValue(2).ToString(), sdr.GetValue(3).ToString(), sdr.GetValue(4).ToString(), sdr.GetValue(5).ToString())); 
                    }
                    sdr.Close();
                 }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return arlLista;
        }

        public ArrayList cargarArray(string tabla)
        {
            ArrayList arlListControlProgramacion = new ArrayList();
            try
            {
                using (Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("SPR_R_CargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", MySqlDbType.VarChar, 30).Value = tabla;
                    Cn.Open();
                    sdr = Cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        if (tabla == "CONTROLEQUIPOS") // Datos para carga de Combos en Equipos
                        {
                            if(sdr.GetValue(2).ToString() == "LINEAS")
                            {
                                Funciones.Lista1.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString()));
                            }
                            else // Marcas
                            {
                                Funciones.Lista2.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString()));
                            }
                        }
                        else // Datos para carga de Combos en Mantenimiento
                        {
                            if (sdr.GetValue(2).ToString() == "EQUIPOS")
                            {
                                Funciones.Lista1.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString()));
                            }
                            else // Operarios
                            {
                                Funciones.Lista2.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString()));
                            }
                        }                      
                    }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return arlListControlProgramacion;
        }

        public int borrarRegistro(int datoEliminar, string tabla)
        {
            int resultado = 0;
            try
            {
                using (Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("SPR_D_Registro", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", MySqlDbType.VarChar, 20).Value = tabla;
                    Cmd.Parameters.Add("p_CONDICION", MySqlDbType.Int32, 10).Value = datoEliminar;
                    Cmd.Parameters.Add("p_resultado", MySqlDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_resultado"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public void liberarRecursos()
        {
            Cmd.Dispose();
            if (Cn != null)
            {
                Cn.Close();
                Cn.Dispose();
            }
        }
    }
}
