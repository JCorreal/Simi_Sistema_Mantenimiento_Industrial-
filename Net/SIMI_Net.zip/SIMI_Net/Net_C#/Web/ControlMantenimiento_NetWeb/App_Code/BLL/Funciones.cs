﻿// Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones

using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using ControlMantenimiento_NetWeb.DAL;
using System.Collections;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.BLL
{
    public class Funciones
    {
        public static string Pagina = null;
        public static int ParametroBuscar = 0;              
        public static string MensajeError;
        public static int UsuarioConectado;

        public static ArrayList arlListadoGeneral;
        private static Dao_Operario dao_operario;
        private static Dao_Equipo dao_equipo;
        private static Dao_ListaValores dao_listavalores;
        private static Dao_Mantenimiento dao_mantenimiento;

        public Funciones() { }

        public static Controlador_Operario CrearControlador_Operario()
        {
            dao_operario = (Dao_Operario)AccesoDatosFactory.obtenerDao_Operario();
            return new Controlador_Operario(dao_operario);
        }

        public static Controlador_Equipo CrearControlador_Equipo()
        {
            dao_equipo = (Dao_Equipo)AccesoDatosFactory.obtenerDao_Equipo();
            return new Controlador_Equipo(dao_equipo);
        }

        public static Controlador_ListaValores CrearControlador_ListaValores()
        {
            dao_listavalores = (Dao_ListaValores)AccesoDatosFactory.obtenerDao_ListaValores();
            return new Controlador_ListaValores(dao_listavalores);
        }

        public static Controlador_Mantenimiento CrearControlador_Mantenimiento()
        {
            dao_mantenimiento = (Dao_Mantenimiento)AccesoDatosFactory.obtenerDao_Mantenimiento();
            return new Controlador_Mantenimiento(dao_mantenimiento);
        }

       
      
        // Funcion para validar campos de formulario vacios 
        public static bool validar_CampoVacio(string cadena)
        {
            bool Vacio = false;
            cadena = cadena.Trim();
            if (string.IsNullOrEmpty(cadena))
            {
                Vacio = true;
            }
            return Vacio;
        }


        // Funcion para validar direcciones de correo electronico
        public static bool validar_Correo(string cadena)
        {
            cadena = cadena.Trim();
            return !Regex.IsMatch(cadena, "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");
        }
        
        // Funcion para validar que haya solo numeros en un campo de texto
        public static bool validar_SoloNumeros(string cadena)
        {
            bool status = false;
            for (int i = 0; i < cadena.Length; i++)
            {
                if (!Char.IsNumber(cadena[i]))
                {
                    status = true;
                    break;
                }
            }
            return status;
        }

        // Funcion para limpiar los controles en un formulario (Solo TextBox)
        public static void limpiarForma(Control strWebForm)    
        {         
             foreach (Control strControl in strWebForm.Controls)
             {
                 if (strControl.GetType().ToString().Equals("System.Web.UI.WebControls.TextBox"))
                 {
                     ((TextBox)strControl).Text = string.Empty;
                 }
             }
        }

        // Funcion para comprobar existencia de numeros en nombres
        public static bool validar_SoloLetras(string cadena)
        {
            bool Resultado = false;
            for (int i = 0; i < cadena.Length; i++)
            {
                if (Char.IsNumber(cadena[i]))
                {
                    Resultado = true;
                    break;
                }
            }
            return Resultado;
        }

        // Funcion para eliminar posibles espacios de tabulacion
        public static string eliminarTabulador(string cadena, string Conversion)
        {
            cadena = cadena.Trim();
            while (cadena.IndexOf("  ", 0) != -1)
            {
                cadena = (cadena.Replace("  ", " "));
            }
            if (Conversion == "MAY")
            {
                cadena = cadena.ToUpper();
            }
            if (Conversion == "1MAY") // Organizar primera letra en Mayuscula y siguientes en Minuscula
            {
                cadena = cadena.ToLower();
                cadena = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(cadena);
            }
            return cadena;
        }

        /* Función para buscar en el Array el criterio ingresado por el usuario, sin embargo hacerlo así
           tiene sus reparos, pues normalmente se cargan en pantalla a lo sumo unos 20 registros, que es 
           lo que cabe en un formulario, ya si se quiere buscar un registro específico, se consulta en BD.

           Porque en escenarios donde se manejen muchos registros como ventas-pedidos, eso implica cargar 
           millones de registros en un array, y se abusa de la RAM, generando tráfico de red innecesario. 
        
           De cualquier forma el Procedimiento Almacenado: SPR_R_CargarListado tiene implementado como 
           parámetro para hacer la búsqueda por el criterio elegido y devolver ese registro.  */

        public static ArrayList cargarBusqueda(string criterio)
        {
            ArrayList arlBusqueda = new ArrayList();
            for (int i = 0; i < arlListadoGeneral.Count; i++)
            {
                CargarListado dato = (CargarListado)Funciones.arlListadoGeneral[i];
                {
                    if (criterio == dato.Columna2)
                    {                        
                        arlBusqueda.Add(new CargarListado(dato.Columna1, dato.Columna2, dato.Columna3, dato.Columna4, dato.Columna5, dato.Columna6));                        
                        break;
                    }
                }
            }
            return arlBusqueda;
        }

        public static void mostrarAyuda()
        {
	     /* Estas líneas son las encargadas de llamar el archivo de ayudas chm o PDF.
			Pero en algunos servidores no funciona, porque como mecanismo de protección
			impiden que se pueda ejecutar un archivo con extensión .chm alojado allí.
			  
			La solución es ubicar el archivo Ayuda.chm en cualquier parte del disco duro 
			y modificar la ruta, en la variable destino. */
            string destino = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + "Ayudas\\Ayuda.chm";
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = destino;
            proc.Start();
            proc.Dispose();
        }
        
    }
}

