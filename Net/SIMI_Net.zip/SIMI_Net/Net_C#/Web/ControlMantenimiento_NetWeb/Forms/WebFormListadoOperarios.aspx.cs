﻿using System;
using ControlMantenimiento_NetWeb.BLL;
using System.Web.UI.WebControls;
using System.Collections;

public partial class Forms_WebFormListadoOperarios : System.Web.UI.Page
{
    private Controlador_Operario _controlador = Funciones.CrearControlador_Operario();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["TIPO_USUARIO"] == null)
        {
            Response.Redirect("~/Forms/WebFormAcceso.aspx");
        }
        if (!this.IsPostBack)
        {
            this.BindRepeater();
        }
    }

    private void BindRepeater()
    {
        Funciones.arlListadoGeneral = new ArrayList();
        Funciones.arlListadoGeneral = _controlador.cargarListado();
        Repeater1.DataSource = Funciones.arlListadoGeneral;       
        Repeater1.DataBind();
    }



    protected void ButtonBuscar_Click(object sender, EventArgs e)
    {
        TextBoxBuscar.Text = TextBoxBuscar.Text.Trim();
        LabelInformacion.Text = "";
        LabelInformacion.ForeColor = System.Drawing.Color.Red;
        if (string.IsNullOrEmpty(TextBoxBuscar.Text.Trim()))
        {
            LabelInformacion.Text = Mensajes.MensajeCampoRequerido;
            TextBoxBuscar.Focus();
        }
        else if (TextBoxBuscar.Text.Substring(0, 1) == "0")
        {
            LabelInformacion.Text = Mensajes.Mensaje6;
            TextBoxBuscar.Focus();
        }
        else
        {
            Repeater1.DataSource = Funciones.cargarBusqueda(TextBoxBuscar.Text.Trim());
            Repeater1.DataBind();
        }

    }



    protected void Repeater1_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Editar")
        {
            Funciones.ParametroBuscar = Convert.ToInt32(((Button)e.CommandSource).CommandArgument);
            Response.Redirect("~/Forms/WebFormOperarios.aspx");
        }

        else if (e.CommandName == "Eliminar")
        {
            int Resultado;
            Resultado = _controlador.eliminarRegistro(Convert.ToInt32(((Button)e.CommandSource).CommandArgument));

            if (Resultado == 0)
            {
                Response.Redirect("~/Forms/WebFormListadoOperarios.aspx");
            }
            else if (Resultado == 1)
            {
                LabelInformacion.Text = Mensajes.Mensaje20;
            }
            else
            {
                LabelInformacion.Text = Mensajes.MensajeErrorBD;
                Response.Redirect("~/Forms/WebFormError.aspx");
            }
        }

    }

    protected void ButtonNuevo_Click(object sender, EventArgs e)
    {
        Funciones.ParametroBuscar = 0;
        Response.Redirect("~/Forms/WebFormOperarios.aspx");
    }
}
