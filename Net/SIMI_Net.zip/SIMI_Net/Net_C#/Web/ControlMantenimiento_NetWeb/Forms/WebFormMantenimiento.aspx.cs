﻿using System;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.BLL;
using System.Collections;

public partial class Forms_WebFormMantenimiento : System.Web.UI.Page
{
    private Controlador_Mantenimiento _controlador = Funciones.CrearControlador_Mantenimiento();

    int ElMantenimiento = 0;

    protected void Page_Init(object sender, EventArgs e)
    {
        ArrayList arlListado = new ArrayList();
        ArrayList arlListadoEquipos = new ArrayList();
        ArrayList arlListadoOperarios = new ArrayList();
        if (Funciones.ParametroBuscar != 0)
        {
            arlListado = _controlador.controlarProgramacion("PROGRAMACION");
        }
        else
        {
            arlListado = _controlador.controlarProgramacion("PROGRAMAR");
        }

        for (int i = 0; i < arlListado.Count; i++)
        {
            if (Convert.ToString(arlListado[i]).Trim().Equals("EQUIPOS"))
            {
                arlListadoEquipos.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                i++; i++;
            }
            else if (Convert.ToString(arlListado[i]).Trim().Equals("OPERARIOS"))
            {
                arlListadoOperarios.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                i++; i++;
            }
        }
        if (arlListadoOperarios == null)
        {
            Funciones.MensajeError = Mensajes.Mensaje13;
            Response.Redirect("~/Forms/WebFormError.aspx");
        }
        else if (arlListadoEquipos == null)
        {
            Funciones.MensajeError = Mensajes.Mensaje14;
            Response.Redirect("~/Forms/WebFormError.aspx");
        }
        else
        {
            DropDownListEquipos.Items.Clear();
            DropDownListEquipos.DataSource = arlListadoEquipos;
            DropDownListEquipos.DataValueField = "CODIGO";     // Codigo o Documento a relacionar en BD
            DropDownListEquipos.DataTextField = "DETALLE";     // Visualizar Nombre o Detalle           
            DropDownListEquipos.DataBind();

            DropDownListOperarios.Items.Clear();
            DropDownListOperarios.DataSource = arlListadoOperarios;
            DropDownListOperarios.DataValueField = "CODIGO";
            DropDownListOperarios.DataTextField = "DETALLE";
            DropDownListOperarios.DataBind();

            if (Funciones.ParametroBuscar != 0)
            {
                LlenarCampos();
            }
        }
    }

    private void LlenarCampos()
    {
        Mantenimiento mantenimiento = (Mantenimiento)_controlador.obtenerRegistro(Funciones.ParametroBuscar);
        if (mantenimiento != null)
        {
            ElMantenimiento = mantenimiento.Mantenimiento_id;
            DropDownListEquipos.SelectedValue = mantenimiento.Equipo_id.ToString();
            DropDownListEquipos.Enabled = false;
            DropDownListOperarios.SelectedValue = mantenimiento.Operario_id.ToString();
            CalendarFecha.SelectedDate = mantenimiento.Fecha;
            CalendarFecha.VisibleDate = mantenimiento.Fecha;
            CalendarFecha.Caption = mantenimiento.Fecha.ToShortDateString();
            TextBoxObservaciones.Text = mantenimiento.Observaciones;
        }

        DropDownListOperarios.Focus();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["TIPO_USUARIO"] == null)
        {
            Response.Redirect("~/Forms/WebFormAcceso.aspx");
        }
    }

    protected void ButtonGrabar_Click(object sender, EventArgs e)
    {
        if (Verificar())
        {
            Guardar();
        }
    }

    private bool Verificar()
    {
        if (CalendarFecha.SelectedDate < DateTime.Now.Date)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje27;
            CalendarFecha.Focus();
            return false;
        }
        return true;
    }

    private void Guardar()
    {
        int Resultado;        
        Mantenimiento mantenimiento = new Mantenimiento();
        mantenimiento.Mantenimiento_id = ElMantenimiento;
        mantenimiento.Equipo_id = Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString());
        mantenimiento.Operario_id = Convert.ToDouble(DropDownListOperarios.SelectedValue.ToString());
        mantenimiento.Fecha = Convert.ToDateTime(CalendarFecha.SelectedDate);
        mantenimiento.Observaciones = TextBoxObservaciones.Text.Trim();

        Resultado = _controlador.guardarMantenimiento(mantenimiento);
        if (Resultado == 0)
        {
            mantenimiento = null;
            Funciones.ParametroBuscar = 0;
            Response.Redirect("~/Forms/WebFormRespuesta.aspx");
        }
        else if (Resultado == 1)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje10;
            DropDownListOperarios.Focus();
        }
        else
        {
            Response.Redirect("~/Forms/WebFormError.aspx");
        }
    }

    protected void ImageButtonAyuda_Click(object sender, System.Web.UI.ImageClickEventArgs e)
    {
        /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
        proc.EnableRaisingEvents = false;
        proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/Ayudas/Ayuda.chm";
        proc.Start();
        proc.Dispose();*/

        // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        // donde descomprimió el archivo descargado de la web
    }
}
