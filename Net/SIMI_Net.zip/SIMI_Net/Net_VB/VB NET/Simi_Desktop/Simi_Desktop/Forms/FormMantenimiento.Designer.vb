﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMantenimiento
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMantenimiento))
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.ButtonSalir = New System.Windows.Forms.Button()
        Me.ButtonAyuda = New System.Windows.Forms.Button()
        Me.DropDownListEquipos = New System.Windows.Forms.ComboBox()
        Me.ButtonEliminar = New System.Windows.Forms.Button()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        Me.label4 = New System.Windows.Forms.Label()
        Me.ButtonGrabar = New System.Windows.Forms.Button()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.DropDownListOperarios = New System.Windows.Forms.ComboBox()
        Me.TextBoxObservaciones = New System.Windows.Forms.TextBox()
        Me.DateTimePickerFecha = New System.Windows.Forms.DateTimePicker()
        Me.errorPro = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.Label_Titulo = New System.Windows.Forms.Label()
        Me.panel2.SuspendLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.Color.White
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.ButtonSalir)
        Me.panel2.Controls.Add(Me.ButtonAyuda)
        Me.panel2.Controls.Add(Me.DropDownListEquipos)
        Me.panel2.Controls.Add(Me.ButtonEliminar)
        Me.panel2.Controls.Add(Me.ButtonCancelar)
        Me.panel2.Controls.Add(Me.label4)
        Me.panel2.Controls.Add(Me.ButtonGrabar)
        Me.panel2.Controls.Add(Me.label3)
        Me.panel2.Controls.Add(Me.label2)
        Me.panel2.Controls.Add(Me.label1)
        Me.panel2.Controls.Add(Me.DropDownListOperarios)
        Me.panel2.Controls.Add(Me.TextBoxObservaciones)
        Me.panel2.Controls.Add(Me.DateTimePickerFecha)
        Me.panel2.Location = New System.Drawing.Point(405, 188)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(533, 346)
        Me.panel2.TabIndex = 327
        '
        'ButtonSalir
        '
        Me.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSalir.ForeColor = System.Drawing.Color.Black
        Me.ButtonSalir.Image = CType(resources.GetObject("ButtonSalir.Image"), System.Drawing.Image)
        Me.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonSalir.Location = New System.Drawing.Point(334, 284)
        Me.ButtonSalir.Name = "ButtonSalir"
        Me.ButtonSalir.Size = New System.Drawing.Size(60, 35)
        Me.ButtonSalir.TabIndex = 7
        Me.ButtonSalir.TabStop = False
        Me.ButtonSalir.Text = "Salir"
        Me.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonSalir.UseVisualStyleBackColor = False
        '
        'ButtonAyuda
        '
        Me.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonAyuda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAyuda.ForeColor = System.Drawing.Color.Black
        Me.ButtonAyuda.Image = CType(resources.GetObject("ButtonAyuda.Image"), System.Drawing.Image)
        Me.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonAyuda.Location = New System.Drawing.Point(277, 284)
        Me.ButtonAyuda.Name = "ButtonAyuda"
        Me.ButtonAyuda.Size = New System.Drawing.Size(60, 35)
        Me.ButtonAyuda.TabIndex = 6
        Me.ButtonAyuda.TabStop = False
        Me.ButtonAyuda.Text = "Ayuda"
        Me.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonAyuda.UseVisualStyleBackColor = False
        '
        'DropDownListEquipos
        '
        Me.DropDownListEquipos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DropDownListEquipos.FormattingEnabled = True
        Me.DropDownListEquipos.Location = New System.Drawing.Point(152, 72)
        Me.DropDownListEquipos.Name = "DropDownListEquipos"
        Me.DropDownListEquipos.Size = New System.Drawing.Size(269, 21)
        Me.DropDownListEquipos.TabIndex = 335
        Me.DropDownListEquipos.TabStop = False
        '
        'ButtonEliminar
        '
        Me.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonEliminar.Enabled = False
        Me.ButtonEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEliminar.ForeColor = System.Drawing.Color.Black
        Me.ButtonEliminar.Image = CType(resources.GetObject("ButtonEliminar.Image"), System.Drawing.Image)
        Me.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonEliminar.Location = New System.Drawing.Point(220, 284)
        Me.ButtonEliminar.Name = "ButtonEliminar"
        Me.ButtonEliminar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonEliminar.TabIndex = 5
        Me.ButtonEliminar.TabStop = False
        Me.ButtonEliminar.Text = "Eliminar"
        Me.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonEliminar.UseVisualStyleBackColor = False
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCancelar.ForeColor = System.Drawing.Color.Black
        Me.ButtonCancelar.Image = CType(resources.GetObject("ButtonCancelar.Image"), System.Drawing.Image)
        Me.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonCancelar.Location = New System.Drawing.Point(163, 284)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonCancelar.TabIndex = 4
        Me.ButtonCancelar.TabStop = False
        Me.ButtonCancelar.Text = "Cancelar"
        Me.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonCancelar.UseVisualStyleBackColor = False
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(55, 221)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(91, 13)
        Me.label4.TabIndex = 334
        Me.label4.Text = "Observaciones"
        '
        'ButtonGrabar
        '
        Me.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonGrabar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGrabar.ForeColor = System.Drawing.Color.Black
        Me.ButtonGrabar.Image = CType(resources.GetObject("ButtonGrabar.Image"), System.Drawing.Image)
        Me.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonGrabar.Location = New System.Drawing.Point(107, 284)
        Me.ButtonGrabar.Name = "ButtonGrabar"
        Me.ButtonGrabar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonGrabar.TabIndex = 3
        Me.ButtonGrabar.TabStop = False
        Me.ButtonGrabar.Text = "Grabar"
        Me.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonGrabar.UseVisualStyleBackColor = False
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(55, 161)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(42, 13)
        Me.label3.TabIndex = 333
        Me.label3.Text = "Fecha"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(55, 114)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(55, 13)
        Me.label2.TabIndex = 332
        Me.label2.Text = "Operario"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(55, 75)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(46, 13)
        Me.label1.TabIndex = 331
        Me.label1.Text = "Equipo"
        '
        'DropDownListOperarios
        '
        Me.DropDownListOperarios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DropDownListOperarios.FormattingEnabled = True
        Me.DropDownListOperarios.Location = New System.Drawing.Point(152, 111)
        Me.DropDownListOperarios.Name = "DropDownListOperarios"
        Me.DropDownListOperarios.Size = New System.Drawing.Size(269, 21)
        Me.DropDownListOperarios.TabIndex = 329
        Me.DropDownListOperarios.TabStop = False
        '
        'TextBoxObservaciones
        '
        Me.TextBoxObservaciones.Location = New System.Drawing.Point(152, 197)
        Me.TextBoxObservaciones.Multiline = True
        Me.TextBoxObservaciones.Name = "TextBoxObservaciones"
        Me.TextBoxObservaciones.Size = New System.Drawing.Size(269, 63)
        Me.TextBoxObservaciones.TabIndex = 328
        Me.TextBoxObservaciones.TabStop = False
        '
        'DateTimePickerFecha
        '
        Me.DateTimePickerFecha.Location = New System.Drawing.Point(152, 155)
        Me.DateTimePickerFecha.Name = "DateTimePickerFecha"
        Me.DateTimePickerFecha.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePickerFecha.TabIndex = 327
        Me.DateTimePickerFecha.TabStop = False
        '
        'errorPro
        '
        Me.errorPro.ContainerControl = Me
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.Teal
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.Label_Titulo)
        Me.panel1.Location = New System.Drawing.Point(405, 149)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(533, 60)
        Me.panel1.TabIndex = 336
        '
        'Label_Titulo
        '
        Me.Label_Titulo.AutoSize = True
        Me.Label_Titulo.BackColor = System.Drawing.Color.Transparent
        Me.Label_Titulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Titulo.ForeColor = System.Drawing.Color.White
        Me.Label_Titulo.Image = CType(resources.GetObject("Label_Titulo.Image"), System.Drawing.Image)
        Me.Label_Titulo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label_Titulo.Location = New System.Drawing.Point(3, 16)
        Me.Label_Titulo.Name = "Label_Titulo"
        Me.Label_Titulo.Size = New System.Drawing.Size(175, 25)
        Me.Label_Titulo.TabIndex = 0
        Me.Label_Titulo.Text = "       Mantenimiento"
        Me.Label_Titulo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'FormMantenimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1188, 683)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "FormMantenimiento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Mantenimiento"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents DropDownListEquipos As System.Windows.Forms.ComboBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents DropDownListOperarios As System.Windows.Forms.ComboBox
    Private WithEvents TextBoxObservaciones As System.Windows.Forms.TextBox
    Private WithEvents DateTimePickerFecha As System.Windows.Forms.DateTimePicker
    Private WithEvents ButtonEliminar As System.Windows.Forms.Button
    Private WithEvents ButtonAyuda As System.Windows.Forms.Button
    Private WithEvents ButtonCancelar As System.Windows.Forms.Button
    Private WithEvents ButtonSalir As System.Windows.Forms.Button
    Private WithEvents ButtonGrabar As System.Windows.Forms.Button
    Private WithEvents errorPro As System.Windows.Forms.ErrorProvider
    Private WithEvents panel1 As Panel
    Friend WithEvents Label_Titulo As Label
End Class
