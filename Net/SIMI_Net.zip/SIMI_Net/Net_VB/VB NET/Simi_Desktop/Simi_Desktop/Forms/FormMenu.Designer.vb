﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMenu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMenu))
        Me.Button_Operarios = New System.Windows.Forms.Button()
        Me.Button_Equipos = New System.Windows.Forms.Button()
        Me.Button_Marcas = New System.Windows.Forms.Button()
        Me.Button_Lineas = New System.Windows.Forms.Button()
        Me.Button_Clave = New System.Windows.Forms.Button()
        Me.Button_Mantenimiento = New System.Windows.Forms.Button()
        Me.lblUsuarioConectado = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button_Operarios
        '
        Me.Button_Operarios.Image = CType(resources.GetObject("Button_Operarios.Image"), System.Drawing.Image)
        Me.Button_Operarios.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Operarios.Location = New System.Drawing.Point(59, 279)
        Me.Button_Operarios.Name = "Button_Operarios"
        Me.Button_Operarios.Size = New System.Drawing.Size(115, 32)
        Me.Button_Operarios.TabIndex = 0
        Me.Button_Operarios.Text = "Operarios"
        Me.Button_Operarios.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Operarios.UseVisualStyleBackColor = True
        '
        'Button_Equipos
        '
        Me.Button_Equipos.Enabled = False
        Me.Button_Equipos.Image = CType(resources.GetObject("Button_Equipos.Image"), System.Drawing.Image)
        Me.Button_Equipos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Equipos.Location = New System.Drawing.Point(59, 317)
        Me.Button_Equipos.Name = "Button_Equipos"
        Me.Button_Equipos.Size = New System.Drawing.Size(115, 32)
        Me.Button_Equipos.TabIndex = 1
        Me.Button_Equipos.Text = "Equipos"
        Me.Button_Equipos.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Equipos.UseVisualStyleBackColor = True
        '
        'Button_Marcas
        '
        Me.Button_Marcas.Enabled = False
        Me.Button_Marcas.Image = CType(resources.GetObject("Button_Marcas.Image"), System.Drawing.Image)
        Me.Button_Marcas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Marcas.Location = New System.Drawing.Point(59, 355)
        Me.Button_Marcas.Name = "Button_Marcas"
        Me.Button_Marcas.Size = New System.Drawing.Size(115, 32)
        Me.Button_Marcas.TabIndex = 2
        Me.Button_Marcas.Text = "Marcas"
        Me.Button_Marcas.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Marcas.UseVisualStyleBackColor = True
        '
        'Button_Lineas
        '
        Me.Button_Lineas.Enabled = False
        Me.Button_Lineas.Image = CType(resources.GetObject("Button_Lineas.Image"), System.Drawing.Image)
        Me.Button_Lineas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Lineas.Location = New System.Drawing.Point(59, 393)
        Me.Button_Lineas.Name = "Button_Lineas"
        Me.Button_Lineas.Size = New System.Drawing.Size(115, 32)
        Me.Button_Lineas.TabIndex = 3
        Me.Button_Lineas.Text = "Lineas"
        Me.Button_Lineas.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Lineas.UseVisualStyleBackColor = True
        '
        'Button_Clave
        '
        Me.Button_Clave.Image = CType(resources.GetObject("Button_Clave.Image"), System.Drawing.Image)
        Me.Button_Clave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Clave.Location = New System.Drawing.Point(59, 469)
        Me.Button_Clave.Name = "Button_Clave"
        Me.Button_Clave.Size = New System.Drawing.Size(115, 32)
        Me.Button_Clave.TabIndex = 4
        Me.Button_Clave.Text = "Cambio Clave"
        Me.Button_Clave.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Clave.UseVisualStyleBackColor = True
        '
        'Button_Mantenimiento
        '
        Me.Button_Mantenimiento.Enabled = False
        Me.Button_Mantenimiento.Image = CType(resources.GetObject("Button_Mantenimiento.Image"), System.Drawing.Image)
        Me.Button_Mantenimiento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Mantenimiento.Location = New System.Drawing.Point(59, 431)
        Me.Button_Mantenimiento.Name = "Button_Mantenimiento"
        Me.Button_Mantenimiento.Size = New System.Drawing.Size(115, 32)
        Me.Button_Mantenimiento.TabIndex = 5
        Me.Button_Mantenimiento.Text = "Mantenimento"
        Me.Button_Mantenimiento.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Mantenimiento.UseVisualStyleBackColor = True
        '
        'lblUsuarioConectado
        '
        Me.lblUsuarioConectado.AutoSize = True
        Me.lblUsuarioConectado.BackColor = System.Drawing.Color.Transparent
        Me.lblUsuarioConectado.ForeColor = System.Drawing.Color.White
        Me.lblUsuarioConectado.Location = New System.Drawing.Point(1, 0)
        Me.lblUsuarioConectado.Name = "lblUsuarioConectado"
        Me.lblUsuarioConectado.Size = New System.Drawing.Size(63, 13)
        Me.lblUsuarioConectado.TabIndex = 6
        Me.lblUsuarioConectado.Text = "Bienvenido:"
        '
        'FormMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1085, 606)
        Me.Controls.Add(Me.lblUsuarioConectado)
        Me.Controls.Add(Me.Button_Mantenimiento)
        Me.Controls.Add(Me.Button_Clave)
        Me.Controls.Add(Me.Button_Lineas)
        Me.Controls.Add(Me.Button_Marcas)
        Me.Controls.Add(Me.Button_Equipos)
        Me.Controls.Add(Me.Button_Operarios)
        Me.Name = "FormMenu"
        Me.Text = "Simi"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button_Operarios As Button
    Friend WithEvents Button_Equipos As Button
    Friend WithEvents Button_Marcas As Button
    Friend WithEvents Button_Lineas As Button
    Friend WithEvents Button_Clave As Button
    Friend WithEvents Button_Mantenimiento As Button
    Friend WithEvents lblUsuarioConectado As Label
End Class
