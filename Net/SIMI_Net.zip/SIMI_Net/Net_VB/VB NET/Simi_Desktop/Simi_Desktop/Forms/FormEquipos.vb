﻿Option Strict On

Public Class FormEquipos
    Private _controlador As Controlador_Equipo = Funciones.crearControlador_Equipo()
    Private grabar As Boolean
    Private _Equipo As Equipo
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub FormEquipos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        DropDownListLineas.ValueMember = "CODIGO"
        DropDownListLineas.DisplayMember = "DETALLE"
        DropDownListLineas.DataSource = Funciones.Lista1

        DropDownListMarcas.ValueMember = "CODIGO"
        DropDownListMarcas.DisplayMember = "DETALLE"
        DropDownListMarcas.DataSource = Funciones.Lista2

        If (Funciones.ParametroBuscar <> 0) Then
            consultarBD()
        End If

    End Sub

    Private Sub consultarBD()
        _Equipo = CType(_controlador.obtenerEquipo(Funciones.ParametroBuscar), Equipo)
        If (Not _Equipo Is Nothing) Then
            poblarFormulario()
        End If
    End Sub

    Private Sub poblarFormulario()
        ButtonEliminar.Enabled = True
        TextBoxNombreEquipo.Text = _Equipo.Nombre_Equipo
        DropDownListMarcas.SelectedValue = _Equipo.Marca.ToString()
        TextBoxSerie.Text = _Equipo.Serie
        DropDownListLineas.SelectedValue = _Equipo.Linea.ToString()
        CheckBoxLubricacion.Checked = If((_Equipo.Lubricacion = 1), True, False)
        TextBoxNombreEquipo.Focus()
    End Sub

    Private Sub TextBoxNombreEquipo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombreEquipo.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.validar_CampoVacio(TextBoxNombreEquipo.Text)) Then
                grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxNombreEquipo.Focus()
                errorPro.SetError(TextBoxNombreEquipo, Mensajes.MensajeCampoRequerido)
            Else
                TextBoxNombreEquipo.Text = Funciones.eliminarTabulador(TextBoxNombreEquipo.Text, "1MAY")
                errorPro.Clear()
                DropDownListMarcas.Focus()
            End If
        End If
    End Sub

    Private Sub DropDownListMarcas_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListMarcas.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            TextBoxSerie.Focus()
        End If
    End Sub

    Private Sub TextBoxSerie_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxSerie.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.validar_CampoVacio(TextBoxSerie.Text)) Then
                grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxSerie.Focus()
                errorPro.SetError(TextBoxSerie, Mensajes.MensajeCampoRequerido)
            Else
                DropDownListLineas.Focus()
            End If
        End If
    End Sub

    Private Sub DropDownListLineas_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListLineas.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            ButtonGrabar.Focus()
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        TextBoxNombreEquipo_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            TextBoxSerie_KeyPress(ButtonGrabar, tecla)
            If (grabar) Then
                Guardar()
            End If
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        _Equipo = New Equipo
        _Equipo.Equipo_id = Funciones.ParametroBuscar
        _Equipo.Nombre_Equipo = TextBoxNombreEquipo.Text.Trim
        _Equipo.Marca = Convert.ToInt32(DropDownListMarcas.SelectedValue.ToString())
        _Equipo.Serie = TextBoxSerie.Text.Trim
        _Equipo.Linea = Convert.ToInt32(DropDownListLineas.SelectedValue.ToString())
        _Equipo.Lubricacion = If((CheckBoxLubricacion.Checked), 1, 0)
        Resultado = _controlador.guardarEquipo(_Equipo)
        If (Resultado = 0) Then
            If (Funciones.ParametroBuscar = 0) Then
                MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Limpiar()
            Else
                MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            End If
        ElseIf (Resultado = 1) Then
                MessageBox.Show(Mensajes.Mensaje7, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxSerie.Focus()
                errorPro.SetError(TextBoxSerie, Mensajes.Mensaje7)
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub Limpiar()
        If (Funciones.ParametroBuscar = 0) Then
            For Each oControls As Control In panel2.Controls
                If (TypeOf oControls Is TextBox) Then
                    oControls.Text = String.Empty
                    Continue For
                End If
            Next
            errorPro.Clear()
            CheckBoxLubricacion.Checked = False
            TextBoxNombreEquipo.Focus()
        Else
            poblarFormulario()
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            If (_controlador.eliminarRegistro(Funciones.ParametroBuscar) = 0) Then
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _Equipo = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        Funciones.MostrarAyuda()
    End Sub


End Class
