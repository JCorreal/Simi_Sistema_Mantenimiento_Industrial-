﻿Option Strict On

Public Class FormListados

    Private col_Operarios() As String = {"OPERARIO_ID", "DOCUMENTO", "NOMBRE_COMPLETO", "CORREO", "TELEFONO"}
    Private col_Equipos() As String = {"EQUIPO_ID", "SERIE", "NOMBRE_EQUIPO", "MARCA", "LINEA", "LUBRICACION"}
    Private col_Mantenimiento() As String = {"MANTENIMIENTO_ID", "SERIE", "NOMBRE_EQUIPO", "FECHA", "OPERARIO"}
    Private col_Marcas() As String = {"LISTAVALORES_ID", "NOMBRE", "DESCRIPCION", "TIPO"}

    Public Sub FormListados(ByVal listar As String)
        InitializeComponent()
    End Sub

    Private Sub FormListados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        traerDatos(Funciones.Source)
    End Sub

    Private Sub traerDatos(ByVal tabla As String)
        Dim arlListado As New ArrayList()
        Select Case tabla
            Case "Operarios"
                Dim _controlador As Controlador_Operario = Funciones.crearControlador_Operario()
                arlListado = _controlador.cargarListado()
                If (arlListado.Count > 0) Then
                    DataGridView1.DataSource = arlListado
                    ponerEncabezados(col_Operarios)
                    DataGridView1.Columns(0).Visible = False
                    DataGridView1.Columns(5).Visible = False
                End If
            Case "Equipos"
                Label_Buscar.Text = "Equipo se busca por Serie"
                Dim _controladore As Controlador_Equipo = Funciones.crearControlador_Equipo()
                arlListado = _controladore.cargarListado()
                If (arlListado.Count > 0) Then
                    DataGridView1.DataSource = arlListado
                    ponerEncabezados(col_Equipos)
                    DataGridView1.Columns(0).Visible = False
                End If
            Case "Mantenimiento"
                Label_Buscar.Text = "Mantenimiento se busca por Serie de Equipo"
                Dim _controladormt As Controlador_Mantenimiento = Funciones.crearControlador_Mantenimiento()
                arlListado = _controladormt.cargarListado()
                If (arlListado.Count > 0) Then
                    DataGridView1.DataSource = arlListado
                    ponerEncabezados(col_Mantenimiento)
                    DataGridView1.Columns(0).Visible = False
                    DataGridView1.Columns(5).Visible = False
                End If
            Case "Marcas"
                Label_Buscar.Text = "Marca se busca por su Nombre"
                Dim _controladorlm As Controlador_ListaValores = Funciones.crearControlador_ListaValores()
                arlListado = _controladorlm.cargarListado("MARCAS")
                If (arlListado.Count > 0) Then
                    DataGridView1.DataSource = arlListado
                    ponerEncabezados(col_Marcas)
                    DataGridView1.Columns(0).Visible = False
                    DataGridView1.Columns(4).Visible = False
                    DataGridView1.Columns(5).Visible = False
                End If
            Case Else
                Label_Buscar.Text = "Linea se busca por su Nombre"
                Dim _controladorll = Funciones.crearControlador_ListaValores()
                arlListado = _controladorll.cargarListado("LINEAS")
                If (arlListado.Count > 0) Then
                    DataGridView1.DataSource = arlListado
                    ponerEncabezados(col_Marcas)
                    DataGridView1.Columns(0).Visible = False
                    DataGridView1.Columns(4).Visible = False
                    DataGridView1.Columns(5).Visible = False
                End If
        End Select
    End Sub

    Private Sub ponerEncabezados(ByVal encabezado() As String)
        For i = 0 To encabezado.Length - 1
            Me.DataGridView1.Columns(i).HeaderCell.Value = encabezado(i)
        Next i
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        DataGridView1.Rows(e.RowIndex).Selected = True
        Funciones.ParametroBuscar = Convert.ToInt32(DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString())
        If (Funciones.ParametroBuscar <> 0) Then
            LlamarFormulario()
        End If
    End Sub

    Private Sub Button_Nuevo_Click(sender As Object, e As EventArgs) Handles Button_Nuevo.Click
        Funciones.ParametroBuscar = 0
        LlamarFormulario()
    End Sub

    Private Sub LlamarFormulario()
        Me.Close()
        Me.Dispose()
        Select Case Funciones.Source
            Case "Operarios"
                FormOperarios.ShowDialog()
            Case "Equipos"
                Funciones.Lista1 = New ArrayList
                Funciones.Lista2 = New ArrayList
                Dim _controladore As Controlador_Equipo = Funciones.crearControlador_Equipo()
                Dim Listado As ArrayList
                Listado = _controladore.CargarDatosCombos()
                Dim i As Integer
                For i = 0 To Listado.Count - 1
                    If (Listado.Item(i).ToString.Equals("LINEAS")) Then
                        Funciones.Lista1.Add(New CargaCombosListas(Listado.Item(i + 1).ToString(), Listado.Item(i + 2).ToString()))
                    ElseIf (Listado.Item(i).ToString.Equals("MARCAS")) Then
                        Funciones.Lista2.Add(New CargaCombosListas(Listado.Item(i + 1).ToString(), Listado.Item(i + 2).ToString()))
                    End If
                Next i
                If (Funciones.Lista1.Count = 0) Then
                    MessageBox.Show(Mensajes.Mensaje12, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Funciones.Lista1.Clear()
                    Funciones.Lista2.Clear()
                ElseIf (Funciones.Lista1.Count = 0) Then
                    MessageBox.Show(Mensajes.Mensaje11, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Funciones.Lista1.Clear()
                    Funciones.Lista2.Clear()
                Else
                    FormEquipos.ShowDialog()
                End If
            Case "Mantenimiento"
                Funciones.Lista1 = New ArrayList
                Funciones.Lista2 = New ArrayList
                Dim _controladormt As Controlador_Mantenimiento = Funciones.crearControlador_Mantenimiento()
                Dim Listado As ArrayList
                If (Funciones.ParametroBuscar = 0) Then
                    Listado = _controladormt.CargarDatosCombos("PROGRAMAR")
                Else
                    Listado = _controladormt.CargarDatosCombos("PROGRAMACION")
                End If
                Dim i As Integer
                For i = 0 To Listado.Count - 1
                    If (Listado.Item(i).ToString.Equals("EQUIPOS")) Then
                        Funciones.Lista1.Add(New CargaCombosListas(Listado.Item(i + 1).ToString(), Listado.Item(i + 2).ToString()))
                    ElseIf (Listado.Item(i).ToString.Equals("OPERARIOS")) Then
                        Funciones.Lista2.Add(New CargaCombosListas(Listado.Item(i + 1).ToString(), Listado.Item(i + 2).ToString()))
                    End If
                Next i
                If (Funciones.Lista1.Count = 0) Then
                    MessageBox.Show(Mensajes.Mensaje14, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Funciones.Lista1.Clear()
                    Funciones.Lista2.Clear()
                ElseIf (Funciones.Lista2.Count = 0) Then
                    MessageBox.Show(Mensajes.Mensaje13, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Funciones.Lista1.Clear()
                    Funciones.Lista2.Clear()
                Else
                    FormMantenimiento.ShowDialog()
                End If
            Case "Marcas"
                Funciones.ValorTipo = "MARCAS"
                FormListaValores.ShowDialog()
            Case Else
                Funciones.ValorTipo = "LINEAS"
                FormListaValores.ShowDialog()
        End Select
    End Sub
    Private Sub Button_Menu_Click(sender As Object, e As EventArgs) Handles Button_Menu.Click
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub Button_Buscar_Click(sender As Object, e As EventArgs) Handles Button_Buscar.Click
        Dim cadena As String = TextBox_Buscar.Text.Trim()
        Dim v_Renglon As Integer = 0
        If Not (String.IsNullOrEmpty(cadena)) Then
            If (Funciones.Source <> "Operarios") Then
                cadena = cadena.ToUpper()
            End If
            For Each row As DataGridViewRow In DataGridView1.Rows
                If CStr(row.Cells(1).Value).ToUpper = TextBox_Buscar.Text.ToUpper Then
                    row.Selected = True
                    v_Renglon = row.Index
                    Exit For
                End If
            Next
            DataGridView1.Rows(v_Renglon).Selected = True
        End If
    End Sub
End Class

