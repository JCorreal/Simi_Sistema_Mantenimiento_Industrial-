﻿Option Strict On

Public Class FormMantenimiento
    Private _controlador As Controlador_Mantenimiento = Funciones.crearControlador_Mantenimiento()
    Private grabar As Boolean
    Private _Mantenimiento As Mantenimiento
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))
    Private arlListadoEquipos As New ArrayList
    Private Sub FormMantenimiento_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CargarCombos()
        If (Funciones.ParametroBuscar <> 0) Then
            consultarBD()
        End If
    End Sub

    Private Sub consultarBD()
        _Mantenimiento = CType(_controlador.obtenerMantenimiento(Funciones.ParametroBuscar), Mantenimiento)
        If (Not _Mantenimiento Is Nothing) Then
            poblarFormulario()
        End If
    End Sub

    Private Sub poblarFormulario()
        ButtonEliminar.Enabled = True
        DropDownListEquipos.Enabled = False
        DropDownListOperarios.SelectedValue = _Mantenimiento.Operario_id.ToString()
        ButtonEliminar.Enabled = True
        DateTimePickerFecha.Value = _Mantenimiento.Fecha
        TextBoxObservaciones.Text = _Mantenimiento.Observaciones.Trim
        DropDownListOperarios.Focus()
    End Sub

    Private Sub CargarCombos()

        DropDownListEquipos.ValueMember = "CODIGO"
        DropDownListEquipos.DisplayMember = "DETALLE"
        DropDownListEquipos.DataSource = Funciones.Lista1

        DropDownListOperarios.ValueMember = "CODIGO"
        DropDownListOperarios.DisplayMember = "DETALLE"
        DropDownListOperarios.DataSource = Funciones.Lista2

    End Sub

    Private Sub DropDownListEquipos_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListEquipos.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            DropDownListOperarios.Focus()
        End If
    End Sub

    Private Sub DropDownListOperarios_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DropDownListOperarios.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            DateTimePickerFecha.Focus()
        End If
    End Sub

    Private Sub DateTimePickerFecha_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DateTimePickerFecha.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            DateTimePickerFecha_ValueChanged(DateTimePickerFecha, e)
        End If
    End Sub

    Private Sub DateTimePickerFecha_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerFecha.ValueChanged
        If (DateTimePickerFecha.Value < DateTime.Now.Date) Then
            grabar = False
            MessageBox.Show(Mensajes.Mensaje27, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            DateTimePickerFecha.Focus()
            errorPro.SetError(DateTimePickerFecha, Mensajes.Mensaje27)
        Else
            TextBoxObservaciones.Focus()
        End If
    End Sub

    Private Sub TextBoxObservaciones_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxObservaciones.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            Funciones.eliminarTabulador(TextBoxObservaciones.Text, "")
            ButtonGrabar.Focus()
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        DateTimePickerFecha_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            Guardar()
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        _Mantenimiento = New Mantenimiento
        _Mantenimiento.Mantenimiento_id = Funciones.ParametroBuscar
        _Mantenimiento.Equipo_id = Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString())
        _Mantenimiento.Operario_id = Convert.ToInt32(DropDownListOperarios.SelectedValue.ToString())
        _Mantenimiento.Fecha = Convert.ToDateTime(DateTimePickerFecha.Value)
        _Mantenimiento.Observaciones = TextBoxObservaciones.Text
        Resultado = _controlador.guardarMantenimiento(_Mantenimiento)
        If (Resultado = 0) Then
            If (Funciones.ParametroBuscar = 0) Then
                MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                RefrescarCombos()
                If (DropDownListEquipos.Items.Count <= 0) Then
                    ButtonSalir.PerformClick()
                Else
                    Limpiar()
                End If
            Else
                MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            End If

        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje10, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            DropDownListOperarios.Focus()
            errorPro.SetError(DropDownListOperarios, Mensajes.Mensaje10)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub Limpiar()
        If (Funciones.ParametroBuscar = 0) Then
            DropDownListEquipos.Enabled = True
            For Each oControls As Control In panel2.Controls
                If (TypeOf oControls Is TextBox) Then
                    oControls.Text = String.Empty
                    Continue For
                End If
            Next
            DateTimePickerFecha.Value = DateTime.Now.Date
            errorPro.Clear()
            DropDownListEquipos.Focus()
        Else
            poblarFormulario()
        End If
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            If (_controlador.eliminarRegistro(Funciones.ParametroBuscar) = 0) Then
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _Mantenimiento = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        Funciones.MostrarAyuda()
    End Sub

    Private Sub RefrescarCombos() ' Este proceso elimina el equipo seleccionado de la lista, para evitar que vuelvan a programarle. Así evitamos ir a BD a recargar el DataSource
        Dim valor As String = DropDownListEquipos.SelectedValue.ToString()
        Dim i As Integer
        Dim _cb As New CargaCombosListas
        For i = 0 To arlListadoEquipos.Count - 1
            _cb = New CargaCombosListas
            _cb = CType(arlListadoEquipos(i), CargaCombosListas)
            If (_cb.Codigo = valor) Then
                arlListadoEquipos.RemoveAt(i)
                Exit For
            End If
        Next
        ' Ahora repoblar los combos nuevamente
        DropDownListEquipos.DataSource = Nothing
        DropDownListEquipos.Items.Clear()
        DropDownListEquipos.ValueMember = "CODIGO"
        DropDownListEquipos.DisplayMember = "DETALLE"
        DropDownListEquipos.DataSource = arlListadoEquipos
        DropDownListEquipos.SelectedIndex = 0
    End Sub

End Class
