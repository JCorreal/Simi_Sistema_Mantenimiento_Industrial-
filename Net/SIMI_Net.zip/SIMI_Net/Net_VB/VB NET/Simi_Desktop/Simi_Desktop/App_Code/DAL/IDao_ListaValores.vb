﻿' Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

Option Strict On

Public Interface IDao_ListaValores

    Function obtenerListaValores(ByVal datoBuscar As Integer) As ListaValores
    Function guardarListaValores(_ListaValores As ListaValores, ByVal Usuario As Integer) As Integer
    Function cargarListado(ByVal tabla As String) As ArrayList
    Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer





End Interface
