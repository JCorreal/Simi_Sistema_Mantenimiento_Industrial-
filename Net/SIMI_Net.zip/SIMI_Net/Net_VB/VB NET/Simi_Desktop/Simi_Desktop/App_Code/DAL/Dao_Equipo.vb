﻿Option Strict On

Imports System.Data.SqlClient

Public Class Dao_Equipo
    Inherits Dao_General : Implements IDao_Equipo

    Public Sub New()

    End Sub

    Public Function obtenerEquipo(datoBuscar As Integer) As Equipo Implements IDao_Equipo.obtenerEquipo
        Dim _Equipo As New Equipo
        Try
            buscarRegistro("TBL_EQUIPOS", datoBuscar)
            If (sdr.Read()) Then
                _Equipo.Equipo_id = Convert.ToInt32(sdr("EQUIPO_ID").ToString())
                _Equipo.Nombre_Equipo = sdr("NOMBRE_EQUIPO").ToString()
                _Equipo.Marca = Convert.ToInt32(sdr("MARCA").ToString())
                _Equipo.Serie = sdr("SERIE").ToString()
                _Equipo.Linea = Convert.ToInt32(sdr("LINEA").ToString())
                If (sdr.GetBoolean(sdr.GetOrdinal("LUBRICACION"))) Then
                    _Equipo.Lubricacion = 1
                End If
            Else
                _Equipo = Nothing
            End If
            sdr.Close()
            liberarRecursos()
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return _Equipo
    End Function

    Public Function guardarEquipo(_Equipo As Equipo, Usuario As Integer) As Integer Implements IDao_Equipo.guardarEquipo
        guardarEquipo = -1
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_Equipos", Cn)
                Cmd.CommandType = CommandType.StoredProcedure

                Cmd.Parameters.Add("p_EQUIPO_ID", SqlDbType.Int, 4).Value = _Equipo.Equipo_id
                Cmd.Parameters.Add("p_NOMBRE_EQUIPO", SqlDbType.VarChar, 50).Value = _Equipo.Nombre_Equipo
                Cmd.Parameters.Add("p_MARCA", SqlDbType.Int, 10).Value = _Equipo.Marca
                Cmd.Parameters.Add("p_SERIE", SqlDbType.VarChar, 20).Value = _Equipo.Serie
                Cmd.Parameters.Add("p_LINEA", SqlDbType.Int, 10).Value = _Equipo.Linea
                Cmd.Parameters.Add("p_LUBRICACION", SqlDbType.Int, 1).Value = _Equipo.Lubricacion
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.Int, 4).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                guardarEquipo = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                liberarRecursos()
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return guardarEquipo
    End Function

    Public Function cargarListado() As ArrayList Implements IDao_Equipo.cargarListado
        Dim arlListado As New ArrayList()
        arlListado = cargarListadodg("TBL_EQUIPOS")
        Return arlListado
    End Function

    Public Function eliminarRegistro(datoEliminar As Integer) As Integer Implements IDao_Equipo.eliminarRegistro
        eliminarRegistro = -1
        eliminarRegistro = borrarRegistro(datoEliminar, "TBL_EQUIPOS")
        Return eliminarRegistro
    End Function

    Public Function CargarDatosCombos() As ArrayList Implements IDao_Equipo.CargarDatosCombos
        Dim arlListado As New ArrayList()
        arlListado = CargarArray("CONTROLEQUIPOS")
        Return arlListado
    End Function
End Class
