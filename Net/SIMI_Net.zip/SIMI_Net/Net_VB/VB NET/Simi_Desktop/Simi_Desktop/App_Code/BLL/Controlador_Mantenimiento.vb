﻿Option Strict On

Public Class Controlador_Mantenimiento
    Private ReadOnly _dao_mantenimiento As IDao_Mantenimiento

    Sub New(dao_mantenimiento As IDao_Mantenimiento)
        _dao_mantenimiento = dao_mantenimiento
    End Sub

    Public Function cargarListado() As ArrayList
        Return _dao_mantenimiento.cargarListado()
    End Function

    Public Function obtenerMantenimiento(ByVal datoBuscar As Integer) As Object
        Return _dao_mantenimiento.obtenerMantenimiento(datoBuscar)
    End Function

    Public Function guardarMantenimiento(ByVal _Mantenimiento As Mantenimiento) As Integer
        Return _dao_mantenimiento.guardarMantenimiento(_Mantenimiento, Funciones.UsuarioConectado)
    End Function

    Public Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer
        Return _dao_mantenimiento.eliminarRegistro(datoEliminar)
    End Function

    Public Function CargarDatosCombos(ByVal tabla As String) As ArrayList
        Return _dao_mantenimiento.CargarDatosCombos(tabla)
    End Function
End Class
