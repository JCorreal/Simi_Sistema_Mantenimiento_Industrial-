﻿' DAL: Data Access Layer - Capa Acceso Datos transversal que las demas extienden

Option Strict On

Imports System.Data.SqlClient

Public Class Dao_General

    Public Sub New()

    End Sub

    Public Shared Cn As SqlConnection
    Public Shared sdr As SqlDataReader
    Public Shared Cmd As SqlCommand

    Public Shared Sub buscarRegistro(ByVal tabla As String, ByVal datoBuscar As Integer)
        Try
            Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
            Cmd = New SqlCommand("SPR_R_buscarRegistro", Cn)
            Cmd.CommandType = CommandType.StoredProcedure
            Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla
            Cmd.Parameters.Add("p_DATOBUSCAR", SqlDbType.Int, 4).Value = datoBuscar
            Cn.Open()
            sdr = Cmd.ExecuteReader()
        Catch
            liberarRecursos()
        End Try
    End Sub

    Public Function CargarArray(ByVal tabla As String) As ArrayList
        Dim arlListado As New ArrayList()
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_R_CargarCombosListas", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla
                Cn.Open()
                Using sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    While (sdr.Read())
                        arlListado.Add(sdr.GetValue(2).ToString())
                        arlListado.Add(sdr.GetValue(0).ToString())
                        arlListado.Add(sdr.GetValue(1).ToString())
                    End While
                    sdr.Close()
                    liberarRecursos()
                End Using
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return arlListado
    End Function

    Public Function borrarRegistro(ByVal datoEliminar As Integer, ByVal tabla As String) As Integer
        borrarRegistro = -1
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_D_Registro", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla
                Cmd.Parameters.Add("p_CONDICION", SqlDbType.Int, 4).Value = datoEliminar
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                borrarRegistro = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                liberarRecursos()
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return borrarRegistro
    End Function

    Public Function cargarListadodg(ByVal tabla As String) As ArrayList
        Dim arlListado As New ArrayList()
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_R_CargarListado", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla
                Cmd.Parameters.Add("p_CONDICION", SqlDbType.VarChar, 20).Value = ""
                Cn.Open()
                Using sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection)
                    While (sdr.Read())
                        arlListado.Add(New CargarListado(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString(), sdr.GetValue(2).ToString(), sdr.GetValue(3).ToString(), sdr.GetValue(4).ToString(), sdr.GetValue(5).ToString()))
                    End While
                    sdr.Close()
                    liberarRecursos()
                End Using
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return arlListado
    End Function

    Public Shared Sub liberarRecursos()

        If (Not sdr Is Nothing) Then
            sdr.Close()
        Else
            Cmd.Dispose()
            If (Not Cn Is Nothing) Then
                Cn.Close()
                Cn.Dispose()
            End If
        End If

    End Sub

End Class

