﻿Option Strict On

Public Interface IDao_Operario
    Function obtenerAcceso(ByVal documento As String, ByVal clave As Integer) As Operario
    Function obtenerOperario(ByVal datoBuscar As Integer) As Operario
    Function guardarOperario(_Operario As Operario, ByVal Usuario As Integer) As Integer
    Function guardarCambioClave(ByVal Usuario As Integer, ByVal claveAnterior As Integer, ByVal claveNueva As Integer) As Integer
    Function cargarListado() As ArrayList
    Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer


End Interface
