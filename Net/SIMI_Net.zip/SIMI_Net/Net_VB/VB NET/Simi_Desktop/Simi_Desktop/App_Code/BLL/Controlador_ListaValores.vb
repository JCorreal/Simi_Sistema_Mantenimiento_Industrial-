﻿Option Strict On

Public Class Controlador_ListaValores
    Private ReadOnly _dao_listavalores As IDao_ListaValores

    Sub New(dao_listavalores As IDao_ListaValores)
        _dao_listavalores = dao_listavalores
    End Sub

    Public Function cargarListado(ByVal tabla As String) As ArrayList
        Return _dao_listavalores.cargarListado(tabla)
    End Function

    Public Function obtenerListaValores(ByVal datoBuscar As Integer) As Object
        Return _dao_listavalores.obtenerListaValores(datoBuscar)
    End Function

    Public Function guardarListaValores(ByVal _ListaValores As ListaValores) As Integer
        Return _dao_listavalores.guardarListaValores(_ListaValores, Funciones.UsuarioConectado)
    End Function

    Public Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer
        Return _dao_listavalores.eliminarRegistro(datoEliminar)
    End Function

End Class
