﻿' Clase que nos permite cargar Pares de clave y valor para los ComboBox y ListBox
Option Strict On

Public Class CargaCombosListas

    Public Property Codigo() As String

    Public Property Detalle() As String

    Public Sub New()

    End Sub

    Public Sub New(ByVal Codigo As String, ByVal Detalle As String)
        Me.Codigo = Codigo
        Me.Detalle = Detalle
    End Sub

End Class
