﻿' Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones

Option Strict On

Imports System.Text.RegularExpressions

Public Class Funciones
    Public Shared ValorTipo As String
    Public Shared Fuente As String
    Public Shared PerfilAcceso As Integer
    Public Shared NombreUsuario As String
    Public Shared UsuarioConectado As Integer
    Public Shared ListadeValores As ArrayList

    Public Shared Function crearControlador_Operario() As Controlador_Operario
        Dim _dao_operario As Dao_Operario = CType(AccesoDatosFactory.obtenerDao_Operario(), Dao_Operario)
        Return New Controlador_Operario(_dao_operario)
    End Function

    Public Shared Function crearControlador_Equipo() As Controlador_Equipo
        Dim _dao_equipo As Dao_Equipo = CType(AccesoDatosFactory.obtenerDao_Equipo(), Dao_Equipo)
        Return New Controlador_Equipo(_dao_equipo)
    End Function

    Public Shared Function crearControlador_ListaValores() As Controlador_ListaValores
        Dim _dao_listavalores As Dao_ListaValores = CType(AccesoDatosFactory.obtenerDao_Listavalores(), Dao_ListaValores)
        Return New Controlador_ListaValores(_dao_listavalores)
    End Function

    Public Shared Function crearControlador_Mantenimiento() As Controlador_Mantenimiento
        Dim _dao_mantenimiento As Dao_Mantenimiento = CType(AccesoDatosFactory.obtenerDao_Mantenimiento(), Dao_Mantenimiento)
        Return New Controlador_Mantenimiento(_dao_mantenimiento)
    End Function


    'Funcion para validar campos de formulario vacios
    Public Shared Function validar_CampoVacio(ByVal cadena As String) As Boolean
        Dim Vacio As Boolean = False
        cadena = cadena.Trim()
        If (String.IsNullOrEmpty(cadena)) Then
            Vacio = True
        End If
        Return Vacio
    End Function

    'Funcion para eliminar posibles espacios de tabulacion en un campo de texto
    Public Shared Function eliminarTabulador(ByVal cadena As String, ByVal Conversion As String) As String
        cadena = cadena.Trim()
        While (cadena.IndexOf("  ", 0) <> -1)
            cadena = (cadena.Replace("  ", " "))
        End While
        If (Conversion = "MAY") Then
            cadena = cadena.ToUpper()
        ElseIf (Conversion = "1MAY") Then 'Organizar primera letra en Mayuscula y siguientes en Minuscula
            cadena = cadena.ToLower()
            cadena = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(cadena)
        End If
        Return cadena
    End Function

    'Funcion para validar direcciones de correo electronico
    Public Shared Function validar_Correo(ByVal cadena As String) As Boolean
        cadena = cadena.Trim()
        Return Regex.IsMatch(cadena, "^\w+[\+\.\w-]*@([\w-]+\.)*\w+[\w-]*\.([a-z]{2,4}|\d+)$")
    End Function

    'Funcion para limpiar los controles en un formulario (Solo TextBox)
    Public Shared Sub limpiarForma(ByVal pnl As Panel)
        For Each oControls As Control In pnl.Controls '  If (TypeOf ctl Is TextBox) Then ctl.Text = ""
            If (TypeOf oControls Is TextBox) Then
                oControls.Text = ""
            End If
        Next
    End Sub

    'Funcion para comprobar existencia de caracteres diferentes de letras
    Public Shared Function validar_SoloLetras(ByVal cadena As String) As Boolean
        Dim i As Integer
        For i = 0 To cadena.Length - 1
            If (Char.IsNumber(cadena(i))) Then
                validar_SoloLetras = True
                Exit For
            End If
        Next i
        validar_SoloLetras = False
    End Function

End Class

