﻿'Patron de Creacion: Factory Method

Public Class AccesoDatosFactory


    Public Shared Function obtenerDao_Operario() As IDao_Operario
        Return New Dao_Operario
    End Function

    Public Shared Function obtenerDao_Equipo() As IDao_Equipo
        Return New Dao_Equipo
    End Function

    Public Shared Function obtenerDao_Listavalores() As IDao_ListaValores
        Return New Dao_ListaValores
    End Function

    Public Shared Function obtenerDao_Mantenimiento() As IDao_Mantenimiento
        Return New Dao_Mantenimiento
    End Function


End Class
