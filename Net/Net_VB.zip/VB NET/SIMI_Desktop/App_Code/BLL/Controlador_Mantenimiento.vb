﻿Option Strict On

Public Class Controlador_Mantenimiento
    Private ReadOnly _dao_mantenimiento As IDao_Mantenimiento

    Sub New(_dao_mantenimiento As IDao_Mantenimiento)
        _dao_mantenimiento = _dao_mantenimiento
    End Sub

    Public Function cargarListado(ByVal Tabla As String) As ArrayList
        Return _dao_mantenimiento.cargarListado(Tabla)
    End Function

    Public Function controlarProgramacion(ByVal Tabla As String) As ArrayList
        Return _dao_mantenimiento.controlarProgramacion(Tabla)
    End Function

    Public Function obtenerMantenimiento(ByVal datoBuscar As Integer) As Object
        Return _dao_mantenimiento.obtenerMantenimiento(datoBuscar)
    End Function

    Public Function guardarMantenimiento(ByVal _Mantenimiento As Mantenimiento) As Integer
        Return _dao_mantenimiento.guardarMantenimiento(_Mantenimiento, Funciones.UsuarioConectado)
    End Function

    Public Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer
        Return _dao_mantenimiento.eliminarRegistro(datoEliminar)
    End Function

End Class
