﻿Option Strict On

Public Class Controlador_Operario
    Private ReadOnly _dao_operario As IDao_Operario

    Sub New(dao_operario As IDao_Operario)
        _dao_operario = dao_operario
    End Sub

    Public Function cargarListado() As ArrayList
        Return _dao_operario.cargarListado()
    End Function

    Public Function obtenerAcceso(ByVal Documento As String, ByVal Clave As Integer) As Operario
        Return _dao_operario.obtenerAcceso(Documento, Clave)
    End Function

    Public Function obtenerOperario(ByVal datoBuscar As Integer) As Object
        Return _dao_operario.obtenerOperario(datoBuscar)
    End Function

    Public Function guardarOperario(ByVal _Operario As Operario) As Integer
        Return _dao_operario.guardarOperario(_Operario, Funciones.UsuarioConectado)
    End Function

    Public Function guardarCambioClave(ByVal claveAnterior As Integer, ByVal claveNueva As Integer) As Integer
        Return _dao_operario.guardarCambioClave(Funciones.UsuarioConectado, claveAnterior, claveNueva)
    End Function

    Public Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer
        Return _dao_operario.eliminarRegistro(datoEliminar)
    End Function

End Class
