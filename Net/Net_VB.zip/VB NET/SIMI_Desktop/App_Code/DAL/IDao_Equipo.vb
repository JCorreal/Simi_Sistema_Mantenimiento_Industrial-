﻿' Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

Option Strict On

Public Interface IDao_Equipo

    Function obtenerEquipo(ByVal datoBuscar As Integer) As Equipo
    Function guardarEquipo(_Equipo As Equipo, ByVal Usuario As Integer) As Integer
    Function cargarListado() As ArrayList
    Function controlarProgramacion() As ArrayList
    Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer

End Interface
