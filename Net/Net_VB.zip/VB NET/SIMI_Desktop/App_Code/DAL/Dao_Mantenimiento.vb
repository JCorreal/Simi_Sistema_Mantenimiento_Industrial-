﻿Option Strict On

Imports System.Data.SqlClient

Public Class Dao_Mantenimiento
    Inherits Dao_General : Implements IDao_Mantenimiento

    Public Function obtenerMantenimiento(datoBuscar As Integer) As Mantenimiento Implements IDao_Mantenimiento.obtenerMantenimiento
        Dim _Mantenimiento = New Mantenimiento
        Try
            buscarRegistro("TBL_MANTENIMIENTO", datoBuscar)
            If (sdr.Read()) Then
                _Mantenimiento.Mantenimiento_id = Convert.ToInt32(sdr("MANTENIMIENTO_ID").ToString())
                _Mantenimiento.Equipo_id = Convert.ToInt32(sdr("EQUIPO_ID").ToString())
                _Mantenimiento.Operario_id = Convert.ToInt32(sdr("OPERARIO_ID").ToString())
                _Mantenimiento.Fecha = Convert.ToDateTime(sdr("FECHA").ToString())
                _Mantenimiento.Observaciones = sdr("OBSERVACIONES").ToString()
            Else
                _Mantenimiento = Nothing
            End If
            sdr.Close()
            liberarRecursos()
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return _Mantenimiento
    End Function

    Public Function guardarMantenimiento(_Mantenimiento As Mantenimiento, Usuario As Integer) As Integer Implements IDao_Mantenimiento.guardarMantenimiento
        guardarMantenimiento = -1
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_Mantenimiento", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_MANTENIMIENTO_ID", SqlDbType.Int, 4).Value = _Mantenimiento.Mantenimiento_id
                Cmd.Parameters.Add("p_EQUIPO_ID", SqlDbType.Int, 10).Value = _Mantenimiento.Equipo_id
                Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 10).Value = _Mantenimiento.Operario_id
                Cmd.Parameters.Add("p_FECHA", SqlDbType.DateTime, 10).Value = _Mantenimiento.Fecha
                Cmd.Parameters.Add("p_OBSERVACIONES", SqlDbType.VarChar, 255).Value = _Mantenimiento.Observaciones
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                guardarMantenimiento = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                liberarRecursos()
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return guardarMantenimiento

    End Function

    Function cargarListado(ByVal tabla As String) As ArrayList Implements IDao_Mantenimiento.cargarListado
        Dim arlLista As New ArrayList()
        arlLista = cargarListas(tabla)
        Return arlLista
    End Function

    Function controlarProgramacion(ByVal tabla As String) As ArrayList Implements IDao_Mantenimiento.controlarProgramacion
        Dim arlLista As New ArrayList()
        arlLista = cargarListas(tabla)
        Return arlLista
    End Function

    Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer Implements IDao_Mantenimiento.eliminarRegistro
        eliminarRegistro = -1
        eliminarRegistro = borrarRegistro(datoEliminar, "TBL_MANTENIMIENTO")
        Return eliminarRegistro
    End Function

End Class
