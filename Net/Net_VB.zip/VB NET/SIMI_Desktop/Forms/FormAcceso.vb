﻿Option Strict On

Public Class FormAcceso
    Private ingresar As Boolean
    Private contadorIntentos As Integer = 0
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub TextBoxDocumento_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxDocumento.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxDocumento.Text)) Then
                    ingresar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.MensajeCampoRequerido)
                ElseIf (TextBoxDocumento.Text.Length < 6) Then
                    ingresar = False
                Else
                    errorPro.Clear()
                    TextBoxClave.Focus()
                End If
            Else
                If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                    e.Handled = True 'Establece el caracter a null si está fuera del intervalo
                End If
            End If
        End If
    End Sub

    Private Sub TextBoxClave_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxClave.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxClave.Text)) Then
                    ingresar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxClave.Focus()
                    errorPro.SetError(TextBoxClave, Mensajes.MensajeCampoRequerido)
                ElseIf (TextBoxClave.Text.Length < 6) Then
                    ingresar = False
                Else
                    errorPro.Clear()
                    ButtonIngresar.Focus()
                End If
            End If
        Else
            If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                e.Handled = True 'Establece el caracter a null si está fuera del intervalo
            End If
        End If
    End Sub

    Private Sub ButtonIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonIngresar.Click
        Intentos() 'Incrementar contador de intentos de acceso
        ingresar = True
        TextBoxDocumento_KeyPress(ButtonIngresar, tecla)
        If (ingresar) Then
            TextBoxClave_KeyPress(ButtonIngresar, tecla)
            If (ingresar) Then
                Dim _controlador As Controlador_Operario = Funciones.crearControlador_Operario()
                Dim _Operario As Operario = _controlador.obtenerAcceso(TextBoxDocumento.Text.Trim, Convert.ToInt32(TextBoxClave.Text.Trim))
                If (Not _Operario Is Nothing) Then
                    ingresar = True
                    Funciones.UsuarioConectado = _Operario.Operario_id
                    Funciones.PerfilAcceso = _Operario.Perfil
                    Funciones.NombreUsuario = _Operario.Nombres + " " + _Operario.Apellidos
                    _Operario = Nothing
                    Me.Hide()
                    FormMenu.ShowDialog()
                Else
                    MessageBox.Show(Mensajes.Mensaje2, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxClave.Focus()
                    errorPro.SetError(TextBoxClave, Mensajes.Mensaje2)
                End If
            End If
        End If
    End Sub

    Private Sub Intentos()
        contadorIntentos = (contadorIntentos + 1)
        If (contadorIntentos = 3) Then
            Application.Exit()  ' Usuario desconocido luego de 3 intentos, finalizar
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Funciones.limpiarForma(panel2)
        TextBoxDocumento.Focus()
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        Application.Exit()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        ' Dim myProcess As Process = Process.Start("E:/Fuentes CM/ControlMantenimiento-NetDesktopVB/ControlMantenimiento-NetDesktopVB/Ayudas/Ayuda.chm")
        ' myProcess.WaitForExit()
        ' Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        ' donde descomprimió el archivo descargado de la web
    End Sub
End Class
