﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMantenimiento
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMantenimiento))
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.lbMensaje = New System.Windows.Forms.Label()
        Me.DropDownListEquipos = New System.Windows.Forms.ComboBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.ButtonBuscar = New System.Windows.Forms.Button()
        Me.DropDownListOperarios = New System.Windows.Forms.ComboBox()
        Me.TextBoxObservaciones = New System.Windows.Forms.TextBox()
        Me.DateTimePickerFecha = New System.Windows.Forms.DateTimePicker()
        Me.ButtonEliminar = New System.Windows.Forms.Button()
        Me.ButtonAyuda = New System.Windows.Forms.Button()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        Me.ButtonSalir = New System.Windows.Forms.Button()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.ButtonGrabar = New System.Windows.Forms.Button()
        Me.errorPro = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.panel2.SuspendLayout()
        Me.panel1.SuspendLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panel2
        '
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.lbMensaje)
        Me.panel2.Controls.Add(Me.DropDownListEquipos)
        Me.panel2.Controls.Add(Me.label4)
        Me.panel2.Controls.Add(Me.label3)
        Me.panel2.Controls.Add(Me.label2)
        Me.panel2.Controls.Add(Me.label1)
        Me.panel2.Controls.Add(Me.ButtonBuscar)
        Me.panel2.Controls.Add(Me.DropDownListOperarios)
        Me.panel2.Controls.Add(Me.TextBoxObservaciones)
        Me.panel2.Controls.Add(Me.DateTimePickerFecha)
        Me.panel2.Location = New System.Drawing.Point(43, 28)
        Me.panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(693, 321)
        Me.panel2.TabIndex = 327
        '
        'lbMensaje
        '
        Me.lbMensaje.AutoSize = True
        Me.lbMensaje.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMensaje.ForeColor = System.Drawing.Color.Blue
        Me.lbMensaje.Location = New System.Drawing.Point(97, 15)
        Me.lbMensaje.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbMensaje.Name = "lbMensaje"
        Me.lbMensaje.Size = New System.Drawing.Size(479, 17)
        Me.lbMensaje.TabIndex = 336
        Me.lbMensaje.Text = "Seleccionar equipo de la lista y presionar el boton de la derecha"
        Me.lbMensaje.Visible = False
        '
        'DropDownListEquipos
        '
        Me.DropDownListEquipos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DropDownListEquipos.FormattingEnabled = True
        Me.DropDownListEquipos.Location = New System.Drawing.Point(185, 65)
        Me.DropDownListEquipos.Margin = New System.Windows.Forms.Padding(4)
        Me.DropDownListEquipos.Name = "DropDownListEquipos"
        Me.DropDownListEquipos.Size = New System.Drawing.Size(357, 24)
        Me.DropDownListEquipos.TabIndex = 335
        Me.DropDownListEquipos.TabStop = False
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(56, 249)
        Me.label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(116, 17)
        Me.label4.TabIndex = 334
        Me.label4.Text = "Observaciones"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(56, 175)
        Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(52, 17)
        Me.label3.TabIndex = 333
        Me.label3.Text = "Fecha"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(56, 117)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(72, 17)
        Me.label2.TabIndex = 332
        Me.label2.Text = "Operario"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(56, 69)
        Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(58, 17)
        Me.label1.TabIndex = 331
        Me.label1.Text = "Equipo"
        '
        'ButtonBuscar
        '
        Me.ButtonBuscar.Location = New System.Drawing.Point(552, 63)
        Me.ButtonBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonBuscar.Name = "ButtonBuscar"
        Me.ButtonBuscar.Size = New System.Drawing.Size(36, 28)
        Me.ButtonBuscar.TabIndex = 330
        Me.ButtonBuscar.TabStop = False
        Me.ButtonBuscar.Text = "..."
        Me.ButtonBuscar.UseVisualStyleBackColor = True
        Me.ButtonBuscar.Visible = False
        '
        'DropDownListOperarios
        '
        Me.DropDownListOperarios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DropDownListOperarios.FormattingEnabled = True
        Me.DropDownListOperarios.Location = New System.Drawing.Point(185, 113)
        Me.DropDownListOperarios.Margin = New System.Windows.Forms.Padding(4)
        Me.DropDownListOperarios.Name = "DropDownListOperarios"
        Me.DropDownListOperarios.Size = New System.Drawing.Size(357, 24)
        Me.DropDownListOperarios.TabIndex = 329
        Me.DropDownListOperarios.TabStop = False
        '
        'TextBoxObservaciones
        '
        Me.TextBoxObservaciones.Location = New System.Drawing.Point(185, 219)
        Me.TextBoxObservaciones.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBoxObservaciones.Multiline = True
        Me.TextBoxObservaciones.Name = "TextBoxObservaciones"
        Me.TextBoxObservaciones.Size = New System.Drawing.Size(357, 77)
        Me.TextBoxObservaciones.TabIndex = 328
        Me.TextBoxObservaciones.TabStop = False
        '
        'DateTimePickerFecha
        '
        Me.DateTimePickerFecha.Location = New System.Drawing.Point(185, 167)
        Me.DateTimePickerFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePickerFecha.Name = "DateTimePickerFecha"
        Me.DateTimePickerFecha.Size = New System.Drawing.Size(265, 22)
        Me.DateTimePickerFecha.TabIndex = 327
        Me.DateTimePickerFecha.TabStop = False
        '
        'ButtonEliminar
        '
        Me.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonEliminar.Enabled = False
        Me.ButtonEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEliminar.ForeColor = System.Drawing.Color.Black
        Me.ButtonEliminar.Image = CType(resources.GetObject("ButtonEliminar.Image"), System.Drawing.Image)
        Me.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonEliminar.Location = New System.Drawing.Point(305, 21)
        Me.ButtonEliminar.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonEliminar.Name = "ButtonEliminar"
        Me.ButtonEliminar.Size = New System.Drawing.Size(80, 43)
        Me.ButtonEliminar.TabIndex = 5
        Me.ButtonEliminar.TabStop = False
        Me.ButtonEliminar.Text = "Eliminar"
        Me.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonEliminar.UseVisualStyleBackColor = False
        '
        'ButtonAyuda
        '
        Me.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonAyuda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAyuda.ForeColor = System.Drawing.Color.Black
        Me.ButtonAyuda.Image = CType(resources.GetObject("ButtonAyuda.Image"), System.Drawing.Image)
        Me.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonAyuda.Location = New System.Drawing.Point(381, 21)
        Me.ButtonAyuda.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonAyuda.Name = "ButtonAyuda"
        Me.ButtonAyuda.Size = New System.Drawing.Size(80, 43)
        Me.ButtonAyuda.TabIndex = 6
        Me.ButtonAyuda.TabStop = False
        Me.ButtonAyuda.Text = "Ayuda"
        Me.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonAyuda.UseVisualStyleBackColor = False
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCancelar.ForeColor = System.Drawing.Color.Black
        Me.ButtonCancelar.Image = CType(resources.GetObject("ButtonCancelar.Image"), System.Drawing.Image)
        Me.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonCancelar.Location = New System.Drawing.Point(229, 21)
        Me.ButtonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(80, 43)
        Me.ButtonCancelar.TabIndex = 4
        Me.ButtonCancelar.TabStop = False
        Me.ButtonCancelar.Text = "Cancelar"
        Me.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonCancelar.UseVisualStyleBackColor = False
        '
        'ButtonSalir
        '
        Me.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSalir.ForeColor = System.Drawing.Color.Black
        Me.ButtonSalir.Image = CType(resources.GetObject("ButtonSalir.Image"), System.Drawing.Image)
        Me.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonSalir.Location = New System.Drawing.Point(457, 21)
        Me.ButtonSalir.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonSalir.Name = "ButtonSalir"
        Me.ButtonSalir.Size = New System.Drawing.Size(80, 43)
        Me.ButtonSalir.TabIndex = 7
        Me.ButtonSalir.TabStop = False
        Me.ButtonSalir.Text = "Salir"
        Me.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonSalir.UseVisualStyleBackColor = False
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.Gray
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.ButtonSalir)
        Me.panel1.Controls.Add(Me.ButtonAyuda)
        Me.panel1.Controls.Add(Me.ButtonEliminar)
        Me.panel1.Controls.Add(Me.ButtonCancelar)
        Me.panel1.Controls.Add(Me.ButtonGrabar)
        Me.panel1.Location = New System.Drawing.Point(43, 335)
        Me.panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(693, 83)
        Me.panel1.TabIndex = 328
        '
        'ButtonGrabar
        '
        Me.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonGrabar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGrabar.ForeColor = System.Drawing.Color.Black
        Me.ButtonGrabar.Image = CType(resources.GetObject("ButtonGrabar.Image"), System.Drawing.Image)
        Me.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonGrabar.Location = New System.Drawing.Point(155, 21)
        Me.ButtonGrabar.Margin = New System.Windows.Forms.Padding(4)
        Me.ButtonGrabar.Name = "ButtonGrabar"
        Me.ButtonGrabar.Size = New System.Drawing.Size(80, 43)
        Me.ButtonGrabar.TabIndex = 3
        Me.ButtonGrabar.TabStop = False
        Me.ButtonGrabar.Text = "Grabar"
        Me.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonGrabar.UseVisualStyleBackColor = False
        '
        'errorPro
        '
        Me.errorPro.ContainerControl = Me
        '
        'FormMantenimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(779, 446)
        Me.Controls.Add(Me.panel2)
        Me.Controls.Add(Me.panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FormMantenimiento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Mantenimiento"
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        Me.panel1.ResumeLayout(False)
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents lbMensaje As System.Windows.Forms.Label
    Private WithEvents DropDownListEquipos As System.Windows.Forms.ComboBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents ButtonBuscar As System.Windows.Forms.Button
    Private WithEvents DropDownListOperarios As System.Windows.Forms.ComboBox
    Private WithEvents TextBoxObservaciones As System.Windows.Forms.TextBox
    Private WithEvents DateTimePickerFecha As System.Windows.Forms.DateTimePicker
    Private WithEvents ButtonEliminar As System.Windows.Forms.Button
    Private WithEvents ButtonAyuda As System.Windows.Forms.Button
    Private WithEvents ButtonCancelar As System.Windows.Forms.Button
    Private WithEvents ButtonSalir As System.Windows.Forms.Button
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents ButtonGrabar As System.Windows.Forms.Button
    Private WithEvents errorPro As System.Windows.Forms.ErrorProvider
End Class
