﻿Option Strict On

Public Class FormCambioClave
    Private _controlador As Controlador_Operario = Funciones.CrearControlador_Operario()
    Private grabar As Boolean
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub TextBoxClave_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxClave.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxClave.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxClave.Focus()
                    errorPro.SetError(TextBoxClave, Mensajes.MensajeCampoRequerido)
                Else
                    errorPro.Clear()
                    TextBoxClaveNueva.Focus()
                End If
            End If
        Else
            If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                e.Handled = True 'Establece el caracter a null si está fuera del intervalo
            End If
        End If
    End Sub

    Private Sub TextBoxClaveNueva_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxClaveNueva.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxClaveNueva.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxClaveNueva.Focus()
                    errorPro.SetError(TextBoxClaveNueva, Mensajes.MensajeCampoRequerido)
                ElseIf (TextBoxClaveNueva.Text = TextBoxClave.Text) Then ' Clave Nueva debe ser diferente de la actual
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje4, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxClaveNueva.Focus()
                    errorPro.SetError(TextBoxClaveNueva, Mensajes.Mensaje21)
                ElseIf (TextBoxClaveNueva.Text.Length < 6) Then
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje21, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxClaveNueva.Focus()
                    errorPro.SetError(TextBoxClaveNueva, Mensajes.Mensaje21)
                Else
                    errorPro.Clear()
                    TextBoxConfirmar.Focus()
                End If
            End If
        Else
            If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                e.Handled = True 'Establece el caracter a null si está fuera del intervalo
            End If
        End If
    End Sub

    Private Sub TextBoxConfirmar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxConfirmar.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxConfirmar.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxConfirmar.Focus()
                    errorPro.SetError(TextBoxConfirmar, Mensajes.MensajeCampoRequerido)
                ElseIf (TextBoxConfirmar.Text <> TextBoxClaveNueva.Text) Then ' Clave Nueva debe ser diferente de la actual
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje5, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxConfirmar.Focus()
                    errorPro.SetError(TextBoxConfirmar, Mensajes.Mensaje5)
                Else
                    errorPro.Clear()
                    ButtonGrabar.Focus()
                End If
            End If
        Else
            If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                e.Handled = True 'Establece el caracter a null si está fuera del intervalo
            End If
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        TextBoxClave_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            TextBoxClaveNueva_KeyPress(ButtonGrabar, tecla)
            If (grabar) Then
                TextBoxConfirmar_KeyPress(ButtonGrabar, tecla)
                If (grabar) Then
                    Guardar()
                End If
            End If
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        Resultado = _controlador.guardarCambioClave(Convert.ToInt32(TextBoxClave.Text.Trim), Convert.ToInt32(TextBoxClaveNueva.Text.Trim))
        If (Resultado = 0) Then
            MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje3, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        ButtonSalir.PerformClick()
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub Limpiar()
        Funciones.limpiarForma(panel2)
        errorPro.Clear()
        TextBoxClave.Focus()
    End Sub
End Class