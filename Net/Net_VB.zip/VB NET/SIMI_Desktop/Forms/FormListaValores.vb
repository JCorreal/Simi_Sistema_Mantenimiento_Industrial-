﻿Option Strict On

Public Class FormListaValores
    Private _controlador As Controlador_ListaValores = Funciones.crearControlador_ListaValores()
    Private grabar As Boolean
    Private _ListaValores As ListaValores
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub FormListaValores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = Funciones.ValorTipo.ToLower()
        Me.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(Me.Text)
        CargarListaSeleccion()
    End Sub

    Private Sub CargarListaSeleccion()

        ListBoxListaValores.ValueMember = "CODIGO"
        ListBoxListaValores.DisplayMember = "DETALLE"
        If (Funciones.ValorTipo = "LINEAS") Then
            ListBoxListaValores.DataSource = _controlador.cargarListado("LINEAS")
        Else
            ListBoxListaValores.DataSource = _controlador.cargarListado("MARCAS")
        End If
    End Sub

    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        If (ListBoxListaValores.Items.Count <> 0) Then
            ListBoxListaValores.Visible = True
        End If
    End Sub

    Private Sub TextBoxNombre_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombre.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.validar_CampoVacio(TextBoxNombre.Text)) Then
                grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxNombre.Focus()
                errorPro.SetError(TextBoxNombre, Mensajes.MensajeCampoRequerido)
            Else
                TextBoxDescripcion.Focus()
            End If
        End If
    End Sub

    Private Sub TextBoxDescripcion_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxDescripcion.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            Funciones.eliminarTabulador(TextBoxDescripcion.Text, "")
            ButtonGrabar.Focus()
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        TextBoxNombre_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            Guardar(Convert.ToInt32(lblCodigo.Text), CStr(IIf(Convert.ToInt32(lblCodigo.Text) = 0, Mensajes.MensajeGraba, Mensajes.MensajeActualiza)))
        End If
    End Sub

    Private Sub Guardar(ByVal ElCodigo As Integer, ByVal Mensaje As String)
        Dim Resultado As Integer
        _ListaValores = New ListaValores
        _ListaValores.Listavalores_id = ElCodigo
        _ListaValores.Nombre = TextBoxNombre.Text.Trim
        _ListaValores.Descripcion = TextBoxDescripcion.Text.Trim
        _ListaValores.Tipo = Funciones.ValorTipo
        Resultado = _controlador.guardarListaValores(_ListaValores)
        If (Resultado = 0) Then
            MessageBox.Show(Mensaje, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            CargarListaSeleccion()
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje8, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBoxNombre.Focus()
            errorPro.SetError(TextBoxNombre, Mensajes.Mensaje8)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        Limpiar()
    End Sub

    Private Sub Limpiar()
        Funciones.limpiarForma(panel2)
        ListBoxListaValores.Visible = False
        ButtonEliminar.Enabled = False
        errorPro.Clear()
        lblCodigo.Text = "0"
        TextBoxNombre.Focus()
    End Sub

    Private Sub LlenarCampos()
        _ListaValores = CType(_controlador.ObtenerListaValores(Convert.ToInt32(lblCodigo.Text)), ListaValores)
        If (Not _ListaValores Is Nothing) Then
            ButtonEliminar.Enabled = True
            TextBoxNombre.Text = _ListaValores.Nombre
            TextBoxDescripcion.Text = _ListaValores.Descripcion
            TextBoxNombre.Focus()
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        Dim Resultado As Integer
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            Resultado = _controlador.EliminarRegistro(Convert.ToInt32(lblCodigo.Text))
            If (Resultado = 0) Then
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                CargarListaSeleccion()
                Limpiar()
            ElseIf (Resultado = 1) Then
                MessageBox.Show(Mensajes.Mensaje9, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _ListaValores = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub lstListaValores_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBoxListaValores.DoubleClick
        lblCodigo.Text = ListBoxListaValores.SelectedValue.ToString()
        ListBoxListaValores.Visible = False
        LlenarCampos()
    End Sub


    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        ' Dim myProcess As Process = Process.Start("E:/Fuentes CM/ControlMantenimiento-NetDesktopVB/ControlMantenimiento-NetDesktopVB/Ayudas/Ayuda.chm")
        ' myProcess.WaitForExit()
        ' Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        ' donde descomprimió el archivo descargado de la web
    End Sub
End Class
