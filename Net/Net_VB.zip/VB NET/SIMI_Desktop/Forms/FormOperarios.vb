﻿Option Strict On

Public Class FormOperarios
    Private _controlador As Controlador_Operario = Funciones.crearControlador_Operario()
    Private grabar As Boolean
    Private rutaFoto As String = ""
    Private _Operario As Operario
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))
    Private elOperario As Integer = 0

    Private Sub FormOperarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim blankContextMenu As New ContextMenuStrip()
        TextBoxDocumento.ContextMenuStrip = blankContextMenu  'Deshabilitar la opcion de pegado
        TextBoxNombres.ContextMenuStrip = blankContextMenu
        TextBoxApellidos.ContextMenuStrip = blankContextMenu
        TextBoxTelefono.ContextMenuStrip = blankContextMenu
        CargarListaSeleccion()
    End Sub

    Private Sub CargarListaSeleccion()
        ListBoxOperarios.ValueMember = "CODIGO"        ' Documento de Operario a relacionar en BD
        ListBoxOperarios.DisplayMember = "DETALLE"     ' Visualizar Nombres y Apellidos de Operario
        ListBoxOperarios.DataSource = _controlador.cargarListado()
    End Sub

    Private Sub TextBoxDocumento_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxDocumento.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxDocumento.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.MensajeCampoRequerido)
                ElseIf (TextBoxDocumento.Text.Length < 6) Then
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje15, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje15)
                ElseIf (TextBoxDocumento.Text.Substring(0, 1) = "0") Then
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje6)
                Else
                    errorPro.Clear()
                    TextBoxNombres.Focus()
                End If
            Else
                If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                    e.Handled = True 'Establece el caracter a null si está fuera del intervalo
                End If
            End If
        End If

    End Sub

    Private Sub LlenarCampos()
        _Operario = CType(_controlador.obtenerOperario(elOperario), Operario)
        If (Not _Operario Is Nothing) Then
            TextBoxDocumento.Enabled = False
            If (Funciones.PerfilAcceso = 1) Then
                ButtonEliminar.Enabled = True
            End If
            TextBoxDocumento.Text = _Operario.Documento
            TextBoxNombres.Text = _Operario.Nombres
            TextBoxApellidos.Text = _Operario.Apellidos
            TextBoxCorreo.Text = _Operario.Correo
            TextBoxTelefono.Text = _Operario.Telefono.ToString()
            If Not String.IsNullOrEmpty(_Operario.Foto) Then
                Try
                    rutaFoto = _Operario.Foto
                    PictureBoxFotoUsuario.Image = Image.FromFile(rutaFoto)
                Catch ex As Exception
                    MessageBox.Show(Mensajes.Mensaje24, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End If
        TextBoxNombres.Focus()
    End Sub

    Private Sub TextBoxNombres_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombres.KeyPress
        If (e.KeyChar <> ChrW(Keys.Back) And e.KeyChar <> ChrW(Keys.Space)) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxNombres.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxNombres.Focus()
                    errorPro.SetError(TextBoxNombres, Mensajes.MensajeCampoRequerido)
                Else
                    TextBoxNombres.Text = Funciones.eliminarTabulador(TextBoxNombres.Text, "1MAY")
                    errorPro.Clear()
                    TextBoxApellidos.Focus()
                End If
            Else
                If (Convert.ToInt32(e.KeyChar) < 65) Or (Convert.ToInt32(e.KeyChar) > 90) And (Convert.ToInt32(e.KeyChar) < 97) Or (Convert.ToInt32(e.KeyChar) > 122) Then
                    e.Handled = True
                End If
            End If
        End If
    End Sub

    Private Sub TextBoxApellidos_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxApellidos.KeyPress
        If (e.KeyChar <> ChrW(Keys.Back) And e.KeyChar <> ChrW(Keys.Space)) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxApellidos.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxApellidos.Focus()
                    errorPro.SetError(TextBoxApellidos, Mensajes.MensajeCampoRequerido)
                Else
                    TextBoxApellidos.Text = Funciones.eliminarTabulador(TextBoxApellidos.Text, "1MAY")
                    errorPro.Clear()
                    TextBoxCorreo.Focus()
                End If
            Else
                If (Convert.ToInt32(e.KeyChar) < 65) Or (Convert.ToInt32(e.KeyChar) > 90) And (Convert.ToInt32(e.KeyChar) < 97) Or (Convert.ToInt32(e.KeyChar) > 122) Then
                    e.Handled = True
                End If
            End If
        End If
    End Sub
    Private Sub TextBoxCorreo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxCorreo.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (TextBoxCorreo.Text.Length <> 0) Then
                If (Funciones.validar_Correo(TextBoxCorreo.Text)) Then
                    errorPro.Clear()
                    TextBoxTelefono.Focus()
                Else
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje16, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxCorreo.Focus()
                    errorPro.SetError(TextBoxCorreo, Mensajes.Mensaje16)
                End If
            Else
                TextBoxTelefono.Focus()
            End If
        End If
    End Sub

    Private Sub TextBoxTelefono_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxTelefono.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxTelefono.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxTelefono.Focus()
                    errorPro.SetError(TextBoxTelefono, Mensajes.MensajeCampoRequerido)
                Else
                    If ((TextBoxTelefono.Text.Length <> 7) And (TextBoxTelefono.Text.Length <> 10)) Then
                        grabar = False
                        MessageBox.Show(Mensajes.Mensaje17, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        TextBoxTelefono.Focus()
                        errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje17)
                    ElseIf (TextBoxTelefono.Text.Substring(0, 1) = "0") Then
                        grabar = False
                        MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        TextBoxTelefono.Focus()
                        errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje6)
                    Else
                        errorPro.Clear()
                        ButtonGrabar.Focus()
                    End If
                End If
            Else
                If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                    e.Handled = True 'Establece el caracter a null si está fuera del intervalo
                End If
            End If
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        TextBoxDocumento_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            TextBoxNombres_KeyPress(ButtonGrabar, tecla)
            If (grabar) Then
                TextBoxApellidos_KeyPress(ButtonGrabar, tecla)
                If (grabar) Then
                    TextBoxCorreo_KeyPress(ButtonGrabar, tecla)
                    If (grabar) Then
                        TextBoxTelefono_KeyPress(ButtonGrabar, tecla)
                        If (grabar) Then
                            Guardar()
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        _Operario = New Operario()
        _Operario.Operario_id = elOperario
        _Operario.Documento = TextBoxDocumento.Text
        _Operario.Nombres = TextBoxNombres.Text.Trim
        _Operario.Apellidos = TextBoxApellidos.Text.Trim
        _Operario.Telefono = TextBoxTelefono.Text.Trim
        _Operario.Correo = TextBoxCorreo.Text.ToLower().Trim
        _Operario.Foto = rutaFoto
        Resultado = _controlador.guardarOperario(_Operario)
        If (Resultado = 0) Then
            If (_Operario.Operario_id = 0) Then
                MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            If (Funciones.PerfilAcceso = 1) Then
                CargarListaSeleccion()
            Else
                ButtonSalir.PerformClick()
            End If
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.Mensaje26, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        Limpiar()
    End Sub

    Private Sub Limpiar()
        elOperario = 0
        ButtonEliminar.Enabled = False
        Funciones.limpiarForma(panel2)
        errorPro.Clear()
        PictureBoxFotoUsuario.Image = Nothing
        rutaFoto = ""
        ListBoxOperarios.Visible = False
        TextBoxDocumento.Enabled = True ' Habilitar Campo de documento si esta Inactivo            
        TextBoxDocumento.Focus()
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        If (ListBoxOperarios.Items.Count <> 0) Then
            ListBoxOperarios.Visible = True
        End If
    End Sub

    Private Sub lstOperarios_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBoxOperarios.DoubleClick
        elOperario = Convert.ToInt32(ListBoxOperarios.SelectedValue.ToString())
        ListBoxOperarios.Visible = False
        LlenarCampos()
    End Sub

    Private Sub PictureBoxFotoUsuario_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBoxFotoUsuario.Click
        Dim oFD As New OpenFileDialog
        oFD.Title = "Seleccionar imagen"
        oFD.Filter = "Imagenes|*.jpg;*.gif;*.png;*.bmp|Todos (*.*)|*.*"
        If (oFD.ShowDialog() = DialogResult.OK) Then
            rutaFoto = oFD.FileName
            Dim peso As New System.IO.FileInfo(oFD.FileName)
            If (rutaFoto.Length > 50) Then
                MessageBox.Show(Mensajes.Mensaje28, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf (peso.Length > 133000) Then 'Imagen de 3x4 no debería superar este peso 
                MessageBox.Show(Mensajes.Mensaje29, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                PictureBoxFotoUsuario.Image = Image.FromFile(rutaFoto)
            End If
        End If
    End Sub

    Private Sub lblBorrarFoto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblBorrarFoto.Click
        PictureBoxFotoUsuario.Image = Nothing
        rutaFoto = ""
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        Dim Resultado As Integer
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            Resultado = _controlador.eliminarRegistro(elOperario)
            If (Resultado = 0) Then
                CargarListaSeleccion()
                Limpiar()
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf (Resultado = 1) Then
                MessageBox.Show(Mensajes.Mensaje20, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _Operario = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        ' Dim myProcess As Process = Process.Start("E:/Fuentes CM/ControlMantenimiento-NetDesktopVB/ControlMantenimiento-NetDesktopVB/Ayudas/Ayuda.chm")
        ' myProcess.WaitForExit()
        ' Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        ' donde descomprimió el archivo descargado de la web
    End Sub
End Class
