﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCambioClave
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormCambioClave))
        Me.label3 = New System.Windows.Forms.Label()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        Me.ButtonSalir = New System.Windows.Forms.Button()
        Me.ButtonGrabar = New System.Windows.Forms.Button()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.TextBoxConfirmar = New System.Windows.Forms.TextBox()
        Me.TextBoxClaveNueva = New System.Windows.Forms.TextBox()
        Me.TextBoxClave = New System.Windows.Forms.TextBox()
        Me.errorPro = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.panel1.SuspendLayout()
        Me.panel2.SuspendLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(126, 113)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(60, 13)
        Me.label3.TabIndex = 22
        Me.label3.Text = "Confirmar"
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.Gray
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.ButtonCancelar)
        Me.panel1.Controls.Add(Me.ButtonSalir)
        Me.panel1.Controls.Add(Me.ButtonGrabar)
        Me.panel1.Location = New System.Drawing.Point(17, 175)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(452, 68)
        Me.panel1.TabIndex = 284
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCancelar.ForeColor = System.Drawing.Color.Black
        Me.ButtonCancelar.Image = CType(resources.GetObject("ButtonCancelar.Image"), System.Drawing.Image)
        Me.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonCancelar.Location = New System.Drawing.Point(195, 17)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonCancelar.TabIndex = 4
        Me.ButtonCancelar.TabStop = False
        Me.ButtonCancelar.Text = "Cancelar"
        Me.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonCancelar.UseVisualStyleBackColor = False
        '
        'ButtonSalir
        '
        Me.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSalir.ForeColor = System.Drawing.Color.Black
        Me.ButtonSalir.Image = CType(resources.GetObject("ButtonSalir.Image"), System.Drawing.Image)
        Me.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonSalir.Location = New System.Drawing.Point(252, 17)
        Me.ButtonSalir.Name = "ButtonSalir"
        Me.ButtonSalir.Size = New System.Drawing.Size(60, 35)
        Me.ButtonSalir.TabIndex = 6
        Me.ButtonSalir.TabStop = False
        Me.ButtonSalir.Text = "Salir"
        Me.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonSalir.UseVisualStyleBackColor = False
        '
        'ButtonGrabar
        '
        Me.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonGrabar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGrabar.ForeColor = System.Drawing.Color.Black
        Me.ButtonGrabar.Image = CType(resources.GetObject("ButtonGrabar.Image"), System.Drawing.Image)
        Me.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonGrabar.Location = New System.Drawing.Point(139, 17)
        Me.ButtonGrabar.Name = "ButtonGrabar"
        Me.ButtonGrabar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonGrabar.TabIndex = 3
        Me.ButtonGrabar.TabStop = False
        Me.ButtonGrabar.Text = "Modificar"
        Me.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonGrabar.UseVisualStyleBackColor = False
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(126, 72)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(80, 13)
        Me.label2.TabIndex = 21
        Me.label2.Text = "Clave Nueva"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(126, 30)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(79, 13)
        Me.label1.TabIndex = 20
        Me.label1.Text = "Clave Actual"
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.label3)
        Me.panel2.Controls.Add(Me.label2)
        Me.panel2.Controls.Add(Me.label1)
        Me.panel2.Controls.Add(Me.TextBoxConfirmar)
        Me.panel2.Controls.Add(Me.TextBoxClaveNueva)
        Me.panel2.Controls.Add(Me.TextBoxClave)
        Me.panel2.Location = New System.Drawing.Point(17, 9)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(452, 169)
        Me.panel2.TabIndex = 283
        '
        'TextBoxConfirmar
        '
        Me.TextBoxConfirmar.Location = New System.Drawing.Point(211, 110)
        Me.TextBoxConfirmar.MaxLength = 6
        Me.TextBoxConfirmar.Name = "TextBoxConfirmar"
        Me.TextBoxConfirmar.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBoxConfirmar.Size = New System.Drawing.Size(44, 20)
        Me.TextBoxConfirmar.TabIndex = 2
        Me.TextBoxConfirmar.TabStop = False
        '
        'TextBoxClaveNueva
        '
        Me.TextBoxClaveNueva.Location = New System.Drawing.Point(211, 69)
        Me.TextBoxClaveNueva.MaxLength = 6
        Me.TextBoxClaveNueva.Name = "TextBoxClaveNueva"
        Me.TextBoxClaveNueva.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBoxClaveNueva.Size = New System.Drawing.Size(44, 20)
        Me.TextBoxClaveNueva.TabIndex = 1
        Me.TextBoxClaveNueva.TabStop = False
        '
        'TextBoxClave
        '
        Me.TextBoxClave.Location = New System.Drawing.Point(211, 27)
        Me.TextBoxClave.MaxLength = 6
        Me.TextBoxClave.Name = "TextBoxClave"
        Me.TextBoxClave.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBoxClave.Size = New System.Drawing.Size(44, 20)
        Me.TextBoxClave.TabIndex = 0
        Me.TextBoxClave.TabStop = False
        '
        'errorPro
        '
        Me.errorPro.ContainerControl = Me
        '
        'FormCambioClave
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(486, 252)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "FormCambioClave"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Cambio Clave"
        Me.panel1.ResumeLayout(False)
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents ButtonCancelar As System.Windows.Forms.Button
    Private WithEvents ButtonSalir As System.Windows.Forms.Button
    Private WithEvents ButtonGrabar As System.Windows.Forms.Button
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents TextBoxConfirmar As System.Windows.Forms.TextBox
    Private WithEvents TextBoxClaveNueva As System.Windows.Forms.TextBox
    Private WithEvents TextBoxClave As System.Windows.Forms.TextBox
    Private WithEvents errorPro As System.Windows.Forms.ErrorProvider
End Class
