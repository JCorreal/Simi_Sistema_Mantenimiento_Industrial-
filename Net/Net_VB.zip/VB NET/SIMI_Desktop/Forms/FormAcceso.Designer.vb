﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAcceso
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAcceso))
        Me.TextBoxDocumento = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.ButtonSalir = New System.Windows.Forms.Button()
        Me.ButtonAyuda = New System.Windows.Forms.Button()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        Me.ButtonIngresar = New System.Windows.Forms.Button()
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.label1 = New System.Windows.Forms.Label()
        Me.TextBoxClave = New System.Windows.Forms.TextBox()
        Me.errorPro = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.panel1.SuspendLayout()
        Me.panel2.SuspendLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBoxDocumento
        '
        Me.TextBoxDocumento.Location = New System.Drawing.Point(173, 24)
        Me.TextBoxDocumento.MaxLength = 10
        Me.TextBoxDocumento.Name = "TextBoxDocumento"
        Me.TextBoxDocumento.Size = New System.Drawing.Size(68, 20)
        Me.TextBoxDocumento.TabIndex = 0
        Me.TextBoxDocumento.TabStop = False
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(96, 72)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(39, 13)
        Me.label4.TabIndex = 340
        Me.label4.Text = "Clave"
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.Gray
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.ButtonSalir)
        Me.panel1.Controls.Add(Me.ButtonAyuda)
        Me.panel1.Controls.Add(Me.ButtonCancelar)
        Me.panel1.Controls.Add(Me.ButtonIngresar)
        Me.panel1.Location = New System.Drawing.Point(-1, 123)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(369, 60)
        Me.panel1.TabIndex = 286
        '
        'ButtonSalir
        '
        Me.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSalir.ForeColor = System.Drawing.Color.Black
        Me.ButtonSalir.Image = CType(resources.GetObject("ButtonSalir.Image"), System.Drawing.Image)
        Me.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonSalir.Location = New System.Drawing.Point(238, 16)
        Me.ButtonSalir.Name = "ButtonSalir"
        Me.ButtonSalir.Size = New System.Drawing.Size(60, 35)
        Me.ButtonSalir.TabIndex = 5
        Me.ButtonSalir.TabStop = False
        Me.ButtonSalir.Text = "Salir"
        Me.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonSalir.UseVisualStyleBackColor = False
        '
        'ButtonAyuda
        '
        Me.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonAyuda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAyuda.ForeColor = System.Drawing.Color.Black
        Me.ButtonAyuda.Image = CType(resources.GetObject("ButtonAyuda.Image"), System.Drawing.Image)
        Me.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonAyuda.Location = New System.Drawing.Point(181, 16)
        Me.ButtonAyuda.Name = "ButtonAyuda"
        Me.ButtonAyuda.Size = New System.Drawing.Size(60, 35)
        Me.ButtonAyuda.TabIndex = 4
        Me.ButtonAyuda.TabStop = False
        Me.ButtonAyuda.Text = "Ayuda"
        Me.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonAyuda.UseVisualStyleBackColor = False
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCancelar.ForeColor = System.Drawing.Color.Black
        Me.ButtonCancelar.Image = CType(resources.GetObject("ButtonCancelar.Image"), System.Drawing.Image)
        Me.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonCancelar.Location = New System.Drawing.Point(129, 16)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonCancelar.TabIndex = 3
        Me.ButtonCancelar.TabStop = False
        Me.ButtonCancelar.Text = "Cancelar"
        Me.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonCancelar.UseVisualStyleBackColor = False
        '
        'ButtonIngresar
        '
        Me.ButtonIngresar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonIngresar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonIngresar.ForeColor = System.Drawing.Color.Black
        Me.ButtonIngresar.Image = CType(resources.GetObject("ButtonIngresar.Image"), System.Drawing.Image)
        Me.ButtonIngresar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonIngresar.Location = New System.Drawing.Point(75, 16)
        Me.ButtonIngresar.Name = "ButtonIngresar"
        Me.ButtonIngresar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonIngresar.TabIndex = 2
        Me.ButtonIngresar.TabStop = False
        Me.ButtonIngresar.Text = "Ingresar"
        Me.ButtonIngresar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonIngresar.UseVisualStyleBackColor = False
        '
        'panel2
        '
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.TextBoxDocumento)
        Me.panel2.Controls.Add(Me.label4)
        Me.panel2.Controls.Add(Me.panel1)
        Me.panel2.Controls.Add(Me.label1)
        Me.panel2.Controls.Add(Me.TextBoxClave)
        Me.panel2.Location = New System.Drawing.Point(26, 20)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(369, 185)
        Me.panel2.TabIndex = 288
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(94, 27)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(50, 13)
        Me.label1.TabIndex = 337
        Me.label1.Text = "Usuario"
        '
        'TextBoxClave
        '
        Me.TextBoxClave.Location = New System.Drawing.Point(173, 69)
        Me.TextBoxClave.MaxLength = 6
        Me.TextBoxClave.Name = "TextBoxClave"
        Me.TextBoxClave.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBoxClave.Size = New System.Drawing.Size(39, 20)
        Me.TextBoxClave.TabIndex = 1
        Me.TextBoxClave.TabStop = False
        '
        'errorPro
        '
        Me.errorPro.ContainerControl = Me
        '
        'FormAcceso
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(421, 225)
        Me.Controls.Add(Me.panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "FormAcceso"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Acceso SIMI"
        Me.panel1.ResumeLayout(False)
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents TextBoxDocumento As System.Windows.Forms.TextBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents panel1 As System.Windows.Forms.Panel
    Private WithEvents ButtonSalir As System.Windows.Forms.Button
    Private WithEvents ButtonAyuda As System.Windows.Forms.Button
    Private WithEvents ButtonCancelar As System.Windows.Forms.Button
    Private WithEvents ButtonIngresar As System.Windows.Forms.Button
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents TextBoxClave As System.Windows.Forms.TextBox
    Private WithEvents errorPro As System.Windows.Forms.ErrorProvider
End Class
