﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormListaValores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormListaValores))
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.label3 = New System.Windows.Forms.Label()
        Me.ButtonCancelar = New System.Windows.Forms.Button()
        Me.label2 = New System.Windows.Forms.Label()
        Me.TextBoxDescripcion = New System.Windows.Forms.TextBox()
        Me.ButtonSalir = New System.Windows.Forms.Button()
        Me.ButtonAyuda = New System.Windows.Forms.Button()
        Me.TextBoxNombre = New System.Windows.Forms.TextBox()
        Me.ButtonGrabar = New System.Windows.Forms.Button()
        Me.ButtonEliminar = New System.Windows.Forms.Button()
        Me.errorPro = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.Label_Lineas = New System.Windows.Forms.Label()
        Me.Label_Marcas = New System.Windows.Forms.Label()
        Me.panel2.SuspendLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.Color.White
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.label3)
        Me.panel2.Controls.Add(Me.ButtonCancelar)
        Me.panel2.Controls.Add(Me.label2)
        Me.panel2.Controls.Add(Me.TextBoxDescripcion)
        Me.panel2.Controls.Add(Me.ButtonSalir)
        Me.panel2.Controls.Add(Me.ButtonAyuda)
        Me.panel2.Controls.Add(Me.TextBoxNombre)
        Me.panel2.Controls.Add(Me.ButtonGrabar)
        Me.panel2.Controls.Add(Me.ButtonEliminar)
        Me.panel2.Location = New System.Drawing.Point(425, 180)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(493, 256)
        Me.panel2.TabIndex = 280
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(99, 123)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(74, 13)
        Me.label3.TabIndex = 283
        Me.label3.Text = "Descripcion"
        '
        'ButtonCancelar
        '
        Me.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonCancelar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCancelar.ForeColor = System.Drawing.Color.Black
        Me.ButtonCancelar.Image = CType(resources.GetObject("ButtonCancelar.Image"), System.Drawing.Image)
        Me.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonCancelar.Location = New System.Drawing.Point(156, 204)
        Me.ButtonCancelar.Name = "ButtonCancelar"
        Me.ButtonCancelar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonCancelar.TabIndex = 4
        Me.ButtonCancelar.TabStop = False
        Me.ButtonCancelar.Text = "Cancelar"
        Me.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonCancelar.UseVisualStyleBackColor = False
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(99, 55)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(50, 13)
        Me.label2.TabIndex = 282
        Me.label2.Text = "Nombre"
        '
        'TextBoxDescripcion
        '
        Me.TextBoxDescripcion.Location = New System.Drawing.Point(179, 91)
        Me.TextBoxDescripcion.MaxLength = 25
        Me.TextBoxDescripcion.Multiline = True
        Me.TextBoxDescripcion.Name = "TextBoxDescripcion"
        Me.TextBoxDescripcion.Size = New System.Drawing.Size(208, 65)
        Me.TextBoxDescripcion.TabIndex = 2
        Me.TextBoxDescripcion.TabStop = False
        '
        'ButtonSalir
        '
        Me.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.ButtonSalir.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSalir.ForeColor = System.Drawing.Color.Black
        Me.ButtonSalir.Image = CType(resources.GetObject("ButtonSalir.Image"), System.Drawing.Image)
        Me.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonSalir.Location = New System.Drawing.Point(327, 204)
        Me.ButtonSalir.Name = "ButtonSalir"
        Me.ButtonSalir.Size = New System.Drawing.Size(60, 35)
        Me.ButtonSalir.TabIndex = 7
        Me.ButtonSalir.TabStop = False
        Me.ButtonSalir.Text = "Salir"
        Me.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonSalir.UseVisualStyleBackColor = False
        '
        'ButtonAyuda
        '
        Me.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonAyuda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAyuda.ForeColor = System.Drawing.Color.Black
        Me.ButtonAyuda.Image = CType(resources.GetObject("ButtonAyuda.Image"), System.Drawing.Image)
        Me.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonAyuda.Location = New System.Drawing.Point(270, 204)
        Me.ButtonAyuda.Name = "ButtonAyuda"
        Me.ButtonAyuda.Size = New System.Drawing.Size(60, 35)
        Me.ButtonAyuda.TabIndex = 6
        Me.ButtonAyuda.TabStop = False
        Me.ButtonAyuda.Text = "Ayuda"
        Me.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonAyuda.UseVisualStyleBackColor = False
        '
        'TextBoxNombre
        '
        Me.TextBoxNombre.Location = New System.Drawing.Point(179, 52)
        Me.TextBoxNombre.MaxLength = 25
        Me.TextBoxNombre.Name = "TextBoxNombre"
        Me.TextBoxNombre.Size = New System.Drawing.Size(208, 20)
        Me.TextBoxNombre.TabIndex = 1
        Me.TextBoxNombre.TabStop = False
        '
        'ButtonGrabar
        '
        Me.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonGrabar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGrabar.ForeColor = System.Drawing.Color.Black
        Me.ButtonGrabar.Image = CType(resources.GetObject("ButtonGrabar.Image"), System.Drawing.Image)
        Me.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonGrabar.Location = New System.Drawing.Point(100, 204)
        Me.ButtonGrabar.Name = "ButtonGrabar"
        Me.ButtonGrabar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonGrabar.TabIndex = 3
        Me.ButtonGrabar.TabStop = False
        Me.ButtonGrabar.Text = "Grabar"
        Me.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonGrabar.UseVisualStyleBackColor = False
        '
        'ButtonEliminar
        '
        Me.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ButtonEliminar.Enabled = False
        Me.ButtonEliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEliminar.ForeColor = System.Drawing.Color.Black
        Me.ButtonEliminar.Image = CType(resources.GetObject("ButtonEliminar.Image"), System.Drawing.Image)
        Me.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ButtonEliminar.Location = New System.Drawing.Point(213, 204)
        Me.ButtonEliminar.Name = "ButtonEliminar"
        Me.ButtonEliminar.Size = New System.Drawing.Size(60, 35)
        Me.ButtonEliminar.TabIndex = 5
        Me.ButtonEliminar.TabStop = False
        Me.ButtonEliminar.Text = "Eliminar"
        Me.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ButtonEliminar.UseVisualStyleBackColor = False
        '
        'errorPro
        '
        Me.errorPro.ContainerControl = Me
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.Teal
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.Label_Lineas)
        Me.panel1.Controls.Add(Me.Label_Marcas)
        Me.panel1.Location = New System.Drawing.Point(425, 124)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(493, 60)
        Me.panel1.TabIndex = 332
        '
        'Label_Lineas
        '
        Me.Label_Lineas.AutoSize = True
        Me.Label_Lineas.BackColor = System.Drawing.Color.Transparent
        Me.Label_Lineas.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Lineas.ForeColor = System.Drawing.Color.White
        Me.Label_Lineas.Image = Global.SIMI_Desktop.My.Resources.Resources.icolineas
        Me.Label_Lineas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label_Lineas.Location = New System.Drawing.Point(3, 16)
        Me.Label_Lineas.Name = "Label_Lineas"
        Me.Label_Lineas.Size = New System.Drawing.Size(105, 25)
        Me.Label_Lineas.TabIndex = 1
        Me.Label_Lineas.Text = "       Lineas"
        Me.Label_Lineas.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label_Marcas
        '
        Me.Label_Marcas.AutoSize = True
        Me.Label_Marcas.BackColor = System.Drawing.Color.Transparent
        Me.Label_Marcas.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Marcas.ForeColor = System.Drawing.Color.White
        Me.Label_Marcas.Image = Global.SIMI_Desktop.My.Resources.Resources.icomarca
        Me.Label_Marcas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Label_Marcas.Location = New System.Drawing.Point(3, 16)
        Me.Label_Marcas.Name = "Label_Marcas"
        Me.Label_Marcas.Size = New System.Drawing.Size(112, 25)
        Me.Label_Marcas.TabIndex = 0
        Me.Label_Marcas.Text = "       Marcas"
        Me.Label_Marcas.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'FormListaValores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.SIMI_Desktop.My.Resources.Resources.Plantilla
        Me.ClientSize = New System.Drawing.Size(1034, 460)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "FormListaValores"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        CType(Me.errorPro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents panel2 As System.Windows.Forms.Panel
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents TextBoxDescripcion As System.Windows.Forms.TextBox
    Private WithEvents TextBoxNombre As System.Windows.Forms.TextBox
    Private WithEvents ButtonAyuda As System.Windows.Forms.Button
    Private WithEvents ButtonGrabar As System.Windows.Forms.Button
    Private WithEvents ButtonEliminar As System.Windows.Forms.Button
    Private WithEvents ButtonSalir As System.Windows.Forms.Button
    Private WithEvents ButtonCancelar As System.Windows.Forms.Button
    Private WithEvents errorPro As System.Windows.Forms.ErrorProvider
    Private WithEvents panel1 As Panel
    Friend WithEvents Label_Marcas As Label
    Friend WithEvents Label_Lineas As Label
End Class
