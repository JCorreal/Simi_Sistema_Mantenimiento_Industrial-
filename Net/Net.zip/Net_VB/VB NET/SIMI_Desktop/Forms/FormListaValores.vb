﻿Option Strict On

Public Class FormListaValores
    Private _controlador As Controlador_ListaValores = Funciones.crearControlador_ListaValores()
    Private grabar As Boolean
    Private _ListaValores As ListaValores
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub FormListaValores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = Funciones.ValorTipo.ToLower()
        If Funciones.ValorTipo = "MARCAS" Then
            Label_Lineas.Visible = False
            Label_Marcas.Visible = True
        ElseIf Funciones.ValorTipo = "LINEAS" Then
            Label_Lineas.Visible = True
            Label_Marcas.Visible = False
        End If
        Me.Text = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(Me.Text)
        If (Funciones.ParametroBuscar <> 0) Then
            consultarBD()
        End If
    End Sub

    Private Sub consultarBD()
        _ListaValores = CType(_controlador.obtenerListaValores(Funciones.ParametroBuscar), ListaValores)
        If (Not _ListaValores Is Nothing) Then
            poblarFormulario()
        End If
    End Sub

    Private Sub poblarFormulario()
        ButtonEliminar.Enabled = True
        TextBoxNombre.Text = _ListaValores.Nombre
        TextBoxDescripcion.Text = _ListaValores.Descripcion
        TextBoxNombre.Focus()
    End Sub

    Private Sub TextBoxNombre_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombre.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (Funciones.validar_CampoVacio(TextBoxNombre.Text)) Then
                grabar = False
                MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBoxNombre.Focus()
                errorPro.SetError(TextBoxNombre, Mensajes.MensajeCampoRequerido)
            Else
                TextBoxDescripcion.Focus()
            End If
        End If
    End Sub

    Private Sub TextBoxDescripcion_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxDescripcion.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            Funciones.eliminarTabulador(TextBoxDescripcion.Text, "")
            ButtonGrabar.Focus()
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        TextBoxNombre_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            Guardar()
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        _ListaValores = New ListaValores
        _ListaValores.Listavalores_id = Funciones.ParametroBuscar
        _ListaValores.Nombre = TextBoxNombre.Text.Trim
        _ListaValores.Descripcion = TextBoxDescripcion.Text.Trim
        _ListaValores.Tipo = Funciones.ValorTipo
        Resultado = _controlador.guardarListaValores(_ListaValores)
        If (Resultado = 0) Then
            If (Funciones.ParametroBuscar = 0) Then
                MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Limpiar()
            Else
                MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            End If
        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.Mensaje8, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBoxNombre.Focus()
            errorPro.SetError(TextBoxNombre, Mensajes.Mensaje8)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Limpiar()
        If (Funciones.ParametroBuscar = 0) Then
            For Each oControls As Control In panel2.Controls
                If (TypeOf oControls Is TextBox) Then
                    oControls.Text = String.Empty
                    Continue For
                End If
            Next
            errorPro.Clear()
            TextBoxNombre.Focus()
        Else
            poblarFormulario()
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        Dim Resultado As Integer
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            Resultado = _controlador.eliminarRegistro(Convert.ToInt32(Funciones.ParametroBuscar))
            If (Resultado = 0) Then
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            ElseIf (Resultado = 1) Then
                MessageBox.Show(Mensajes.Mensaje9, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _ListaValores = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        Funciones.MostrarAyuda()
    End Sub
End Class
