﻿Public Class FormMenu


    Private Sub FormMenu2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If (Funciones.PerfilAcceso = 1) Then
            Button_Equipos.Enabled = True
            Button_Marcas.Enabled = True
            Button_Lineas.Enabled = True
            Button_Mantenimiento.Enabled = True
        End If
        lblUsuarioConectado.Text = lblUsuarioConectado.Text + " " + Funciones.NombreUsuario
    End Sub

    Private Sub Button_Operarios_Click(sender As Object, e As EventArgs) Handles Button_Operarios.Click
        If (Funciones.PerfilAcceso = 1) Then
            Funciones.Source = "Operarios"
            FormListados.ShowDialog()
        Else
            Funciones.ParametroBuscar = Funciones.UsuarioConectado
            FormOperarios.ShowDialog()
        End If
    End Sub

    Private Sub Button_Equipos_Click(sender As Object, e As EventArgs) Handles Button_Equipos.Click
        Funciones.Source = "Equipos"
        FormListados.ShowDialog()
    End Sub

    Private Sub Button_Marcas_Click(sender As Object, e As EventArgs) Handles Button_Marcas.Click
        Funciones.Source = "Marcas"
        FormListados.ShowDialog()
    End Sub

    Private Sub Button_Lineas_Click(sender As Object, e As EventArgs) Handles Button_Lineas.Click
        Funciones.Source = "Lineas"
        FormListados.ShowDialog()
    End Sub

    Private Sub Button_Mantenimiento_Click(sender As Object, e As EventArgs) Handles Button_Mantenimiento.Click
        Funciones.Source = "Mantenimiento"
        FormListados.ShowDialog()
    End Sub

    Private Sub Button_Clave_Click(sender As Object, e As EventArgs) Handles Button_Clave.Click
        FormCambioClave.ShowDialog()
    End Sub
End Class