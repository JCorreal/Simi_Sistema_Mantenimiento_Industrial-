﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormListados
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TextBox_Buscar = New System.Windows.Forms.TextBox()
        Me.Button_Nuevo = New System.Windows.Forms.Button()
        Me.Label_Buscar = New System.Windows.Forms.Label()
        Me.Button_Menu = New System.Windows.Forms.Button()
        Me.Button_Buscar = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(362, 243)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(654, 150)
        Me.DataGridView1.TabIndex = 3
        '
        'TextBox_Buscar
        '
        Me.TextBox_Buscar.Location = New System.Drawing.Point(664, 174)
        Me.TextBox_Buscar.Name = "TextBox_Buscar"
        Me.TextBox_Buscar.Size = New System.Drawing.Size(169, 20)
        Me.TextBox_Buscar.TabIndex = 6
        '
        'Button_Nuevo
        '
        Me.Button_Nuevo.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button_Nuevo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Nuevo.ForeColor = System.Drawing.Color.Black
        Me.Button_Nuevo.Image = Global.SIMI_Desktop.My.Resources.Resources.Nuevo
        Me.Button_Nuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Nuevo.Location = New System.Drawing.Point(502, 163)
        Me.Button_Nuevo.Name = "Button_Nuevo"
        Me.Button_Nuevo.Size = New System.Drawing.Size(75, 31)
        Me.Button_Nuevo.TabIndex = 10
        Me.Button_Nuevo.TabStop = False
        Me.Button_Nuevo.Text = "Nuevo"
        Me.Button_Nuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Nuevo.UseVisualStyleBackColor = False
        '
        'Label_Buscar
        '
        Me.Label_Buscar.AutoSize = True
        Me.Label_Buscar.BackColor = System.Drawing.Color.Transparent
        Me.Label_Buscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Buscar.ForeColor = System.Drawing.Color.Teal
        Me.Label_Buscar.Location = New System.Drawing.Point(387, 49)
        Me.Label_Buscar.Name = "Label_Buscar"
        Me.Label_Buscar.Size = New System.Drawing.Size(169, 13)
        Me.Label_Buscar.TabIndex = 11
        Me.Label_Buscar.Text = "Operario se busca por Documento"
        '
        'Button_Menu
        '
        Me.Button_Menu.Image = Global.SIMI_Desktop.My.Resources.Resources.casa
        Me.Button_Menu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Menu.Location = New System.Drawing.Point(74, 72)
        Me.Button_Menu.Name = "Button_Menu"
        Me.Button_Menu.Size = New System.Drawing.Size(104, 29)
        Me.Button_Menu.TabIndex = 13
        Me.Button_Menu.Text = "Menú Principal"
        Me.Button_Menu.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Menu.UseVisualStyleBackColor = True
        '
        'Button_Buscar
        '
        Me.Button_Buscar.Image = Global.SIMI_Desktop.My.Resources.Resources.Consulta
        Me.Button_Buscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button_Buscar.Location = New System.Drawing.Point(583, 163)
        Me.Button_Buscar.Name = "Button_Buscar"
        Me.Button_Buscar.Size = New System.Drawing.Size(75, 32)
        Me.Button_Buscar.TabIndex = 14
        Me.Button_Buscar.Text = "Buscar"
        Me.Button_Buscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button_Buscar.UseVisualStyleBackColor = True
        '
        'FormListados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.SIMI_Desktop.My.Resources.Resources.Plantilla
        Me.ClientSize = New System.Drawing.Size(1132, 592)
        Me.Controls.Add(Me.Button_Buscar)
        Me.Controls.Add(Me.Button_Menu)
        Me.Controls.Add(Me.Label_Buscar)
        Me.Controls.Add(Me.Button_Nuevo)
        Me.Controls.Add(Me.TextBox_Buscar)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "FormListados"
        Me.Text = "FormListados"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TextBox_Buscar As TextBox
    Private WithEvents Button_Nuevo As Button
    Friend WithEvents Label_Buscar As Label
    Friend WithEvents Button_Menu As Button
    Friend WithEvents Button_Buscar As Button
End Class
