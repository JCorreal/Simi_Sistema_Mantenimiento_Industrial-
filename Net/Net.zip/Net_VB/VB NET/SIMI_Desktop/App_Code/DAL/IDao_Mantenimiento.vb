﻿' Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

Option Strict On

Public Interface IDao_Mantenimiento

    Function obtenerMantenimiento(ByVal datoBuscar As Integer) As Mantenimiento
    Function guardarMantenimiento(_Mantenimiento As Mantenimiento, ByVal Usuario As Integer) As Integer
    Function cargarListado() As ArrayList
    Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer
    Sub CargarDatosCombos(ByVal tabla As String)
End Interface
