﻿Option Strict On

Public Class Controlador_Equipo
    Private ReadOnly _dao_equipo As IDao_Equipo

    Sub New(dao_equipo As IDao_Equipo)
        _dao_equipo = dao_equipo
    End Sub

    Public Function cargarListado() As ArrayList
        Return _dao_equipo.cargarListado()
    End Function

    Public Function obtenerEquipo(ByVal datoBuscar As Integer) As Object
        Return _dao_equipo.obtenerEquipo(datoBuscar)
    End Function

    Public Function guardarEquipo(ByVal _Equipo As Equipo) As Integer
        Return _dao_equipo.guardarEquipo(_Equipo, Funciones.UsuarioConectado)
    End Function

    Public Function eliminarRegistro(ByVal datoEliminar As Integer) As Integer
        Return _dao_equipo.eliminarRegistro(datoEliminar)
    End Function
    Public Sub CargarDatosCombos(ByVal tabla As String)
        _dao_equipo.CargarDatosCombos(tabla)
    End Sub

End Class
