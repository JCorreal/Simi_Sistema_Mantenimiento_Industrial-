﻿// Clase para cargar en los Repeater los diferentes listados
namespace ControlMantenimiento_NetWeb.BO
{
    public class CargarListado
    {
        public string Columna1 { get; set; }
        public string Columna2 { get; set; }
        public string Columna3 { get; set; }
        public string Columna4 { get; set; }
        public string Columna5 { get; set; }
        public string Columna6 { get; set; }


        public CargarListado() { }

        public CargarListado(string Columna1, string Columna2, string Columna3, string Columna4, string Columna5, string Columna6)
        {
            this.Columna1 = Columna1;
            this.Columna2 = Columna2;
            this.Columna3 = Columna3;
            this.Columna4 = Columna4;
            this.Columna5 = Columna5;
            this.Columna6 = Columna6;
        }
    }
}