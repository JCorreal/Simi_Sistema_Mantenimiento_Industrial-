﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using System.Collections;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public interface IDao_ListaValores
    {
        ListaValores obtenerListaValores(int datoBuscar);
       
        int guardarListaValores(ListaValores listavalores, int usuario);
       
        ArrayList cargarListado(string Tabla);
        ArrayList controlProgramacion(string Tabla);
        int eliminarRegistro(int DatoEliminar);
    }
        
}
