﻿namespace SIMI_Desktop
{
    partial class FormOperarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOperarios));
            this.ButtonGrabar = new System.Windows.Forms.Button();
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonAyuda = new System.Windows.Forms.Button();
            this.ButtonEliminar = new System.Windows.Forms.Button();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LabelBorrarFoto = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PictureBoxFotoUsuario = new System.Windows.Forms.PictureBox();
            this.TextBoxTelefono = new System.Windows.Forms.TextBox();
            this.TextBoxCorreo = new System.Windows.Forms.TextBox();
            this.TextBoxApellidos = new System.Windows.Forms.TextBox();
            this.TextBoxNombres = new System.Windows.Forms.TextBox();
            this.TextBoxDocumento = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFotoUsuario)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ButtonGrabar
            // 
            this.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonGrabar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGrabar.ForeColor = System.Drawing.Color.Black;
            this.ButtonGrabar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonGrabar.Image")));
            this.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonGrabar.Location = new System.Drawing.Point(110, 251);
            this.ButtonGrabar.Name = "ButtonGrabar";
            this.ButtonGrabar.Size = new System.Drawing.Size(60, 35);
            this.ButtonGrabar.TabIndex = 7;
            this.ButtonGrabar.TabStop = false;
            this.ButtonGrabar.Text = "Grabar";
            this.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonGrabar.UseVisualStyleBackColor = false;
            this.ButtonGrabar.Click += new System.EventHandler(this.ButtonGrabar_Click);
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(337, 251);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(60, 35);
            this.ButtonSalir.TabIndex = 11;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonAyuda
            // 
            this.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAyuda.ForeColor = System.Drawing.Color.Black;
            this.ButtonAyuda.Image = ((System.Drawing.Image)(resources.GetObject("ButtonAyuda.Image")));
            this.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonAyuda.Location = new System.Drawing.Point(280, 251);
            this.ButtonAyuda.Name = "ButtonAyuda";
            this.ButtonAyuda.Size = new System.Drawing.Size(60, 35);
            this.ButtonAyuda.TabIndex = 10;
            this.ButtonAyuda.TabStop = false;
            this.ButtonAyuda.Text = "Ayuda";
            this.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonAyuda.UseVisualStyleBackColor = false;
            this.ButtonAyuda.Click += new System.EventHandler(this.ButtonAyuda_Click);
            // 
            // ButtonEliminar
            // 
            this.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonEliminar.Enabled = false;
            this.ButtonEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonEliminar.ForeColor = System.Drawing.Color.Black;
            this.ButtonEliminar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonEliminar.Image")));
            this.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonEliminar.Location = new System.Drawing.Point(223, 251);
            this.ButtonEliminar.Name = "ButtonEliminar";
            this.ButtonEliminar.Size = new System.Drawing.Size(60, 35);
            this.ButtonEliminar.TabIndex = 9;
            this.ButtonEliminar.TabStop = false;
            this.ButtonEliminar.Text = "Eliminar";
            this.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonEliminar.UseVisualStyleBackColor = false;
            this.ButtonEliminar.Click += new System.EventHandler(this.ButtonEliminar_Click);
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(166, 251);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(60, 35);
            this.ButtonCancelar.TabIndex = 8;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.ButtonSalir);
            this.panel2.Controls.Add(this.ButtonAyuda);
            this.panel2.Controls.Add(this.LabelBorrarFoto);
            this.panel2.Controls.Add(this.ButtonEliminar);
            this.panel2.Controls.Add(this.ButtonCancelar);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.ButtonGrabar);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.PictureBoxFotoUsuario);
            this.panel2.Controls.Add(this.TextBoxTelefono);
            this.panel2.Controls.Add(this.TextBoxCorreo);
            this.panel2.Controls.Add(this.TextBoxApellidos);
            this.panel2.Controls.Add(this.TextBoxNombres);
            this.panel2.Controls.Add(this.TextBoxDocumento);
            this.panel2.Location = new System.Drawing.Point(410, 171);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(520, 304);
            this.panel2.TabIndex = 276;
            // 
            // LabelBorrarFoto
            // 
            this.LabelBorrarFoto.AutoSize = true;
            this.LabelBorrarFoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelBorrarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelBorrarFoto.Location = new System.Drawing.Point(410, 161);
            this.LabelBorrarFoto.Name = "LabelBorrarFoto";
            this.LabelBorrarFoto.Size = new System.Drawing.Size(72, 15);
            this.LabelBorrarFoto.TabIndex = 325;
            this.LabelBorrarFoto.Text = "Borrar Foto";
            this.LabelBorrarFoto.Click += new System.EventHandler(this.LabelBorrarFoto_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(114, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 285;
            this.label5.Text = "Telefono";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(115, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 284;
            this.label4.Text = "Correo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(114, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 283;
            this.label3.Text = "Apellidos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(114, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 282;
            this.label2.Text = "Nombres";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 281;
            this.label1.Text = "Documento";
            // 
            // PictureBoxFotoUsuario
            // 
            this.PictureBoxFotoUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBoxFotoUsuario.Location = new System.Drawing.Point(390, 17);
            this.PictureBoxFotoUsuario.Name = "PictureBoxFotoUsuario";
            this.PictureBoxFotoUsuario.Size = new System.Drawing.Size(116, 132);
            this.PictureBoxFotoUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBoxFotoUsuario.TabIndex = 280;
            this.PictureBoxFotoUsuario.TabStop = false;
            this.PictureBoxFotoUsuario.Click += new System.EventHandler(this.PictureBoxFotoUsuario_Click);
            // 
            // TextBoxTelefono
            // 
            this.TextBoxTelefono.Location = new System.Drawing.Point(211, 193);
            this.TextBoxTelefono.MaxLength = 10;
            this.TextBoxTelefono.Name = "TextBoxTelefono";
            this.TextBoxTelefono.Size = new System.Drawing.Size(72, 20);
            this.TextBoxTelefono.TabIndex = 4;
            this.TextBoxTelefono.TabStop = false;
            // 
            // TextBoxCorreo
            // 
            this.TextBoxCorreo.Location = new System.Drawing.Point(211, 161);
            this.TextBoxCorreo.MaxLength = 50;
            this.TextBoxCorreo.Name = "TextBoxCorreo";
            this.TextBoxCorreo.Size = new System.Drawing.Size(161, 20);
            this.TextBoxCorreo.TabIndex = 3;
            this.TextBoxCorreo.TabStop = false;
            // 
            // TextBoxApellidos
            // 
            this.TextBoxApellidos.Location = new System.Drawing.Point(211, 129);
            this.TextBoxApellidos.MaxLength = 25;
            this.TextBoxApellidos.Name = "TextBoxApellidos";
            this.TextBoxApellidos.Size = new System.Drawing.Size(161, 20);
            this.TextBoxApellidos.TabIndex = 2;
            this.TextBoxApellidos.TabStop = false;
            // 
            // TextBoxNombres
            // 
            this.TextBoxNombres.Location = new System.Drawing.Point(211, 97);
            this.TextBoxNombres.MaxLength = 25;
            this.TextBoxNombres.Name = "TextBoxNombres";
            this.TextBoxNombres.Size = new System.Drawing.Size(161, 20);
            this.TextBoxNombres.TabIndex = 1;
            this.TextBoxNombres.TabStop = false;
            // 
            // TextBoxDocumento
            // 
            this.TextBoxDocumento.Location = new System.Drawing.Point(211, 65);
            this.TextBoxDocumento.MaxLength = 10;
            this.TextBoxDocumento.Name = "TextBoxDocumento";
            this.TextBoxDocumento.Size = new System.Drawing.Size(72, 20);
            this.TextBoxDocumento.TabIndex = 0;
            this.TextBoxDocumento.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(410, 115);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(520, 60);
            this.panel3.TabIndex = 344;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Image = global::SIMI_Desktop.Properties.Resources.icoperarios;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(3, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 25);
            this.label6.TabIndex = 343;
            this.label6.Text = "      Operarios";
            // 
            // FormOperarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIMI_Desktop.Properties.Resources.Plantilla;
            this.ClientSize = new System.Drawing.Size(1126, 589);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormOperarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Operarios";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormOperarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFotoUsuario)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ButtonGrabar;
        private System.Windows.Forms.ErrorProvider errorPro;
        private System.Windows.Forms.Button ButtonEliminar;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonAyuda;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox PictureBoxFotoUsuario;
        private System.Windows.Forms.TextBox TextBoxTelefono;
        private System.Windows.Forms.TextBox TextBoxCorreo;
        private System.Windows.Forms.TextBox TextBoxApellidos;
        private System.Windows.Forms.TextBox TextBoxNombres;
        private System.Windows.Forms.TextBox TextBoxDocumento;
        private System.Windows.Forms.Label LabelBorrarFoto;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
    }
}

