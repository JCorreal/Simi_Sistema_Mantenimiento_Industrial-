﻿namespace SIMI_Desktop.Forms
{
    partial class FormListados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_Listado = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Titulo = new System.Windows.Forms.Label();
            this.textBox_Buscar = new System.Windows.Forms.TextBox();
            this.button_Buscar = new System.Windows.Forms.Button();
            this.button_Nuevo = new System.Windows.Forms.Button();
            this.label_Buscar = new System.Windows.Forms.Label();
            this.button_Menu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Listado)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView_Listado
            // 
            this.dataGridView_Listado.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Listado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Listado.Location = new System.Drawing.Point(326, 195);
            this.dataGridView_Listado.Name = "dataGridView_Listado";
            this.dataGridView_Listado.ReadOnly = true;
            this.dataGridView_Listado.Size = new System.Drawing.Size(649, 272);
            this.dataGridView_Listado.TabIndex = 0;
            this.dataGridView_Listado.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Listado_CellClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label_Titulo);
            this.panel1.Location = new System.Drawing.Point(326, 140);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(649, 60);
            this.panel1.TabIndex = 342;
            // 
            // label_Titulo
            // 
            this.label_Titulo.AutoSize = true;
            this.label_Titulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Titulo.ForeColor = System.Drawing.Color.White;
            this.label_Titulo.Location = new System.Drawing.Point(255, 21);
            this.label_Titulo.Name = "label_Titulo";
            this.label_Titulo.Size = new System.Drawing.Size(51, 20);
            this.label_Titulo.TabIndex = 0;
            this.label_Titulo.Text = "label1";
            // 
            // textBox_Buscar
            // 
            this.textBox_Buscar.Location = new System.Drawing.Point(679, 115);
            this.textBox_Buscar.Name = "textBox_Buscar";
            this.textBox_Buscar.Size = new System.Drawing.Size(166, 20);
            this.textBox_Buscar.TabIndex = 343;
            // 
            // button_Buscar
            // 
            this.button_Buscar.Image = global::SIMI_Desktop.Properties.Resources.Consulta;
            this.button_Buscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Buscar.Location = new System.Drawing.Point(598, 112);
            this.button_Buscar.Name = "button_Buscar";
            this.button_Buscar.Size = new System.Drawing.Size(75, 23);
            this.button_Buscar.TabIndex = 344;
            this.button_Buscar.Text = "Buscar";
            this.button_Buscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Buscar.UseVisualStyleBackColor = true;
            this.button_Buscar.Click += new System.EventHandler(this.button_Buscar_Click);
            // 
            // button_Nuevo
            // 
            this.button_Nuevo.Image = global::SIMI_Desktop.Properties.Resources.Nuevo;
            this.button_Nuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Nuevo.Location = new System.Drawing.Point(517, 111);
            this.button_Nuevo.Name = "button_Nuevo";
            this.button_Nuevo.Size = new System.Drawing.Size(75, 23);
            this.button_Nuevo.TabIndex = 345;
            this.button_Nuevo.Text = "Nuevo";
            this.button_Nuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Nuevo.UseVisualStyleBackColor = true;
            this.button_Nuevo.Click += new System.EventHandler(this.button_Nuevo_Click);
            // 
            // label_Buscar
            // 
            this.label_Buscar.AutoSize = true;
            this.label_Buscar.BackColor = System.Drawing.Color.Transparent;
            this.label_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Buscar.ForeColor = System.Drawing.Color.Teal;
            this.label_Buscar.Location = new System.Drawing.Point(676, 99);
            this.label_Buscar.Name = "label_Buscar";
            this.label_Buscar.Size = new System.Drawing.Size(169, 13);
            this.label_Buscar.TabIndex = 346;
            this.label_Buscar.Text = "Operario se busca por Documento";
            // 
            // button_Menu
            // 
            this.button_Menu.Image = global::SIMI_Desktop.Properties.Resources.casa;
            this.button_Menu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Menu.Location = new System.Drawing.Point(60, 72);
            this.button_Menu.Name = "button_Menu";
            this.button_Menu.Size = new System.Drawing.Size(103, 40);
            this.button_Menu.TabIndex = 347;
            this.button_Menu.Text = "Menú Principal";
            this.button_Menu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Menu.UseVisualStyleBackColor = true;
            this.button_Menu.Click += new System.EventHandler(this.button_Menu_Click);
            // 
            // FormListados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIMI_Desktop.Properties.Resources.Plantilla;
            this.ClientSize = new System.Drawing.Size(1097, 569);
            this.Controls.Add(this.button_Menu);
            this.Controls.Add(this.label_Buscar);
            this.Controls.Add(this.button_Nuevo);
            this.Controls.Add(this.button_Buscar);
            this.Controls.Add(this.textBox_Buscar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView_Listado);
            this.Name = "FormListados";
            this.Text = "FormListados";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Listado)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_Listado;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Titulo;
        private System.Windows.Forms.TextBox textBox_Buscar;
        private System.Windows.Forms.Button button_Buscar;
        private System.Windows.Forms.Button button_Nuevo;
        private System.Windows.Forms.Label label_Buscar;
        private System.Windows.Forms.Button button_Menu;
    }
}