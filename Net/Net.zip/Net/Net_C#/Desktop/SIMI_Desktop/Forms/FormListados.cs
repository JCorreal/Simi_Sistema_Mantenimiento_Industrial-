﻿using SIMI_Desktop.BLL;
using System;
using System.Collections;
using System.Windows.Forms;


namespace SIMI_Desktop.Forms
{
    public partial class FormListados : Form
    {
        string source = null;
        ArrayList arlListado = new ArrayList();
        string[] col_Operarios = { "OPERARIO_ID", "DOCUMENTO", "NOMBRE_COMPLETO", "CORREO", "TELEFONO" };
        string[] col_Equipos = { "EQUIPO_ID", "SERIE", "NOMBRE_EQUIPO", "MARCA","LINEA", "LUBRICACION" };
        string[] col_Mantenimiento = { "MANTENIMIENTO_ID", "SERIE", "NOMBRE_EQUIPO", "FECHA", "OPERARIO" };
        string[] col_Marcas = { "LISTAVALORES_ID", "NOMBRE", "DESCRIPCION", "TIPO" };

        public FormListados(string listar)
        {
            InitializeComponent();
            source = listar;
            traerDatos(listar);
        }

        private void traerDatos(string listar )
        {
            label_Titulo.Text = "Listado " + listar;
            switch (listar)
            {
                case "Operarios":
                    Controlador_Operario _controlador = Funciones.crearControlador_Operario();
                    arlListado = _controlador.cargarListado();
                    if (arlListado.Count > 0)
                    {
                        dataGridView_Listado.DataSource = arlListado;
                        ponerEncabezados(col_Operarios);
                        this.dataGridView_Listado.Columns[0].Visible = false;
                        this.dataGridView_Listado.Columns[5].Visible = false;
                    }
                    break;
                case "Equipos":
                    label_Buscar.Text = "Equipo se busca por Serie";
                    Controlador_Equipo _controladore = Funciones.crearControlador_Equipo();
                    arlListado = _controladore.cargarListado();
                    if (arlListado.Count > 0)
                    {
                        dataGridView_Listado.DataSource = arlListado;
                        ponerEncabezados(col_Equipos);
                        this.dataGridView_Listado.Columns[0].Visible = false;                      
                    }
                    break;
                case "Mantenimiento":
                    label_Buscar.Text = "Mantenimiento se busca por Serie de Equipo";
                    Controlador_Mantenimiento _controladormt = Funciones.crearControlador_Mantenimiento();
                    arlListado = _controladormt.cargarListado();
                    if (arlListado.Count >0)
                    {
                        dataGridView_Listado.DataSource = arlListado;
                        ponerEncabezados(col_Mantenimiento);
                        this.dataGridView_Listado.Columns[0].Visible = false;
                        this.dataGridView_Listado.Columns[5].Visible = false;
                    }
                    break;
                case "Marcas":
                    label_Buscar.Text = "Marca se busca por su Nombre";
                    Controlador_ListaValores _controladorlm = Funciones.crearControlador_ListaValores();
                    arlListado = _controladorlm.cargarListado("MARCAS" );
                    if (arlListado.Count > 0)
                    {
                        dataGridView_Listado.DataSource = arlListado;
                        ponerEncabezados(col_Marcas);
                        this.dataGridView_Listado.Columns[0].Visible = false;
                        this.dataGridView_Listado.Columns[4].Visible = false;
                        this.dataGridView_Listado.Columns[5].Visible = false;
                    }
                    break;
                default:
                    label_Buscar.Text = "Linea se busca por su Nombre";
                    Controlador_ListaValores _controladorll = Funciones.crearControlador_ListaValores();
                    arlListado = _controladorll.cargarListado("LINEAS" );
                    if (arlListado.Count > 0)
                    {
                        dataGridView_Listado.DataSource = arlListado;
                        ponerEncabezados(col_Marcas);
                        this.dataGridView_Listado.Columns[0].Visible = false;
                        this.dataGridView_Listado.Columns[4].Visible = false;
                        this.dataGridView_Listado.Columns[5].Visible = false;
                    }
                    break;
            }
        }

        private void ponerEncabezados(string[] encabezado)
        {
            for (int i = 0; i < encabezado.Length; i++)
            {
                dataGridView_Listado.Columns[i].HeaderText = encabezado[i];
            }
        }
               
        private void dataGridView_Listado_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Funciones.ParametroBuscar = Convert.ToInt32(dataGridView_Listado.Rows[e.RowIndex].Cells[0].Value.ToString());
            if (Funciones.ParametroBuscar != 0)
            {
                LlamarFormulario();                
            }
        }

        private void button_Buscar_Click(object sender, EventArgs e)
        {
            int v_Renglon = 0;
            string cadena = textBox_Buscar.Text.Trim();
            if (!"".Equals(cadena))
            {
                if (!source.Equals("Operarios"))
                {
                    cadena = cadena.ToUpper();
                }
                foreach (DataGridViewRow Row in dataGridView_Listado.Rows)             
                {                    
                    if (Convert.ToString(Row.Cells[1].Value) == cadena)
                    {
                        v_Renglon = Row.Index;
                        Row.Selected = true;
                        break;
                    }
                }
            }
        }

        private void button_Nuevo_Click(object sender, EventArgs e)
        {
            Funciones.ParametroBuscar = 0;
            LlamarFormulario();
        }

        private void LlamarFormulario()
		{
            this.Close();
            this.Dispose();
            switch (source)
            {
                case "Operarios":
                    {                        
                        FormOperarios Form_Operarios = new FormOperarios();
                        Form_Operarios.ShowDialog();
                        break;
                    }
                case "Equipos":
                    {
                        Controlador_Equipo _controladore = Funciones.crearControlador_Equipo();
                        _controladore.CargarDatosCombos("CONTROLEQUIPOS");
                        if (Funciones.Lista1 == null)
                        {
                            MessageBox.Show(Mensajes.Mensaje12, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Funciones.Lista1 = null;
                            Funciones.Lista2 = null;
                        }
                        else if (Funciones.Lista2 == null)
                        {
                            MessageBox.Show(Mensajes.Mensaje11, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Funciones.Lista1 = null;
                            Funciones.Lista2 = null;
                        }
                        else
                        {
                            FormEquipos Form_Equipos = new FormEquipos();
                            Form_Equipos.ShowDialog();
                        }                         
                        break;
                    }
                case "Mantenimiento":
                    {
                        Controlador_Mantenimiento _controladormt = Funciones.crearControlador_Mantenimiento();
                        if (Funciones.ParametroBuscar == 0)
                        {
                            _controladormt.CargarDatosCombos("PROGRAMAR");
                            if (Funciones.Lista1 == null)
                            {
                                MessageBox.Show(Mensajes.Mensaje12, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                Funciones.Lista1 = null;
                                Funciones.Lista2 = null;
                            }
                            else if (Funciones.Lista2 == null)
                            {
                                MessageBox.Show(Mensajes.Mensaje11, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                Funciones.Lista1 = null;
                                Funciones.Lista2 = null;
                            }
                            else
                            {
                                FormMantenimiento Form_Mantenimiento = new FormMantenimiento();
                                Form_Mantenimiento.ShowDialog();
                            }
                        }
                        else
                        {
                            _controladormt.CargarDatosCombos("PROGRAMACION");
                            FormMantenimiento Form_Mantenimiento = new FormMantenimiento();
                            Form_Mantenimiento.ShowDialog();
                        }                      
                        break;
                    }
                case "Marcas":
                    {
                        Funciones.ValorTipo = "MARCAS";                      
                        FormListaValores Form_ListaValores = new FormListaValores();
                        Form_ListaValores.ShowDialog();
                        break;
                    }
                default:
                    {
                        Funciones.ValorTipo = "LINEAS";                       
                        FormListaValores Form_ListaValores = new FormListaValores();
                        Form_ListaValores.ShowDialog();
                        break;
                    }
            }
		}
		
        private void button_Menu_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();            
        }
    }
}
