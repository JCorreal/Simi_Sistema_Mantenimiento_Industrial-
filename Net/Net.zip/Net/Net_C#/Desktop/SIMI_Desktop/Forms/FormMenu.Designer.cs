﻿namespace SIMI_Desktop.Forms
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Operarios = new System.Windows.Forms.Button();
            this.button_Equipos = new System.Windows.Forms.Button();
            this.button_Marcas = new System.Windows.Forms.Button();
            this.button_Lineas = new System.Windows.Forms.Button();
            this.button_Mantenimiento = new System.Windows.Forms.Button();
            this.button_Clave = new System.Windows.Forms.Button();
            this.lblUsuarioConectado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_Operarios
            // 
            this.button_Operarios.Image = global::SIMI_Desktop.Properties.Resources.icoperarios;
            this.button_Operarios.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Operarios.Location = new System.Drawing.Point(58, 275);
            this.button_Operarios.Name = "button_Operarios";
            this.button_Operarios.Size = new System.Drawing.Size(113, 36);
            this.button_Operarios.TabIndex = 0;
            this.button_Operarios.Text = "Operarios";
            this.button_Operarios.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Operarios.UseVisualStyleBackColor = true;
            this.button_Operarios.Click += new System.EventHandler(this.button_Operarios_Click);
            // 
            // button_Equipos
            // 
            this.button_Equipos.Enabled = false;
            this.button_Equipos.Image = global::SIMI_Desktop.Properties.Resources.icoequipos;
            this.button_Equipos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Equipos.Location = new System.Drawing.Point(58, 315);
            this.button_Equipos.Name = "button_Equipos";
            this.button_Equipos.Size = new System.Drawing.Size(113, 36);
            this.button_Equipos.TabIndex = 1;
            this.button_Equipos.Text = "Equipos";
            this.button_Equipos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Equipos.UseVisualStyleBackColor = true;
            this.button_Equipos.Click += new System.EventHandler(this.button_Equipos_Click);
            // 
            // button_Marcas
            // 
            this.button_Marcas.Enabled = false;
            this.button_Marcas.Image = global::SIMI_Desktop.Properties.Resources.icomarca;
            this.button_Marcas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Marcas.Location = new System.Drawing.Point(58, 355);
            this.button_Marcas.Name = "button_Marcas";
            this.button_Marcas.Size = new System.Drawing.Size(113, 36);
            this.button_Marcas.TabIndex = 2;
            this.button_Marcas.Text = "Marcas";
            this.button_Marcas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Marcas.UseVisualStyleBackColor = true;
            this.button_Marcas.Click += new System.EventHandler(this.button_Marcas_Click);
            // 
            // button_Lineas
            // 
            this.button_Lineas.Enabled = false;
            this.button_Lineas.Image = global::SIMI_Desktop.Properties.Resources.icolineas;
            this.button_Lineas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Lineas.Location = new System.Drawing.Point(58, 395);
            this.button_Lineas.Name = "button_Lineas";
            this.button_Lineas.Size = new System.Drawing.Size(113, 36);
            this.button_Lineas.TabIndex = 3;
            this.button_Lineas.Text = "Lineas";
            this.button_Lineas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Lineas.UseVisualStyleBackColor = true;
            this.button_Lineas.Click += new System.EventHandler(this.button_Lineas_Click);
            // 
            // button_Mantenimiento
            // 
            this.button_Mantenimiento.Enabled = false;
            this.button_Mantenimiento.Image = global::SIMI_Desktop.Properties.Resources.icotiempo;
            this.button_Mantenimiento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Mantenimiento.Location = new System.Drawing.Point(58, 435);
            this.button_Mantenimiento.Name = "button_Mantenimiento";
            this.button_Mantenimiento.Size = new System.Drawing.Size(113, 36);
            this.button_Mantenimiento.TabIndex = 4;
            this.button_Mantenimiento.Text = "Mantenimiento";
            this.button_Mantenimiento.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Mantenimiento.UseVisualStyleBackColor = true;
            this.button_Mantenimiento.Click += new System.EventHandler(this.button_Mantenimiento_Click);
            // 
            // button_Clave
            // 
            this.button_Clave.Image = global::SIMI_Desktop.Properties.Resources.icoclave;
            this.button_Clave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Clave.Location = new System.Drawing.Point(58, 475);
            this.button_Clave.Name = "button_Clave";
            this.button_Clave.Size = new System.Drawing.Size(113, 36);
            this.button_Clave.TabIndex = 5;
            this.button_Clave.Text = "Cambio Clave";
            this.button_Clave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Clave.UseVisualStyleBackColor = true;
            this.button_Clave.Click += new System.EventHandler(this.button_Clave_Click);
            // 
            // lblUsuarioConectado
            // 
            this.lblUsuarioConectado.AutoSize = true;
            this.lblUsuarioConectado.BackColor = System.Drawing.Color.Transparent;
            this.lblUsuarioConectado.ForeColor = System.Drawing.Color.White;
            this.lblUsuarioConectado.Location = new System.Drawing.Point(0, -1);
            this.lblUsuarioConectado.Name = "lblUsuarioConectado";
            this.lblUsuarioConectado.Size = new System.Drawing.Size(66, 13);
            this.lblUsuarioConectado.TabIndex = 6;
            this.lblUsuarioConectado.Text = "Bienvenido: ";
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIMI_Desktop.Properties.Resources.Plantilla_Menu;
            this.ClientSize = new System.Drawing.Size(1097, 595);
            this.Controls.Add(this.lblUsuarioConectado);
            this.Controls.Add(this.button_Clave);
            this.Controls.Add(this.button_Mantenimiento);
            this.Controls.Add(this.button_Lineas);
            this.Controls.Add(this.button_Marcas);
            this.Controls.Add(this.button_Equipos);
            this.Controls.Add(this.button_Operarios);
            this.Name = "FormMenu";
            this.Text = "SIMI";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Operarios;
        private System.Windows.Forms.Button button_Equipos;
        private System.Windows.Forms.Button button_Marcas;
        private System.Windows.Forms.Button button_Lineas;
        private System.Windows.Forms.Button button_Mantenimiento;
        private System.Windows.Forms.Button button_Clave;
        private System.Windows.Forms.Label lblUsuarioConectado;
    }
}