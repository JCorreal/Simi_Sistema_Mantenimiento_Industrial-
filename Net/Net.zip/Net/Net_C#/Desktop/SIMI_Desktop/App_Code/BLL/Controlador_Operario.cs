using SIMI_Desktop.BO;
using SIMI_Desktop.DAL;
using System.Collections;

namespace SIMI_Desktop.BLL
{
    public class Controlador_Operario
    {
        private readonly IDao_Operario _dao_operario;

        public Controlador_Operario(IDao_Operario dao_operario)
        {
            _dao_operario = dao_operario;
        }

        public ArrayList cargarListado()
        {
            return _dao_operario.cargarListado();
        }

        public Operario obtenerAcceso(string documento, int clave)
        {
            Operario operario = null;
            operario = _dao_operario.obtenerAcceso(documento, clave);
            return operario;
        }

        public Operario obtenerOperario(int datoBuscar)
        {
            Operario operario = new Operario();
            operario = _dao_operario.obtenerOperario(datoBuscar);
            return operario;
        }

        public int guardarOperario(Operario operario)
        {
            return _dao_operario.guardarOperario(operario, Funciones.UsuarioConectado);
        }

        public int guardarCambioClave(int claveAnterior, int claveNueva)
        {
            return _dao_operario.guardarCambioClave(Funciones.UsuarioConectado, claveAnterior, claveNueva);
        }

        public int eliminarRegistro(int datoEliminar)
        {
            return _dao_operario.eliminarRegistro(datoEliminar);
        }
    }
}