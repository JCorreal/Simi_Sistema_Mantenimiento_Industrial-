﻿Option Strict On

Public Class ListaValores ' Clase que respresenta la estructura ListaValores en BD

    Public Sub New()

    End Sub

    Public Property Listavalores_id() As Integer

    Public Property Nombre() As String

    Public Property Descripcion() As String

    Public Property Tipo() As String

End Class
