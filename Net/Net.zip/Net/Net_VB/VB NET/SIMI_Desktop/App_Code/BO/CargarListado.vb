﻿' Clase que nos permite cargar listados de información para visualizar en DataGridView
Option Strict On

Public Class CargarListado
    Public Property Columna1() As String
    Public Property Columna2() As String
    Public Property Columna3() As String
    Public Property Columna4() As String
    Public Property Columna5() As String

    Public Property Columna6() As String

    Public Sub New()

    End Sub

    Public Sub New(ByVal Columna1 As String, ByVal Columna2 As String, ByVal Columna3 As String, ByVal Columna4 As String, ByVal Columna5 As String, ByVal Columna6 As String)
        Me.Columna1 = Columna1
        Me.Columna2 = Columna2
        Me.Columna3 = Columna3
        Me.Columna4 = Columna4
        Me.Columna5 = Columna5
        Me.Columna6 = Columna6
    End Sub

End Class
