﻿Option Strict On

Imports System.Data.SqlClient

Public Class Dao_Operario
    Inherits Dao_General : Implements IDao_Operario

    Public Sub New()

    End Sub

    Public Function obtenerAcceso(ByVal documento As String, ByVal clave As Integer) As Operario Implements IDao_Operario.obtenerAcceso
        Dim _Operario As New Operario
        Try
            Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
            Cmd = New SqlCommand("SPR_R_obtenerAcceso", Cn)
            Cmd.CommandType = CommandType.StoredProcedure
            Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = documento
            Cmd.Parameters.Add("p_CLAVE", SqlDbType.Int, 6).Value = clave
            Cn.Open()
            sdr = Cmd.ExecuteReader()
            If (sdr.Read()) Then
                _Operario.Operario_id = Convert.ToInt32(sdr("OPERARIO_ID").ToString())
                _Operario.Nombres = sdr("NOMBRES").ToString()
                _Operario.Apellidos = sdr("APELLIDOS").ToString()
                _Operario.Perfil = Convert.ToInt32(sdr("PERFIL").ToString())
            Else
                _Operario = Nothing
            End If
            liberarRecursos()
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return _Operario
    End Function


    Public Function guardarOperario(_Operario As Operario, Usuario As Integer) As Integer Implements IDao_Operario.guardarOperario
        guardarOperario = -1
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_Operarios", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 4).Value = _Operario.Operario_id
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = _Operario.Documento
                Cmd.Parameters.Add("p_NOMBRES", SqlDbType.VarChar, 25).Value = _Operario.Nombres
                Cmd.Parameters.Add("p_APELLIDOS", SqlDbType.VarChar, 25).Value = _Operario.Apellidos
                Cmd.Parameters.Add("p_CORREO", SqlDbType.VarChar, 50).Value = _Operario.Correo
                Cmd.Parameters.Add("p_TELEFONO", SqlDbType.VarChar, 10).Value = _Operario.Telefono
                Cmd.Parameters.Add("p_FOTO", SqlDbType.VarChar, 50).Value = _Operario.Foto
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.Int, 4).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                guardarOperario = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                liberarRecursos()
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return guardarOperario
    End Function

    Public Function guardarCambioClave(Usuario As Integer, claveAnterior As Integer, claveNueva As Integer) As Integer Implements IDao_Operario.guardarCambioClave
        guardarCambioClave = -1
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_U_CambioClave", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.VarChar, 10).Value = Usuario
                Cmd.Parameters.Add("p_CLAVE_ANTERIOR", SqlDbType.Int, 6).Value = claveAnterior
                Cmd.Parameters.Add("p_CLAVE_NUEVA", SqlDbType.Int, 6).Value = claveNueva
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                guardarCambioClave = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                liberarRecursos()
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return guardarCambioClave
    End Function

    Public Function cargarListado() As ArrayList Implements IDao_Operario.cargarListado
        Dim arlListado As New ArrayList()
        arlListado = cargarListadodg("TBL_OPERARIOS")
        Return arlListado
    End Function

    Public Function eliminarRegistro(datoEliminar As Integer) As Integer Implements IDao_Operario.eliminarRegistro
        eliminarRegistro = -1
        eliminarRegistro = borrarRegistro(datoEliminar, "TBL_OPERARIOS")
        Return eliminarRegistro
    End Function

    Public Function obtenerOperario(datoBuscar As Integer) As Operario Implements IDao_Operario.obtenerOperario
        Dim _Operario As New Operario
        Try
            buscarRegistro("TBL_OPERARIOS", datoBuscar)
            If (sdr.Read()) Then
                _Operario.Operario_id = Convert.ToInt32(sdr("OPERARIO_ID").ToString())
                _Operario.Documento = sdr("DOCUMENTO").ToString()
                _Operario.Nombres = sdr("NOMBRES").ToString()
                _Operario.Apellidos = sdr("APELLIDOS").ToString()
                _Operario.Correo = sdr("CORREO").ToString()
                _Operario.Telefono = sdr("TELEFONO").ToString()
                _Operario.Foto = sdr("FOTO").ToString()
            Else
                _Operario = Nothing
            End If
            sdr.Close()
            liberarRecursos()
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return _Operario
    End Function
End Class
