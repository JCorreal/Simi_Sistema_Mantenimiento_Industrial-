﻿Option Strict On

Imports System.Data.SqlClient

Public Class Dao_ListaValores
    Inherits Dao_General : Implements IDao_ListaValores

    Public Sub New()

    End Sub

    Public Function obtenerListaValores(datoBuscar As Integer) As ListaValores Implements IDao_ListaValores.obtenerListaValores
        Dim _ListaValores As New ListaValores
        Try
            buscarRegistro("TBL_LISTAVALORES", datoBuscar)
            If (sdr.Read()) Then
                _ListaValores.Listavalores_id = Convert.ToInt32(sdr("LISTAVALORES_ID").ToString())
                _ListaValores.Nombre = sdr("NOMBRE").ToString()
                _ListaValores.Descripcion = sdr("DESCRIPCION").ToString()
            Else
                _ListaValores = Nothing
            End If
            sdr.Close()
            liberarRecursos()
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return _ListaValores
    End Function

    Public Function guardarListaValores(_ListaValores As ListaValores, Usuario As Integer) As Integer Implements IDao_ListaValores.guardarListaValores
        guardarListaValores = -1
        Try
            Using Cn = New SqlConnection(Conexion.obtenerConexion().ToString)
                Cmd = New SqlCommand("SPR_IU_ListaValores", Cn)
                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.Parameters.Add("p_LISTAVALORES_ID", SqlDbType.Int, 4).Value = _ListaValores.Listavalores_id
                Cmd.Parameters.Add("p_NOMBRE", SqlDbType.VarChar, 50).Value = _ListaValores.Nombre
                Cmd.Parameters.Add("p_DESCRIPCION", SqlDbType.VarChar, 255).Value = _ListaValores.Descripcion
                Cmd.Parameters.Add("p_TIPO", SqlDbType.VarChar, 50).Value = _ListaValores.Tipo
                Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.Int,4).Value = Usuario
                Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output
                Cn.Open()
                Cmd.ExecuteNonQuery()
                guardarListaValores = Convert.ToInt32(Cmd.Parameters("p_RESULTADO").Value)
                liberarRecursos()
            End Using
        Catch
            liberarRecursos()
        Finally
            liberarRecursos()
        End Try
        Return guardarListaValores

    End Function

    Public Function cargarListado(ByVal tabla As String) As ArrayList Implements IDao_ListaValores.cargarListado
        Dim arlLista As New ArrayList()
        arlLista = cargarListadodg(tabla)
        Return arlLista
    End Function

    Public Function eliminarRegistro(datoEliminar As Integer) As Integer Implements IDao_ListaValores.eliminarRegistro
        eliminarRegistro = -1
        eliminarRegistro = borrarRegistro(datoEliminar, "TBL_LISTAVALORES")
        Return eliminarRegistro
    End Function
End Class
