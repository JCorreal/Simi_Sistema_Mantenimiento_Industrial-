﻿Option Strict On
Imports System.IO

Public Class FormOperarios
    Private _controlador As Controlador_Operario = Funciones.crearControlador_Operario()
    Private grabar As Boolean
    Private rutaFoto As String = ""
    Private _Operario As Operario
    Private tecla As New KeyPressEventArgs(ChrW(Keys.Enter))

    Private Sub FormOperarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim blankContextMenu As New ContextMenuStrip()
        TextBoxDocumento.ContextMenuStrip = blankContextMenu  'Deshabilitar la opcion de pegado
        TextBoxNombres.ContextMenuStrip = blankContextMenu
        TextBoxApellidos.ContextMenuStrip = blankContextMenu
        TextBoxTelefono.ContextMenuStrip = blankContextMenu
        If (Funciones.ParametroBuscar <> 0) Then
            consultarBD()
        End If
    End Sub

    Private Sub consultarBD()
        _Operario = CType(_controlador.obtenerOperario(Funciones.ParametroBuscar), Operario)
        If (Not _Operario Is Nothing) Then
            poblarFormulario()
        End If
    End Sub

    Private Sub poblarFormulario()
        Dim aPath As String = Application.StartupPath
        Dim posicion As Integer = aPath.IndexOf("bin")
        Dim sDestino As String = Mid(aPath, 1, posicion) & "Fotos_Operarios\"
        If (Funciones.PerfilAcceso = 1) Then
            ButtonEliminar.Enabled = True
        End If
        TextBoxDocumento.Text = _Operario.Documento
        TextBoxDocumento.Enabled = False
        TextBoxNombres.Text = _Operario.Nombres
        TextBoxApellidos.Text = _Operario.Apellidos
        TextBoxCorreo.Text = _Operario.Correo
        TextBoxTelefono.Text = _Operario.Telefono.ToString()
        If Not String.IsNullOrEmpty(_Operario.Foto) Then
            Try
                PictureBoxFotoUsuario.Image = Image.FromFile(sDestino & _Operario.Foto)
            Catch ex As Exception
                MessageBox.Show(Mensajes.Mensaje24, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
        TextBoxNombres.Focus()
    End Sub
    Private Sub TextBoxDocumento_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxDocumento.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxDocumento.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.MensajeCampoRequerido)
                ElseIf (TextBoxDocumento.Text.Length < 6) Then
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje15, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje15)
                ElseIf (TextBoxDocumento.Text.Substring(0, 1) = "0") Then
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxDocumento.Focus()
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje6)
                Else
                    errorPro.Clear()
                    TextBoxNombres.Focus()
                End If
            Else
                If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                    e.Handled = True 'Establece el caracter a null si está fuera del intervalo
                End If
            End If
        End If

    End Sub

    Private Sub TextBoxNombres_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxNombres.KeyPress
        If (e.KeyChar <> ChrW(Keys.Back) And e.KeyChar <> ChrW(Keys.Space)) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxNombres.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxNombres.Focus()
                    errorPro.SetError(TextBoxNombres, Mensajes.MensajeCampoRequerido)
                Else
                    TextBoxNombres.Text = Funciones.eliminarTabulador(TextBoxNombres.Text, "1MAY")
                    errorPro.Clear()
                    TextBoxApellidos.Focus()
                End If
            Else
                If (Convert.ToInt32(e.KeyChar) < 65) Or (Convert.ToInt32(e.KeyChar) > 90) And (Convert.ToInt32(e.KeyChar) < 97) Or (Convert.ToInt32(e.KeyChar) > 122) Then
                    e.Handled = True
                End If
            End If
        End If
    End Sub

    Private Sub TextBoxApellidos_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxApellidos.KeyPress
        If (e.KeyChar <> ChrW(Keys.Back) And e.KeyChar <> ChrW(Keys.Space)) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxApellidos.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxApellidos.Focus()
                    errorPro.SetError(TextBoxApellidos, Mensajes.MensajeCampoRequerido)
                Else
                    TextBoxApellidos.Text = Funciones.eliminarTabulador(TextBoxApellidos.Text, "1MAY")
                    errorPro.Clear()
                    TextBoxCorreo.Focus()
                End If
            Else
                If (Convert.ToInt32(e.KeyChar) < 65) Or (Convert.ToInt32(e.KeyChar) > 90) And (Convert.ToInt32(e.KeyChar) < 97) Or (Convert.ToInt32(e.KeyChar) > 122) Then
                    e.Handled = True
                End If
            End If
        End If
    End Sub
    Private Sub TextBoxCorreo_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxCorreo.KeyPress
        If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
            If (TextBoxCorreo.Text.Length <> 0) Then
                If (Funciones.validar_Correo(TextBoxCorreo.Text)) Then
                    errorPro.Clear()
                    TextBoxTelefono.Focus()
                Else
                    grabar = False
                    MessageBox.Show(Mensajes.Mensaje16, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxCorreo.Focus()
                    errorPro.SetError(TextBoxCorreo, Mensajes.Mensaje16)
                End If
            Else
                TextBoxTelefono.Focus()
            End If
        End If
    End Sub

    Private Sub TextBoxTelefono_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBoxTelefono.KeyPress
        If e.KeyChar <> ChrW(Keys.Back) Then
            If (e.KeyChar = ChrW(Keys.Enter) Or e.KeyChar = ChrW(Keys.Tab)) Then
                If (Funciones.validar_CampoVacio(TextBoxTelefono.Text)) Then
                    grabar = False
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBoxTelefono.Focus()
                    errorPro.SetError(TextBoxTelefono, Mensajes.MensajeCampoRequerido)
                Else
                    If ((TextBoxTelefono.Text.Length <> 7) And (TextBoxTelefono.Text.Length <> 10)) Then
                        grabar = False
                        MessageBox.Show(Mensajes.Mensaje17, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        TextBoxTelefono.Focus()
                        errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje17)
                    ElseIf (TextBoxTelefono.Text.Substring(0, 1) = "0") Then
                        grabar = False
                        MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        TextBoxTelefono.Focus()
                        errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje6)
                    Else
                        errorPro.Clear()
                        ButtonGrabar.Focus()
                    End If
                End If
            Else
                If (e.KeyChar < "0" Or e.KeyChar > "9") Then
                    e.Handled = True 'Establece el caracter a null si está fuera del intervalo
                End If
            End If
        End If
    End Sub

    Private Sub ButtonGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGrabar.Click
        grabar = True
        TextBoxDocumento_KeyPress(ButtonGrabar, tecla)
        If (grabar) Then
            TextBoxNombres_KeyPress(ButtonGrabar, tecla)
            If (grabar) Then
                TextBoxApellidos_KeyPress(ButtonGrabar, tecla)
                If (grabar) Then
                    TextBoxCorreo_KeyPress(ButtonGrabar, tecla)
                    If (grabar) Then
                        TextBoxTelefono_KeyPress(ButtonGrabar, tecla)
                        If (grabar) Then
                            Guardar()
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub Guardar()
        Dim Resultado As Integer
        _Operario = New Operario()
        _Operario.Operario_id = Funciones.ParametroBuscar
        _Operario.Documento = TextBoxDocumento.Text
        _Operario.Nombres = TextBoxNombres.Text.Trim
        _Operario.Apellidos = TextBoxApellidos.Text.Trim
        _Operario.Telefono = TextBoxTelefono.Text.Trim
        _Operario.Correo = TextBoxCorreo.Text.ToLower().Trim
        _Operario.Foto = rutaFoto
        Resultado = _controlador.guardarOperario(_Operario)
        If (Resultado = 0) Then
            If (_Operario.Operario_id = 0) Then
                MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Limpiar()
            Else
                MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ButtonSalir.PerformClick()
            End If

        ElseIf (Resultado = 1) Then
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.Mensaje26, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Limpiar()
        If (Funciones.ParametroBuscar = 0) Then
            For Each oControls As Control In panel2.Controls
                If (TypeOf oControls Is TextBox) Then
                    oControls.Text = String.Empty
                    Continue For
                End If
            Next
            errorPro.Clear()
            PictureBoxFotoUsuario.Image = Nothing
            rutaFoto = ""
            TextBoxNombres.Focus()
        Else
            poblarFormulario()
        End If
    End Sub

    Private Sub ButtonCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancelar.Click
        Limpiar()
    End Sub

    Private Sub PictureBoxFotoUsuario_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBoxFotoUsuario.Click
        Dim aPath As String = Application.StartupPath
        Dim posicion As Integer = aPath.IndexOf("bin")
        Dim sDestino As String = Mid(aPath, 1, posicion) & "Fotos_Operarios\"
        Dim oFD As New OpenFileDialog
        oFD.Title = "Seleccionar imagen"
        oFD.Filter = "Imagenes|*.jpg;*.gif;*.png;*.bmp|Todos (*.*)|*.*"
        If (oFD.ShowDialog() = DialogResult.OK) Then
            rutaFoto = oFD.FileName
            Dim peso As New System.IO.FileInfo(oFD.FileName)
            If (Funciones.validar_CampoVacio(TextBoxDocumento.Text)) Then
                MessageBox.Show(Mensajes.Mensaje29, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf (peso.Length > 133000) Then 'Imagen de 3x4 no debería superar este peso 
                MessageBox.Show(Mensajes.Mensaje30, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                PictureBoxFotoUsuario.Image = Image.FromFile(oFD.FileName)
                sDestino = sDestino & TextBoxDocumento.Text & Path.GetExtension(oFD.FileName)
            End If
            My.Computer.FileSystem.CopyFile(rutaFoto, sDestino)
            rutaFoto = TextBoxDocumento.Text & Path.GetExtension(oFD.FileName)
        End If
    End Sub

    Private Sub lblBorrarFoto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblBorrarFoto.Click
        PictureBoxFotoUsuario.Image = Nothing
        rutaFoto = ""
    End Sub

    Private Sub ButtonEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonEliminar.Click
        Dim Resultado As Integer
        If (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK) Then
            Resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar)
            If (Resultado = 0) Then
                ButtonSalir.PerformClick()
                MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf (Resultado = 1) Then
                MessageBox.Show(Mensajes.Mensaje20, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub ButtonSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSalir.Click
        _controlador = Nothing
        _Operario = Nothing
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub ButtonAyuda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonAyuda.Click
        Funciones.MostrarAyuda()
    End Sub
End Class
