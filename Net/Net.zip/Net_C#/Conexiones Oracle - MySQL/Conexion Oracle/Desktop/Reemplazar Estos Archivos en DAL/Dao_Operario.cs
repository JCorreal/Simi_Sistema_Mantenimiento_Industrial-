﻿// DAL: Data Access Layer - Capa Acceso Datos Operarios
using System;
using Oracle.DataAccess.Client;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Dao_Operario : Dao_General, IDao_Operario
    {
        // Default Constructor
        public Dao_Operario() { }

        public Operario obtenerAcceso(string documento, int clave)
        {
            Operario operario = new Operario();
            try
            {
                Cn = new OracleConnection(Conexion.obtenerConexion);
                Cmd = new OracleCommand("SPR_R_obtenerAcceso", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_DOCUMENTO", OracleDbType.Varchar2, 10).Value = documento;
                Cmd.Parameters.Add("p_CLAVE", OracleDbType.Int32, 6).Value = clave;
                Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
                if (sdr.Read())
                {
                    operario.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Perfil = Convert.ToInt32(sdr["PERFIL"].ToString());
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return operario;
        }

        public Operario obtenerOperario(int datoBuscar)
        {
            Operario operario = new Operario();
            try
            {
                buscarRegistro("TBL_OPERARIOS", datoBuscar);
                if (sdr.Read())
                {
                    operario.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    operario.Documento = sdr["DOCUMENTO"].ToString();
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Correo = sdr["CORREO"].ToString();
                    operario.Telefono = sdr["TELEFONO"].ToString();
                    operario.Foto = sdr["FOTO"].ToString();
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return operario;
        }

        public int guardarOperario(Operario operario, int Usuario)
        {
            Int32 resultado = -1;
            try
            {
                using (Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("SPR_IU_Operarios", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_OPERARIO_ID", OracleDbType.Int32, 4).Value = operario.Operario_id;
                    Cmd.Parameters.Add("p_DOCUMENTO", OracleDbType.Varchar2, 10).Value = operario.Documento;
                    Cmd.Parameters.Add("p_NOMBRES", OracleDbType.Varchar2, 25).Value = operario.Nombres;
                    Cmd.Parameters.Add("p_APELLIDOS", OracleDbType.Varchar2, 25).Value = operario.Apellidos;
                    Cmd.Parameters.Add("p_CORREO", OracleDbType.Varchar2, 50).Value = operario.Correo;
                    Cmd.Parameters.Add("p_TELEFONO", OracleDbType.Varchar2, 10).Value = operario.Telefono;
                    Cmd.Parameters.Add("p_FOTO", OracleDbType.Varchar2, 50).Value = operario.Foto;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", OracleDbType.Varchar2, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                     resultado = (Int32)(Oracle.DataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;

        }

        public int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva)
        {
            Int32 resultado = -1;
            try
            {
                using (Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("SPR_U_CambioClave", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_OPERARIO_ID", OracleDbType.Varchar2, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_CLAVE_ANTERIOR", OracleDbType.Int32, 6).Value = claveAnterior;
                    Cmd.Parameters.Add("p_CLAVE_NUEVA", OracleDbType.Int32, 6).Value = claveNueva;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = (Int32)(Oracle.DataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
				}
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public ArrayList cargarListado()
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas("TBL_OPERARIOS");
            return arlLista;

        }

        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_OPERARIOS");
            return resultado;
        }


    }
}
