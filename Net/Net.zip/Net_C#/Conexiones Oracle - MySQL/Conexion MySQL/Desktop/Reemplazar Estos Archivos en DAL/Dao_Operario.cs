﻿// DAL: Data Access Layer - Capa Acceso Datos Operarios
using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Dao_Operario : Dao_General, IDao_Operario
    {
        // Default Constructor
        public Dao_Operario() { }

        public Operario obtenerAcceso(string documento, int clave)
        {
            Operario operario = new Operario();
            try
            {
                Cn = new MySqlConnection(Conexion.obtenerConexion);
                Cmd = new MySqlCommand("SPR_R_obtenerAcceso", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_DOCUMENTO", MySqlDbType.VarChar, 10).Value = documento;
                Cmd.Parameters.Add("p_CLAVE", MySqlDbType.Int32, 6).Value = clave;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
                if (sdr.Read())
                {
                    operario.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Perfil = Convert.ToInt32(sdr["PERFIL"].ToString());
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return operario;
        }

        public Operario obtenerOperario(int datoBuscar)
        {
            Operario operario = new Operario();
            try
            {
                buscarRegistro("TBL_OPERARIOS", datoBuscar);
                if (sdr.Read())
                {
                    operario.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    operario.Documento = sdr["DOCUMENTO"].ToString();
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Correo = sdr["CORREO"].ToString();
                    operario.Telefono = sdr["TELEFONO"].ToString();
                    operario.Foto = sdr["FOTO"].ToString();
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return operario;
        }

        public int guardarOperario(Operario operario, int Usuario)
        {
            int resultado = -1;
            try
            {
                using (Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("SPR_IU_Operarios", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_OPERARIO_ID", MySqlDbType.Int32, 4).Value = operario.Operario_id;
                    Cmd.Parameters.Add("p_DOCUMENTO", MySqlDbType.VarChar, 10).Value = operario.Documento;
                    Cmd.Parameters.Add("p_NOMBRES", MySqlDbType.VarChar, 25).Value = operario.Nombres;
                    Cmd.Parameters.Add("p_APELLIDOS", MySqlDbType.VarChar, 25).Value = operario.Apellidos;
                    Cmd.Parameters.Add("p_CORREO", MySqlDbType.VarChar, 50).Value = operario.Correo;
                    Cmd.Parameters.Add("p_TELEFONO", MySqlDbType.VarChar, 10).Value = operario.Telefono;
                    Cmd.Parameters.Add("p_FOTO", MySqlDbType.VarChar, 50).Value = operario.Foto;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", MySqlDbType.VarChar, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", MySqlDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;

        }

        public int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva)
        {
            int resultado = -1;
            try
            {
                using (MySqlConnection Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("SPR_U_CambioClave", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_OPERARIO_ID", MySqlDbType.Int32, 4).Value = Usuario;
                    Cmd.Parameters.Add("p_CLAVE_ANTERIOR", MySqlDbType.Int32, 6).Value = claveAnterior;
                    Cmd.Parameters.Add("p_CLAVE_NUEVA", MySqlDbType.Int32, 6).Value = claveNueva;
                    Cmd.Parameters.Add("p_RESULTADO", MySqlDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public ArrayList cargarListado()
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas("TBL_OPERARIOS");
            return arlLista;

        }

        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_OPERARIOS");
            return resultado;
        }


    }
}
