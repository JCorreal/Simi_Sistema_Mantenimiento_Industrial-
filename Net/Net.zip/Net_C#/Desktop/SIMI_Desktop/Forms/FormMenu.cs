﻿using SIMI_Desktop.BLL;
using System;
using System.Windows.Forms;

namespace SIMI_Desktop.Forms
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            if (Funciones.PerfilAcceso == 1)
            {
                button_Equipos.Enabled = true;
                button_Marcas.Enabled = true;
                button_Lineas.Enabled = true;
                button_Mantenimiento.Enabled = true;
            }
            lblUsuarioConectado.Text = lblUsuarioConectado.Text + " " + Funciones.NombreUsuario;
        }

        private void button_Operarios_Click(object sender, EventArgs e)
        {
            if (Funciones.PerfilAcceso == 1)
            {
                FormListados FormListados = new FormListados("Operarios");
                FormListados.ShowDialog(this);
            }
            else
            {
                Funciones.ParametroBuscar = Funciones.UsuarioConectado;
                FormOperarios Form_Operarios = new FormOperarios();
                Form_Operarios.ShowDialog(this);
            }
        }
        private void button_Equipos_Click(object sender, EventArgs e)
        {
            FormListados FormListados = new FormListados("Equipos");
            FormListados.ShowDialog(this);
        }
        private void button_Marcas_Click(object sender, EventArgs e)
        {
            FormListados FormListados = new FormListados("Marcas");
            FormListados.ShowDialog(this);
        }
        private void button_Lineas_Click(object sender, EventArgs e)
        {
            FormListados FormListados = new FormListados("Lineas");
            FormListados.ShowDialog(this);
        }
        private void button_Mantenimiento_Click(object sender, EventArgs e)
        {
            FormListados FormListados = new FormListados("Mantenimiento");
            FormListados.ShowDialog(this);
        }
        private void button_Clave_Click(object sender, EventArgs e)
        {
            FormCambioClave Form_CambioClave = new FormCambioClave();
            Form_CambioClave.ShowDialog(this);
        }



    }
}

