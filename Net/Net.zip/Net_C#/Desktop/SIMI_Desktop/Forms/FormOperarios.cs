﻿using SIMI_Desktop.BLL;
using SIMI_Desktop.BO;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace SIMI_Desktop
{
    public partial class FormOperarios : Form
    {
        public FormOperarios()
        {
            InitializeComponent();
            var blankContextMenu = new ContextMenuStrip();
            TextBoxDocumento.ContextMenuStrip = blankContextMenu;
            TextBoxNombres.ContextMenuStrip = blankContextMenu;
            TextBoxApellidos.ContextMenuStrip = blankContextMenu;
            TextBoxTelefono.ContextMenuStrip = blankContextMenu;

            // Habilitando teclas de Enter y Tab
            this.TextBoxDocumento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxDocumento_KeyPress);
            this.TextBoxNombres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxNombres_KeyPress);
            this.TextBoxApellidos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxApellidos_KeyPress);
            this.TextBoxCorreo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxCorreo_KeyPress);
            this.TextBoxTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxTelefono_KeyPress);
        }

        private Controlador_Operario _controlador = Funciones.crearControlador_Operario();
        private bool grabar;
        private string RutaFoto = "";
        private Operario operario;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter

        private void FormOperarios_Load(object sender, EventArgs e)
        {
            if (Funciones.ParametroBuscar != 0)
            {
                consultarBD();
            }
        }

        private void consultarBD()
        {
            operario = (Operario)_controlador.obtenerOperario(Funciones.ParametroBuscar);
            if (operario != null)
            {
                poblarFormulario();
            }
        }

        private void poblarFormulario() // Volcar datos de estrucura de Base da Datos sobre el Formulario actual
        {
            TextBoxDocumento.Enabled = false;
            if (Funciones.PerfilAcceso == 1)
            {
                ButtonEliminar.Enabled = true;
            }

            TextBoxDocumento.Text = operario.Documento;
            TextBoxNombres.Text = operario.Nombres;
            TextBoxApellidos.Text = operario.Apellidos;
            TextBoxCorreo.Text = operario.Correo;
            TextBoxTelefono.Text = operario.Telefono;
            if (operario.Foto != null && operario.Foto != "")
            {
                try
                {
                    string aPath = Application.StartupPath;
                    Int32 posicion = aPath.IndexOf("bin");
                    string sDestino = aPath.Substring(0, posicion) + "Fotos_Operarios/";                    
                    PictureBoxFotoUsuario.Image = Image.FromFile(sDestino + operario.Foto);
                }
                catch
                {
                    MessageBox.Show(Mensajes.Mensaje24, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            TextBoxNombres.Focus();
        }

        private void TextBoxDocumento_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxDocumento.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxDocumento.Text.Length < 6)
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.Mensaje15, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje15);
                }
                else if (TextBoxDocumento.Text.Substring(0, 1) == "0")
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.Mensaje6);
                }
                else
                {
                    errorPro.Clear();
                    TextBoxNombres.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxNombres_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxNombres.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxNombres.Focus();
                    errorPro.SetError(TextBoxNombres, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxNombres.Text = Funciones.eliminarTabulador(TextBoxNombres.Text, "1MAY");
                    errorPro.Clear();
                    TextBoxApellidos.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 65 || e.KeyChar > 97) && (e.KeyChar < 90 || e.KeyChar > 122) && e.KeyChar != 8 && e.KeyChar != 32)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxApellidos_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxApellidos.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxApellidos.Focus();
                    errorPro.SetError(TextBoxApellidos, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxApellidos.Text = Funciones.eliminarTabulador(TextBoxApellidos.Text, "1MAY");
                    errorPro.Clear();
                    TextBoxCorreo.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 65 || e.KeyChar > 97) && (e.KeyChar < 90 || e.KeyChar > 122) && e.KeyChar != 8 && e.KeyChar != 32)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxCorreo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (TextBoxCorreo.Text.Length != 0)
                {
                    TextBoxCorreo.Text = TextBoxCorreo.Text.ToLower();
                    if (Funciones.validar_Correo(TextBoxCorreo.Text))
                    {
                        grabar = false;
                        MessageBox.Show(Mensajes.Mensaje16, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxCorreo.Focus();
                        errorPro.SetError(TextBoxCorreo, Mensajes.Mensaje16);
                    }
                    else
                    {
                        errorPro.Clear();
                        TextBoxTelefono.Focus();
                    }
                }
                else
                {
                    TextBoxTelefono.Focus();
                }
            }
        }

        private void TextBoxTelefono_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar != 8) // Habilitar tecla de retroceso
            {
                if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
                {
                    if (Funciones.validar_CampoVacio(TextBoxTelefono.Text))
                    {
                        grabar = false;
                        MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        TextBoxTelefono.Focus();
                        errorPro.SetError(TextBoxTelefono, Mensajes.MensajeCampoRequerido);
                    }
                    else
                    {
                        if ((TextBoxTelefono.Text.Length != 7) && (TextBoxTelefono.Text.Length != 10))
                        {
                            grabar = false;
                            MessageBox.Show(Mensajes.Mensaje17, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            TextBoxTelefono.Focus();
                            errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje17);
                        }
                        else if (TextBoxTelefono.Text.Substring(0, 1) == "0")
                        {
                            grabar = false;
                            MessageBox.Show(Mensajes.Mensaje6, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            TextBoxTelefono.Focus();
                            errorPro.SetError(TextBoxTelefono, Mensajes.Mensaje6);
                        }
                        else
                        {
                            errorPro.Clear();
                            ButtonGrabar.Focus();
                        }
                    }
                }
                else
                    if (e.KeyChar >= 48 && e.KeyChar <= 57)
                    e.Handled = false;
                else if (e.KeyChar == 46)
                    e.Handled = false;
                else
                    e.Handled = true;
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            grabar = true;
            TextBoxDocumento_KeyPress(ButtonGrabar, Tecla);
            if (grabar)
            {
                TextBoxNombres_KeyPress(ButtonGrabar, Tecla);
                if (grabar)
                {
                    TextBoxApellidos_KeyPress(ButtonGrabar, Tecla);
                    if (grabar)
                    {
                        TextBoxCorreo_KeyPress(ButtonGrabar, Tecla);
                        if (grabar)
                        {
                            TextBoxTelefono_KeyPress(ButtonGrabar, Tecla);
                            if (grabar)
                            {
                                Guardar();
                            }
                        }
                    }
                }
            }
        }

        private void Guardar()
        {
            int resultado;
            Operario operario = new Operario();
            operario.Operario_id = Funciones.ParametroBuscar;
            operario.Documento = TextBoxDocumento.Text;
            operario.Nombres = TextBoxNombres.Text.Trim();
            operario.Apellidos = TextBoxApellidos.Text.Trim().Trim();
            operario.Telefono = TextBoxTelefono.Text;
            operario.Correo = TextBoxCorreo.Text.Trim();
            operario.Foto = RutaFoto;
            resultado = _controlador.guardarOperario(operario);
            if (resultado == 0)
            {
                if (Funciones.ParametroBuscar == 0)
                {
                    MessageBox.Show(Mensajes.MensajeGraba, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Limpiar();
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ButtonSalir.PerformClick();
                }
            }
            else if (resultado == 1)
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.Mensaje26, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Limpiar()
        {
            if (Funciones.ParametroBuscar == 0)
            {
                ButtonEliminar.Enabled = false;
                Funciones.limpiarForma(panel2);
                errorPro.Clear();
                PictureBoxFotoUsuario.Image = null;
                RutaFoto = "";
                TextBoxNombres.Focus();
            }
            else
            {
                poblarFormulario();
            }          
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void PictureBoxFotoUsuario_Click(object sender, EventArgs e)
        {
            string aPath = Application.StartupPath;
            Int32 posicion = aPath.IndexOf("bin");
            string sDestino = aPath.Substring(0, posicion) + "Fotos_Operarios/";
            if (Funciones.validar_CampoVacio(TextBoxDocumento.Text))
            {
                MessageBox.Show(Mensajes.Mensaje29, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                OpenFileDialog oFD = new OpenFileDialog();
                oFD.Title = "Seleccionar imagen";
                oFD.Filter = "Imagenes|*.jpg;*.gif;*.png;*.bmp|Todos (*.*)|*.*";
                if (oFD.ShowDialog() == DialogResult.OK)
                {                   
                    System.IO.FileInfo peso = new System.IO.FileInfo(oFD.FileName);
                    if (peso.Length > 133000) // Imagen de 3x4 no debería superar este peso
                    {
                        MessageBox.Show(Mensajes.Mensaje30, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        
                        string extension = Path.GetExtension(oFD.FileName);                        
                        this.PictureBoxFotoUsuario.Image = Image.FromFile(oFD.FileName);
                        sDestino = sDestino + TextBoxDocumento.Text  + extension;
                        File.Copy(oFD.FileName, sDestino, true);
                        RutaFoto = TextBoxDocumento.Text + extension;
                    }
                }
            }
           
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            int resultado;
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                resultado = _controlador.eliminarRegistro(Funciones.ParametroBuscar);
                if (resultado == 0)
                {
                    MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
					ButtonSalir.PerformClick();
                }
                else if (resultado == 1)
                {
                    MessageBox.Show(Mensajes.Mensaje20, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void LabelBorrarFoto_Click(object sender, EventArgs e)
        {
            PictureBoxFotoUsuario.Image = null;
            RutaFoto = "";
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            Funciones.mostararAyuda();
        }
    }
}
