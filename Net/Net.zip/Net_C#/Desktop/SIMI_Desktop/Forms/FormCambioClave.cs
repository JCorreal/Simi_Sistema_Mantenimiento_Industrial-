﻿using SIMI_Desktop.BLL;
using System;
using System.Windows.Forms;

namespace SIMI_Desktop
{
    public partial class FormCambioClave : Form
    {
        public FormCambioClave()
        {
            InitializeComponent();
            this.TextBoxClave.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxClave_KeyPress);
            this.TextBoxClaveNueva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxClaveNueva_KeyPress);
            this.TextBoxConfirmar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxConfirmar_KeyPress);
        }

        private Controlador_Operario _controlador = Funciones.crearControlador_Operario();
        private bool grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter

        private void FormCambioClave_Load(object sender, EventArgs e)
        {
        }

        private void TextBoxClave_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxClave.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClave.Focus();
                    errorPro.SetError(TextBoxClave, Mensajes.MensajeCampoRequerido);
                }
                else
                {
                    TextBoxClaveNueva.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxClaveNueva_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxClaveNueva.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClaveNueva.Focus();
                    errorPro.SetError(TextBoxClaveNueva, Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxClaveNueva.Text == TextBoxClave.Text) // Clave Nueva debe ser diferente de la actual
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.Mensaje4, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClaveNueva.Focus();
                    errorPro.SetError(TextBoxClaveNueva, Mensajes.Mensaje4);
                }
                else if (TextBoxClaveNueva.Text.Length != 6)
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.Mensaje21, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClaveNueva.Focus();
                    errorPro.SetError(TextBoxClaveNueva, Mensajes.Mensaje21);
                }
                else
                {
                    errorPro.Clear();
                    TextBoxConfirmar.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxConfirmar_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxConfirmar.Text))
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxConfirmar.Focus();
                    errorPro.SetError(TextBoxConfirmar, Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxConfirmar.Text != TextBoxClaveNueva.Text) // Debe confirmar la clave y debe ser igual a Clave Nueva
                {
                    grabar = false;
                    MessageBox.Show(Mensajes.Mensaje5, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxConfirmar.Focus();
                    errorPro.SetError(TextBoxConfirmar, Mensajes.Mensaje5);
                }
                else
                {
                    errorPro.Clear();
                    ButtonGrabar.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            grabar = true;
            TextBoxClave_KeyPress(ButtonGrabar, Tecla);
            if (grabar)
            {
                TextBoxClaveNueva_KeyPress(ButtonGrabar, Tecla);
                if (grabar)
                {
                    TextBoxConfirmar_KeyPress(ButtonGrabar, Tecla);
                    if (grabar)
                    {
                        Guardar();
                    }
                }
            }
        }

        private void Guardar()
        {
            int resultado = _controlador.guardarCambioClave(Convert.ToInt32(TextBoxClave.Text.Trim()), Convert.ToInt32(TextBoxClaveNueva.Text.Trim()));
            if (resultado == 0)
            {
                MessageBox.Show(Mensajes.MensajeActualiza, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (resultado == 1)
            {
                MessageBox.Show(Mensajes.Mensaje3, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ButtonSalir.PerformClick();
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void Limpiar()
        {
            Funciones.limpiarForma(panel2);
            errorPro.Clear();
            TextBoxClave.Focus();
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }




    }
}
