using SIMI_Desktop.BO;
using SIMI_Desktop.DAL;
using System.Collections;

namespace SIMI_Desktop.BLL
{
    public class Controlador_Equipo
    {
        private readonly IDao_Equipo _dao_equipo;

        public Controlador_Equipo(IDao_Equipo dao_equipo)
        {
            _dao_equipo = dao_equipo;
        }

        public ArrayList cargarListado()
        {
            return _dao_equipo.cargarListado();
        }

        public void CargarDatosCombos(string tabla)
        {
            _dao_equipo.cargarDatosCombos(tabla);
        }

        public Equipo obtenerEquipo(int datoBuscar)
        {
            Equipo equipo = new Equipo();
            equipo = _dao_equipo.obtenerEquipo(datoBuscar);
            return equipo;
        }

        public int guardarEquipo(Equipo equipo)
        {
            return _dao_equipo.guardarEquipo(equipo, Funciones.UsuarioConectado);
        }

        public int eliminarRegistro(int datoEliminar)
        {
            return _dao_equipo.eliminarRegistro(datoEliminar);
        }
    }
}