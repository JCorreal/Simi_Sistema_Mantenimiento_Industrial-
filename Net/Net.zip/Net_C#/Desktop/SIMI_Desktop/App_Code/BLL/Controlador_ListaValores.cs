﻿using SIMI_Desktop.BO;
using SIMI_Desktop.DAL;
using System.Collections;

namespace SIMI_Desktop.BLL
{
    class Controlador_ListaValores
    {
        private readonly IDao_ListaValores _dao_listavalores;

        public Controlador_ListaValores(IDao_ListaValores dao_listavalores)
        {
            _dao_listavalores = dao_listavalores;
        }

        public ArrayList cargarListado(string tabla)
        {
            return _dao_listavalores.cargarListado(tabla);
        }

        public ListaValores obtenerListaValores(int datoBuscar)
        {
            ListaValores ListaValores = new ListaValores();
            ListaValores = _dao_listavalores.obtenerListaValores(datoBuscar);
            return ListaValores;
        }

        public int guardarListaValores(ListaValores listavalores)
        {
            return _dao_listavalores.guardarListaValores(listavalores, Funciones.UsuarioConectado);
        }

        public int eliminarRegistro(int datoEliminar)
        {
            return _dao_listavalores.eliminarRegistro(datoEliminar);
        }
    }

}
