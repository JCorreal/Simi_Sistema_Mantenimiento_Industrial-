﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using SIMI_Desktop.BO;
using System.Collections;

namespace SIMI_Desktop.DAL
{
    public interface IDao_Operario
    {
        Operario obtenerAcceso(string documento, int clave);
        Operario obtenerOperario(int datoBuscar);
        int guardarOperario(Operario operario, int Usuario);
        int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva);
        ArrayList cargarListado();
        int eliminarRegistro(int datoEliminar);
    }
}
