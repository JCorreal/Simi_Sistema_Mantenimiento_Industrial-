﻿// DAL: Data Access Layer - Capa Acceso Datos
using SIMI_Desktop.BO;
using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;

namespace SIMI_Desktop.DAL
{
    public class Dao_Operario : Dao_General, IDao_Operario
    {
        // Default Constructor
        public Dao_Operario() { }

        public Operario obtenerAcceso(string documento, int clave)
        {
            Operario operario = new Operario();
            try
            {
                Cn = new SqlConnection(Conexion.obtenerConexion);
                Cmd = new SqlCommand("SPR_R_ObtenerAcceso", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = documento;
                Cmd.Parameters.Add("p_CLAVE", SqlDbType.Int, 6).Value = clave;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
                if (sdr.Read())
                {
                    operario.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Perfil = Convert.ToInt32(sdr["PERFIL"].ToString());
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return operario;
        }

        public Operario obtenerOperario(int datoBuscar)
        {
            Operario operario = new Operario();
            try
            {
                buscarRegistro("TBL_OPERARIOS", datoBuscar);
                if (sdr.Read())
                {
                    operario.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    operario.Documento = sdr["DOCUMENTO"].ToString();
                    operario.Nombres = sdr["NOMBRES"].ToString();
                    operario.Apellidos = sdr["APELLIDOS"].ToString();
                    operario.Correo = sdr["CORREO"].ToString();
                    operario.Telefono = sdr["TELEFONO"].ToString();
                    operario.Foto = sdr["FOTO"].ToString();
                }
                else
                {
                    operario = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return operario;
        }

        public int guardarOperario(Operario operario, int Usuario)
        {
            int resultado = -1;
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_IU_Operarios", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 4).Value = operario.Operario_id;
                    Cmd.Parameters.Add("p_DOCUMENTO", SqlDbType.VarChar, 10).Value = operario.Documento;
                    Cmd.Parameters.Add("p_NOMBRES", SqlDbType.VarChar, 25).Value = operario.Nombres;
                    Cmd.Parameters.Add("p_APELLIDOS", SqlDbType.VarChar, 25).Value = operario.Apellidos;
                    Cmd.Parameters.Add("p_CORREO", SqlDbType.VarChar, 50).Value = operario.Correo;
                    Cmd.Parameters.Add("p_TELEFONO", SqlDbType.VarChar, 10).Value = operario.Telefono;
                    Cmd.Parameters.Add("p_FOTO", SqlDbType.VarChar, 50).Value = operario.Foto;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.Int, 4).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;

        }

        public int guardarCambioClave(int Usuario, int claveAnterior, int claveNueva)
        {
            int resultado = -1;
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_U_CambioClave", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_OPERARIO_ID", SqlDbType.Int, 4).Value = Usuario;
                    Cmd.Parameters.Add("p_CLAVE_ANTERIOR", SqlDbType.Int, 6).Value = claveAnterior;
                    Cmd.Parameters.Add("p_CLAVE_NUEVA", SqlDbType.Int, 6).Value = claveNueva;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public ArrayList cargarListado()
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas("TBL_OPERARIOS");
            return arlLista;
        }

        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_OPERARIOS");
            return resultado;
        }


    }
}
