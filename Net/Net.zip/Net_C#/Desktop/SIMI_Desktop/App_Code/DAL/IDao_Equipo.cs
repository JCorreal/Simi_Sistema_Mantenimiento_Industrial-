﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using SIMI_Desktop.BO;
using System.Collections;

namespace SIMI_Desktop.DAL
{
    public interface IDao_Equipo
    {
        Equipo obtenerEquipo(int datoBuscar);
        int guardarEquipo(Equipo equipo, int Usuario);
        ArrayList cargarListado();
        void cargarDatosCombos(string tabla);
        int eliminarRegistro(int datoEliminar);
    }
}
