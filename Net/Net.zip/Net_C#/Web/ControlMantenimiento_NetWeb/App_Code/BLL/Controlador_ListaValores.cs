﻿using ControlMantenimiento_NetWeb.BLL;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.DAL;
using System.Collections;

public class Controlador_ListaValores
{
    private readonly IDao_ListaValores _dao_listavalores;

    public Controlador_ListaValores(IDao_ListaValores dao_listavalores)
    {
        _dao_listavalores = dao_listavalores;
    }

    public ArrayList cargarListado(string Tabla)
    {
        return _dao_listavalores.cargarListado(Tabla);
    }

    public ListaValores obtenerRegistro(int datoBuscar)
    {
        ListaValores ListaValores = new ListaValores();
        ListaValores = _dao_listavalores.obtenerListaValores(datoBuscar);
        return ListaValores;
    }

    public int guardarListaValores(ListaValores listavalores)
    {
        return _dao_listavalores.guardarListaValores(listavalores, Funciones.UsuarioConectado);
    }

    public int eliminarRegistro(int datoEliminar)
    {
        return _dao_listavalores.eliminarRegistro(datoEliminar);
    }


}