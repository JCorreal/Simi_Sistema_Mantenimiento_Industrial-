﻿using System;
using ControlMantenimiento_NetWeb.BLL;
using System.Web.UI.WebControls;
using System.Collections;

public partial class Forms_WebFormListadoMantenimientos : System.Web.UI.Page
{
    private Controlador_Mantenimiento _controlador = Funciones.CrearControlador_Mantenimiento();

    protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["TIPO_USUARIO"] == null)
            {
                Response.Redirect("~/Forms/WebFormAcceso.aspx");
            }
            if (!this.IsPostBack)
            {
                this.BindRepeater();
            }
        }

        private void BindRepeater()
        {
            Funciones.arlListadoGeneral = new ArrayList();
            Funciones.arlListadoGeneral = _controlador.cargarListado();
            Repeater1.DataSource = Funciones.arlListadoGeneral;
            Repeater1.DataBind();
    }



        protected void ButtonBuscar_Click(object sender, EventArgs e)
        {
            TextBoxBuscar.Text = TextBoxBuscar.Text.Trim();
            LabelInformacion.Text = "";
            LabelInformacion.ForeColor = System.Drawing.Color.Red;
            if (string.IsNullOrEmpty(TextBoxBuscar.Text.Trim()))
            {
                LabelInformacion.Text = Mensajes.MensajeCampoRequerido;
                TextBoxBuscar.Focus();
            }
            else
            {
                Repeater1.DataSource = Funciones.cargarBusqueda(TextBoxBuscar.Text.Trim().ToUpper());
                Repeater1.DataBind();
            }

        }


        protected void Repeater1_ItemCommand(object source, System.Web.UI.WebControls.RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Editar")
            {
               Funciones.ParametroBuscar = Convert.ToInt32(((Button)e.CommandSource).CommandArgument);
               Response.Redirect("~/Forms/WebFormMantenimiento.aspx");
            }

            else if (e.CommandName == "Eliminar")
            {
                int Resultado;
                Resultado = _controlador.eliminarRegistro(Convert.ToInt32(((Button)e.CommandSource).CommandArgument));

                if (Resultado == 0)
                {
                    Response.Redirect("~/Forms/WebFormListadoMantenimientos.aspx");
                }
                else
                {
                    LabelInformacion.Text = Mensajes.MensajeErrorBD;
                    Response.Redirect("~/Forms/WebFormError.aspx");
                }
            }

        }

        protected void ButtonNuevo_Click(object sender, EventArgs e)
        {
            Funciones.ParametroBuscar = 0;
            Response.Redirect("~/Forms/WebFormMantenimiento.aspx");            
        }
    }
