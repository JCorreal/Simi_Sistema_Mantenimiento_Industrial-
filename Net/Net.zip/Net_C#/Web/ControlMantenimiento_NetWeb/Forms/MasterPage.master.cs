﻿using System;
using ControlMantenimiento_NetWeb.BLL;


public partial class Forms_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LabelTitulo.Text = Mensajes.MensajeAplicacion;
    }
}
