﻿using System;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.BLL;

public partial class Forms_WebFormListaValores : System.Web.UI.Page
{
    private Controlador_ListaValores _controlador = Funciones.CrearControlador_ListaValores();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["TIPO_USUARIO"] == null)
        {
            Response.Redirect("~/Forms/WebFormAcceso.aspx");
        }
        lblTitulo.Text = Funciones.Pagina;
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Funciones.ParametroBuscar != 0)
        {
            LlenarCampos();
        }
    }

    private void LlenarCampos()
    {
        ListaValores listavalores = (ListaValores)_controlador.obtenerRegistro(Funciones.ParametroBuscar);
        if (listavalores != null)
        {
            lblCodigo.Text = listavalores.Listavalores_id.ToString();
            TextBoxNombre.Text = listavalores.Nombre;
            TextBoxDescripcion.Text = listavalores.Descripcion;
        }
        TextBoxNombre.Focus();
    }

    private bool Verificar()
    {
        if (Funciones.validar_CampoVacio(TextBoxNombre.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxNombre.Focus();
            return false;
        }
        return true;
    }

    protected void ButtonGrabar_Click(object sender, EventArgs e)
    {
        if (Verificar())
        {
            Guardar(Convert.ToInt32(lblCodigo.Text), (lblCodigo.Text == "0") ? Mensajes.MensajeGraba : Mensajes.MensajeActualiza);
        }
    }

    private void Guardar(int ElCodigo, string Mensaje)
    {
        int Resultado;
        ListaValores listavalores = new ListaValores();
        listavalores.Listavalores_id = ElCodigo;
        listavalores.Nombre = TextBoxNombre.Text.Trim();
        listavalores.Descripcion = TextBoxDescripcion.Text;
        listavalores.Tipo = Funciones.Pagina;
        Resultado = _controlador.guardarListaValores(listavalores);
        if (Resultado == 0)
        {
            listavalores = null;
            Funciones.ParametroBuscar = 0;
            Response.Redirect("~/Forms/WebFormRespuesta.aspx");
        }
        else if (Resultado == 1)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje8;
            TextBoxNombre.Focus();
        }
        else
        {
            Response.Redirect("~/Forms/WebFormError.aspx");
        }
    }

    protected void ImageButtonAyuda_Click(object sender, System.Web.UI.ImageClickEventArgs e)
    {
        /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
        proc.EnableRaisingEvents = false;
        proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/Ayudas/Ayuda.chm";
        proc.Start();
        proc.Dispose();*/

        // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        // donde descomprimió el archivo descargado de la web
    }
}