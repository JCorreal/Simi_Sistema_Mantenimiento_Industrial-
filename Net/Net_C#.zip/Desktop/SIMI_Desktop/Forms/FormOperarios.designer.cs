﻿namespace SIMI_Desktop
{
    partial class FormOperarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOperarios));
            this.ButtonGrabar = new System.Windows.Forms.Button();
            this.errorPro = new System.Windows.Forms.ErrorProvider(this.components);
            this.ButtonSalir = new System.Windows.Forms.Button();
            this.ButtonAyuda = new System.Windows.Forms.Button();
            this.ButtonEliminar = new System.Windows.Forms.Button();
            this.ButtonCancelar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.LabelBorrarFoto = new System.Windows.Forms.Label();
            this.ButtonBuscar = new System.Windows.Forms.Button();
            this.ListBoxOperarios = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PictureBoxFotoUsuario = new System.Windows.Forms.PictureBox();
            this.TextBoxTelefono = new System.Windows.Forms.TextBox();
            this.TextBoxCorreo = new System.Windows.Forms.TextBox();
            this.TextBoxApellidos = new System.Windows.Forms.TextBox();
            this.TextBoxNombres = new System.Windows.Forms.TextBox();
            this.TextBoxDocumento = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFotoUsuario)).BeginInit();
            this.SuspendLayout();
            // 
            // ButtonGrabar
            // 
            this.ButtonGrabar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonGrabar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonGrabar.ForeColor = System.Drawing.Color.Black;
            this.ButtonGrabar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonGrabar.Image")));
            this.ButtonGrabar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonGrabar.Location = new System.Drawing.Point(136, 21);
            this.ButtonGrabar.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonGrabar.Name = "ButtonGrabar";
            this.ButtonGrabar.Size = new System.Drawing.Size(80, 43);
            this.ButtonGrabar.TabIndex = 7;
            this.ButtonGrabar.TabStop = false;
            this.ButtonGrabar.Text = "Grabar";
            this.ButtonGrabar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonGrabar.UseVisualStyleBackColor = false;
            this.ButtonGrabar.Click += new System.EventHandler(this.ButtonGrabar_Click);
            // 
            // errorPro
            // 
            this.errorPro.ContainerControl = this;
            // 
            // ButtonSalir
            // 
            this.ButtonSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonSalir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.ButtonSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonSalir.ForeColor = System.Drawing.Color.Black;
            this.ButtonSalir.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSalir.Image")));
            this.ButtonSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonSalir.Location = new System.Drawing.Point(439, 21);
            this.ButtonSalir.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonSalir.Name = "ButtonSalir";
            this.ButtonSalir.Size = new System.Drawing.Size(80, 43);
            this.ButtonSalir.TabIndex = 11;
            this.ButtonSalir.TabStop = false;
            this.ButtonSalir.Text = "Salir";
            this.ButtonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonSalir.UseVisualStyleBackColor = false;
            this.ButtonSalir.Click += new System.EventHandler(this.ButtonSalir_Click);
            // 
            // ButtonAyuda
            // 
            this.ButtonAyuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAyuda.ForeColor = System.Drawing.Color.Black;
            this.ButtonAyuda.Image = ((System.Drawing.Image)(resources.GetObject("ButtonAyuda.Image")));
            this.ButtonAyuda.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonAyuda.Location = new System.Drawing.Point(363, 21);
            this.ButtonAyuda.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonAyuda.Name = "ButtonAyuda";
            this.ButtonAyuda.Size = new System.Drawing.Size(80, 43);
            this.ButtonAyuda.TabIndex = 10;
            this.ButtonAyuda.TabStop = false;
            this.ButtonAyuda.Text = "Ayuda";
            this.ButtonAyuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonAyuda.UseVisualStyleBackColor = false;
            this.ButtonAyuda.Click += new System.EventHandler(this.ButtonAyuda_Click);
            // 
            // ButtonEliminar
            // 
            this.ButtonEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonEliminar.Enabled = false;
            this.ButtonEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonEliminar.ForeColor = System.Drawing.Color.Black;
            this.ButtonEliminar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonEliminar.Image")));
            this.ButtonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonEliminar.Location = new System.Drawing.Point(287, 21);
            this.ButtonEliminar.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonEliminar.Name = "ButtonEliminar";
            this.ButtonEliminar.Size = new System.Drawing.Size(80, 43);
            this.ButtonEliminar.TabIndex = 9;
            this.ButtonEliminar.TabStop = false;
            this.ButtonEliminar.Text = "Eliminar";
            this.ButtonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonEliminar.UseVisualStyleBackColor = false;
            this.ButtonEliminar.Click += new System.EventHandler(this.ButtonEliminar_Click);
            // 
            // ButtonCancelar
            // 
            this.ButtonCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCancelar.ForeColor = System.Drawing.Color.Black;
            this.ButtonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCancelar.Image")));
            this.ButtonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ButtonCancelar.Location = new System.Drawing.Point(211, 21);
            this.ButtonCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonCancelar.Name = "ButtonCancelar";
            this.ButtonCancelar.Size = new System.Drawing.Size(80, 43);
            this.ButtonCancelar.TabIndex = 8;
            this.ButtonCancelar.TabStop = false;
            this.ButtonCancelar.Text = "Cancelar";
            this.ButtonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ButtonCancelar.UseVisualStyleBackColor = false;
            this.ButtonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.ButtonSalir);
            this.panel1.Controls.Add(this.ButtonAyuda);
            this.panel1.Controls.Add(this.ButtonEliminar);
            this.panel1.Controls.Add(this.ButtonCancelar);
            this.panel1.Controls.Add(this.ButtonGrabar);
            this.panel1.Location = new System.Drawing.Point(-1, 359);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(693, 94);
            this.panel1.TabIndex = 275;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.LabelBorrarFoto);
            this.panel2.Controls.Add(this.ButtonBuscar);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.ListBoxOperarios);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.PictureBoxFotoUsuario);
            this.panel2.Controls.Add(this.TextBoxTelefono);
            this.panel2.Controls.Add(this.TextBoxCorreo);
            this.panel2.Controls.Add(this.TextBoxApellidos);
            this.panel2.Controls.Add(this.TextBoxNombres);
            this.panel2.Controls.Add(this.TextBoxDocumento);
            this.panel2.Location = new System.Drawing.Point(43, 28);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(693, 455);
            this.panel2.TabIndex = 276;
            // 
            // LabelBorrarFoto
            // 
            this.LabelBorrarFoto.AutoSize = true;
            this.LabelBorrarFoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelBorrarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelBorrarFoto.Location = new System.Drawing.Point(541, 246);
            this.LabelBorrarFoto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LabelBorrarFoto.Name = "LabelBorrarFoto";
            this.LabelBorrarFoto.Size = new System.Drawing.Size(93, 19);
            this.LabelBorrarFoto.TabIndex = 325;
            this.LabelBorrarFoto.Text = "Borrar Foto";
            this.LabelBorrarFoto.Click += new System.EventHandler(this.LabelBorrarFoto_Click);
            // 
            // ButtonBuscar
            // 
            this.ButtonBuscar.Location = new System.Drawing.Point(385, 76);
            this.ButtonBuscar.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonBuscar.Name = "ButtonBuscar";
            this.ButtonBuscar.Size = new System.Drawing.Size(36, 28);
            this.ButtonBuscar.TabIndex = 324;
            this.ButtonBuscar.TabStop = false;
            this.ButtonBuscar.Text = "...";
            this.ButtonBuscar.UseVisualStyleBackColor = true;
            this.ButtonBuscar.Click += new System.EventHandler(this.ButtonBuscar_Click);
            // 
            // ListBoxOperarios
            // 
            this.ListBoxOperarios.BackColor = System.Drawing.SystemColors.Info;
            this.ListBoxOperarios.FormattingEnabled = true;
            this.ListBoxOperarios.ItemHeight = 16;
            this.ListBoxOperarios.Location = new System.Drawing.Point(184, 16);
            this.ListBoxOperarios.Margin = new System.Windows.Forms.Padding(4);
            this.ListBoxOperarios.Name = "ListBoxOperarios";
            this.ListBoxOperarios.Size = new System.Drawing.Size(323, 52);
            this.ListBoxOperarios.TabIndex = 318;
            this.ListBoxOperarios.Visible = false;
            this.ListBoxOperarios.DoubleClick += new System.EventHandler(this.ListBoxOperarios_DoubleClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(152, 246);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 285;
            this.label5.Text = "Telefono";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(153, 210);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 284;
            this.label4.Text = "Correo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(152, 167);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 283;
            this.label3.Text = "Apellidos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(152, 124);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 282;
            this.label2.Text = "Nombres";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(152, 84);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 17);
            this.label1.TabIndex = 281;
            this.label1.Text = "Documento";
            // 
            // PictureBoxFotoUsuario
            // 
            this.PictureBoxFotoUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBoxFotoUsuario.Location = new System.Drawing.Point(511, 76);
            this.PictureBoxFotoUsuario.Margin = new System.Windows.Forms.Padding(4);
            this.PictureBoxFotoUsuario.Name = "PictureBoxFotoUsuario";
            this.PictureBoxFotoUsuario.Size = new System.Drawing.Size(154, 162);
            this.PictureBoxFotoUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PictureBoxFotoUsuario.TabIndex = 280;
            this.PictureBoxFotoUsuario.TabStop = false;
            this.PictureBoxFotoUsuario.Click += new System.EventHandler(this.PictureBoxFotoUsuario_Click);
            // 
            // TextBoxTelefono
            // 
            this.TextBoxTelefono.Location = new System.Drawing.Point(281, 238);
            this.TextBoxTelefono.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxTelefono.MaxLength = 10;
            this.TextBoxTelefono.Name = "TextBoxTelefono";
            this.TextBoxTelefono.Size = new System.Drawing.Size(95, 22);
            this.TextBoxTelefono.TabIndex = 4;
            this.TextBoxTelefono.TabStop = false;
            // 
            // TextBoxCorreo
            // 
            this.TextBoxCorreo.Location = new System.Drawing.Point(281, 198);
            this.TextBoxCorreo.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxCorreo.MaxLength = 50;
            this.TextBoxCorreo.Name = "TextBoxCorreo";
            this.TextBoxCorreo.Size = new System.Drawing.Size(213, 22);
            this.TextBoxCorreo.TabIndex = 3;
            this.TextBoxCorreo.TabStop = false;
            // 
            // TextBoxApellidos
            // 
            this.TextBoxApellidos.Location = new System.Drawing.Point(281, 159);
            this.TextBoxApellidos.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxApellidos.MaxLength = 25;
            this.TextBoxApellidos.Name = "TextBoxApellidos";
            this.TextBoxApellidos.Size = new System.Drawing.Size(213, 22);
            this.TextBoxApellidos.TabIndex = 2;
            this.TextBoxApellidos.TabStop = false;
            // 
            // TextBoxNombres
            // 
            this.TextBoxNombres.Location = new System.Drawing.Point(281, 119);
            this.TextBoxNombres.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxNombres.MaxLength = 25;
            this.TextBoxNombres.Name = "TextBoxNombres";
            this.TextBoxNombres.Size = new System.Drawing.Size(213, 22);
            this.TextBoxNombres.TabIndex = 1;
            this.TextBoxNombres.TabStop = false;
            // 
            // TextBoxDocumento
            // 
            this.TextBoxDocumento.Location = new System.Drawing.Point(281, 80);
            this.TextBoxDocumento.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxDocumento.MaxLength = 10;
            this.TextBoxDocumento.Name = "TextBoxDocumento";
            this.TextBoxDocumento.Size = new System.Drawing.Size(95, 22);
            this.TextBoxDocumento.TabIndex = 0;
            this.TextBoxDocumento.TabStop = false;
            // 
            // FormOperarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 507);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormOperarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Operarios";
            this.Load += new System.EventHandler(this.FormOperarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorPro)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFotoUsuario)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ButtonGrabar;
        private System.Windows.Forms.ErrorProvider errorPro;
        private System.Windows.Forms.Button ButtonEliminar;
        private System.Windows.Forms.Button ButtonCancelar;
        private System.Windows.Forms.Button ButtonSalir;
        private System.Windows.Forms.Button ButtonAyuda;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox PictureBoxFotoUsuario;
        private System.Windows.Forms.TextBox TextBoxTelefono;
        private System.Windows.Forms.TextBox TextBoxCorreo;
        private System.Windows.Forms.TextBox TextBoxApellidos;
        private System.Windows.Forms.TextBox TextBoxNombres;
        private System.Windows.Forms.TextBox TextBoxDocumento;
        private System.Windows.Forms.ListBox ListBoxOperarios;
        private System.Windows.Forms.Button ButtonBuscar;
        private System.Windows.Forms.Label LabelBorrarFoto;
    }
}

