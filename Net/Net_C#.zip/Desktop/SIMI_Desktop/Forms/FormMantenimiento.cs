﻿
/*=================================================================================== 
 La norma es que no puede haber sino una sola programación por equipo
 Un Operario no puede estar asignado en la misma fecha para varios mantenimientos
 ==================================================================================== */

using System;
using System.Windows.Forms;
using SIMI_Desktop.BO;
using SIMI_Desktop.BLL;
using System.Collections;

namespace SIMI_Desktop
{
    public partial class FormMantenimiento : Form
    {
        public FormMantenimiento()
        {
            InitializeComponent();
            this.DropDownListEquipos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListEquipos_KeyPress);
            this.DropDownListOperarios.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DropDownListOperarios_KeyPress);
            this.DateTimePickerFecha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DateTimePickerFecha_KeyPress);
            this.TextBoxObservaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxObservaciones_KeyPress);
        }

        private int elMantenimiento = 0;
        private Controlador_Mantenimiento _controlador = Funciones.crearControlador_Mantenimiento();
        private bool grabar;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter       

        private void FormMantenimiento_Load(object sender, EventArgs e)
        {
            if (Funciones.Fuente == "PROGRAMACION")            
            {
                ButtonBuscar.Visible = true;
                Label_Mensaje.Visible = true;
                ButtonGrabar.Enabled = false;
            }
            CargarCombos();         
        }

        private void CargarCombos()
        {
            ArrayList arlListado = new ArrayList();
            ArrayList arlListadoOperarios = new ArrayList();
            ArrayList arlListadoEquipos = new ArrayList();
            arlListado = _controlador.controlarProgramacion(Funciones.Fuente);
            for (int i = 0; i < arlListado.Count; i++)
            {
                if (Convert.ToString(arlListado[i]).Trim().Equals("EQUIPOS"))
                {
                    arlListadoEquipos.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++;
                }
                else if (Convert.ToString(arlListado[i]).Trim().Equals("OPERARIOS"))
                {
                    arlListadoOperarios.Add(new CargaCombosListas(arlListado[i + 1].ToString(), arlListado[i + 1].ToString() + " " + arlListado[i + 2].ToString()));
                    i++; i++;
                }
            }

            DropDownListEquipos.ValueMember = "CODIGO";
            DropDownListEquipos.DisplayMember = "DETALLE";
            DropDownListEquipos.DataSource = arlListadoEquipos;

            DropDownListOperarios.ValueMember = "CODIGO";
            DropDownListOperarios.DisplayMember = "DETALLE";
            DropDownListOperarios.DataSource = arlListadoOperarios;

            if (DropDownListEquipos.Items.Count == 0)
            {
                ButtonSalir.PerformClick();
            }
        }

        private void DropDownListEquipos_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DropDownListOperarios.Focus();
            }
        }

        private void DropDownListOperarios_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DateTimePickerFecha.Focus();
            }
        }

        private void DateTimePickerFecha_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                DateTimePickerFecha_ValueChanged(DateTimePickerFecha, e);
            }            
        }

        private void TextBoxObservaciones_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
               Funciones.eliminarTabulador(TextBoxObservaciones.Text, "");
               ButtonGrabar.Focus();
            }
        }

        private void ButtonGrabar_Click(object sender, EventArgs e)
        {
            grabar = true;
            DateTimePickerFecha_KeyPress(ButtonGrabar, Tecla);              
            if (grabar)
            {
                if (Funciones.Fuente == "PROGRAMAR")
                {
                    Guardar(Mensajes.MensajeGraba);
                }
                else
                {
                    Guardar(Mensajes.MensajeActualiza);
                }
            }            
        }

        private void Guardar(string Mensaje)
        {
            int resultado;
            Mantenimiento mantenimiento = new Mantenimiento();
            mantenimiento.Mantenimiento_id = elMantenimiento;
            mantenimiento.Equipo_id = Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString()); 
            mantenimiento.Operario_id = Convert.ToDouble(DropDownListOperarios.SelectedValue.ToString()); 
            mantenimiento.Fecha = Convert.ToDateTime(DateTimePickerFecha.Value);
            mantenimiento.Observaciones = TextBoxObservaciones.Text;
            
            resultado = _controlador.guardarMantenimiento(mantenimiento);
            if (resultado == 0)
            {
                MessageBox.Show(Mensaje, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);                
                Limpiar();
                CargarCombos();
            }
            else if (resultado == 1)
            {
                MessageBox.Show(Mensajes.Mensaje10, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DropDownListOperarios.Focus();
                errorPro.SetError(DropDownListOperarios, Mensajes.Mensaje10);
            }
            else
            {
                MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }           
            
        }

        private void Limpiar()
        {
            elMantenimiento = 0;
            ButtonEliminar.Enabled = false;
            DropDownListEquipos.Enabled = true;
            Funciones.limpiarForma(panel2);
            DateTimePickerFecha.Value = DateTime.Now.Date;
            errorPro.Clear();
            if (Funciones.Fuente == "PROGRAMACION")
            {
                ButtonGrabar.Enabled = false;
            }
            DropDownListEquipos.Focus();
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {            
            Limpiar();            
        }
                
        private void ButtonBuscar_Click(object sender, EventArgs e)
        {
            LlenarCampos();        
        }
        
        private void LlenarCampos()
        {
          Mantenimiento mantenimiento = (Mantenimiento)_controlador.obtenerMantenimiento(Convert.ToInt32(DropDownListEquipos.SelectedValue.ToString()));
          if (mantenimiento != null)
          {
              elMantenimiento = mantenimiento.Mantenimiento_id;
              ButtonEliminar.Enabled = true;
              DropDownListEquipos.Enabled = false;
              DropDownListOperarios.SelectedValue = mantenimiento.Operario_id.ToString();
              ButtonEliminar.Enabled = true;
              DateTimePickerFecha.Value = mantenimiento.Fecha;
              TextBoxObservaciones.Text = mantenimiento.Observaciones;
              ButtonGrabar.Enabled = true;
              DropDownListOperarios.Focus();
          }
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            _controlador = null;
            this.Close();
            this.Dispose();
        }

        private void ButtonEliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Mensajes.MensajeConfirmarBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                
                if (_controlador.eliminarRegistro(elMantenimiento) == 0)
                {
                    MessageBox.Show(Mensajes.MensajeBorrado, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(Mensajes.MensajeErrorBD, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }                
                Limpiar();
                CargarCombos();
            }
            
        }

        private void DateTimePickerFecha_ValueChanged(object sender, EventArgs e)
        {
            if (DateTimePickerFecha.Value < DateTime.Now.Date)
            {
                grabar = false;
                MessageBox.Show(Mensajes.Mensaje27, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                DateTimePickerFecha.Focus();
                errorPro.SetError(DateTimePickerFecha, Mensajes.Mensaje27);
            }
            else
            {
                errorPro.Clear();
                TextBoxObservaciones.Focus ();
            }
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
           /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetDesktop/ControlMantenimiento-NetDesktop/Ayudas/Ayuda.chm";
            proc.Start();
            proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }
                      

    }
}
