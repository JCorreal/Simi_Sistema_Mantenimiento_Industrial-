﻿using ControlMantenimiento_NetWeb.BLL;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.DAL;
using System.Collections;


public class Controlador_Equipo
{
    private readonly IDao_Equipo _dao_equipo;

    public Controlador_Equipo(IDao_Equipo dao_equipo)
    {
        _dao_equipo = dao_equipo;
    }

    public ArrayList cargarListado(string condicion)
    {
        return _dao_equipo.cargarListado(condicion);
    }

    public ArrayList controlarProgramacion()
    {
     return _dao_equipo.controlarProgramacion();
    }

    public Equipo obtenerRegistro(int datoBuscar)
    {
        Equipo equipo = new Equipo();
        equipo = _dao_equipo.obtenerEquipo(datoBuscar);
        return equipo;
    }

    public int guardarEquipo(Equipo equipo)
    {
        return _dao_equipo.guardarEquipo(equipo, Funciones.UsuarioConectado);
    }

    public int eliminarRegistro(int datoEliminar)
    {
        return _dao_equipo.eliminarRegistro(datoEliminar);
    }

}