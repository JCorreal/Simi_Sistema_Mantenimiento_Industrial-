﻿using ControlMantenimiento_NetWeb.BLL;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.DAL;
using System.Collections;

public class Controlador_Mantenimiento
{
    private readonly IDao_Mantenimiento _dao_mantenimiento;

    public Controlador_Mantenimiento(IDao_Mantenimiento dao_mantenimiento)
    {
        _dao_mantenimiento = dao_mantenimiento;
    }

    public ArrayList cargarListado(string condicion)
    {
        return _dao_mantenimiento.cargarListado(condicion);
    }

    public ArrayList controlarProgramacion(string Tabla)
    {
        return _dao_mantenimiento.controlarProgramacion(Tabla);
    }

    public Mantenimiento obtenerRegistro(int datoBuscar)
    {
        Mantenimiento mantenimiento = new Mantenimiento();
        mantenimiento = _dao_mantenimiento.obtenerMantenimiento(datoBuscar);
        return mantenimiento;
    }

    public int guardarMantenimiento(Mantenimiento mantenimiento)
    {
        return _dao_mantenimiento.guardarMantenimiento(mantenimiento, Funciones.UsuarioConectado);
    }

    public int eliminarRegistro(int datoEliminar)
    {
        return _dao_mantenimiento.eliminarRegistro(datoEliminar);
    }
}

