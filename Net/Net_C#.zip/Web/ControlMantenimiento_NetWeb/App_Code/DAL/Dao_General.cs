﻿// DAL: Data Access Layer - Capa Acceso Datos Variables Generales
using System;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public class Dao_General
    {
        // Default Constructor
        public Dao_General() { }

        public SqlConnection Cn;   // Conexion 
        public SqlDataReader sdr;  // Cursor - Recordset de solo lectura
        public SqlCommand Cmd;     // Objeto de tipo Command para acceder a Procedimientos Almacenados        

        public void buscarRegistro(string tabla, int datoBuscar)
        {
            try
            {
                Cn = new SqlConnection(Conexion.obtenerConexion);
                Cmd = new SqlCommand("SPR_R_buscarRegistro", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla;
                Cmd.Parameters.Add("p_DATOBUSCAR", SqlDbType.Int, 4).Value = datoBuscar;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ArrayList cargarListas(string tabla, string condicion)
        {
            ArrayList arlListado = new ArrayList();
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_R_cargarListado", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla;
                    Cmd.Parameters.Add("p_CONDICION", SqlDbType.VarChar, 20).Value = condicion;
                    Cn.Open();
                    using (sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            arlListado.Add(new CargarListado(sdr.GetValue(0).ToString(), sdr.GetValue(1).ToString(), sdr.GetValue(2).ToString(), sdr.GetValue(3).ToString(), sdr.GetValue(4).ToString()));
                        }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return arlListado;
        }

        public ArrayList controlProgramacion(string tabla)
        {
            ArrayList arlListControlProgramacion = new ArrayList();
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_R_CargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 30).Value = tabla;
                    Cn.Open();
                    using (sdr = Cmd.ExecuteReader(CommandBehavior.CloseConnection))
                        while (sdr.Read())
                        {
                            arlListControlProgramacion.Add(sdr.GetValue(2).ToString());
                            arlListControlProgramacion.Add(sdr.GetValue(0).ToString());
                            arlListControlProgramacion.Add(sdr.GetValue(1).ToString());
                        }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return arlListControlProgramacion;
        }

        public int borrarRegistro(int datoEliminar, string tabla)
        {
            int resultado = 0;
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_D_Registro", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", SqlDbType.VarChar, 20).Value = tabla;
                    Cmd.Parameters.Add("p_CONDICION", SqlDbType.Int, 4).Value = datoEliminar;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public void liberarRecursos()
        {
            Cmd.Dispose();
            if (Cn != null)
            {
                Cn.Close();
                Cn.Dispose();
            }
        }
    }
}