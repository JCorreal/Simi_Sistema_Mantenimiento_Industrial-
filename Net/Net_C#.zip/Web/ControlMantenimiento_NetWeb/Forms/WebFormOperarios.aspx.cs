﻿using System;
using System.Web.UI;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.BLL;

public partial class Forms_WebFormOperarios : System.Web.UI.Page
{
    private Controlador_Operario _controlador = Funciones.CrearControlador_Operario();

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Funciones.ParametroBuscar != 0)
        {
            LlenarCampos();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["TIPO_USUARIO"] == null)
        {
            Response.Redirect("~/Forms/WebFormAcceso.aspx");
        }
    }

    private bool Verificar()
    {
        if (Funciones.validar_CampoVacio(TextBoxDocumento.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxDocumento.Focus();
            return false;
        }
        if (Funciones.validar_SoloNumeros(TextBoxDocumento.Text))
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje25;
            TextBoxDocumento.Focus();
            return false;
        }
        if (TextBoxDocumento.Text.Length < 6)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje15;
            TextBoxDocumento.Focus();
            return false;
        }
        if (TextBoxDocumento.Text.Substring(0, 1) == "0")
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje6;
            TextBoxDocumento.Focus();
            return false;
        }
        if (Funciones.validar_CampoVacio(TextBoxNombres.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxNombres.Focus();
            return false;
        }
        TextBoxNombres.Text = Funciones.eliminarTabulador(TextBoxNombres.Text, "1MAY");
        if (Funciones.validar_SoloLetras(TextBoxNombres.Text))
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje23;
            TextBoxNombres.Focus();
            return false;
        }
        if (Funciones.validar_CampoVacio(TextBoxApellidos.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxApellidos.Focus();
            return false;
        }
        TextBoxApellidos.Text = Funciones.eliminarTabulador(TextBoxApellidos.Text, "1MAY");
        if (Funciones.validar_SoloLetras(TextBoxApellidos.Text))
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje23;
            TextBoxApellidos.Focus();
            return false;
        }
        if (TextBoxCorreo.Text.Length != 0)
        {
            if (Funciones.validar_Correo(TextBoxCorreo.Text))
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje16;
                TextBoxCorreo.Focus();
                return false;
            }
        }
        if (Funciones.validar_CampoVacio(TextBoxTelefono.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxTelefono.Focus();
            return false;
        }
        if ((TextBoxTelefono.Text.Length != 7) && (TextBoxTelefono.Text.Length != 10))
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje17;
            TextBoxTelefono.Focus();
            return false;
        }
        if (TextBoxTelefono.Text.Substring(0, 1) == "0")
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje6;
            TextBoxTelefono.Focus();
            return false;
        }

        return true;
    }

    private void Guardar(string Mensaje)
    {
        int Resultado;
        Operario operario = new Operario();
        operario.Operario_id = Funciones.ParametroBuscar;
        operario.Documento = TextBoxDocumento.Text;
        operario.Nombres = TextBoxNombres.Text.Trim();
        operario.Apellidos = TextBoxApellidos.Text.Trim();
        operario.Telefono = TextBoxTelefono.Text;
        operario.Correo = TextBoxCorreo.Text.ToLower().Trim();
        //FileUpload1.SaveAs(Server.MapPath("~/resources/Imagenes/") + FileUpload1.FileName);
        operario.Foto = "~/resources/Imagenes/" + FileUpload1.FileName;
        Resultado = _controlador.guardarOperario(operario);
        if (Resultado == 0)
        {
            operario = null;
            Funciones.ParametroBuscar = 0;
            Response.Redirect("~/Forms/WebFormRespuesta.aspx");
        }
        else if (Resultado == 1)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje26;
            TextBoxDocumento.Focus();
        }
        else
        {
            Response.Redirect("~/Forms/WebFormError.aspx");
        }
    }

    private void Limpiar()
    {
        Control strWebForm = Page.FindControl("frmOperarios");
        Funciones.limpiarForma(strWebForm);
    }

    private void LlenarCampos()
    {
        
        Operario operario = (Operario)_controlador.obtenerRegistro(Funciones.ParametroBuscar);
        if (operario != null)
        {
            TextBoxDocumento.Enabled = false;
            TextBoxDocumento.Text = operario.Documento.ToString();
            TextBoxNombres.Text = operario.Nombres;
            TextBoxApellidos.Text = operario.Apellidos;
            TextBoxCorreo.Text = operario.Correo;
            TextBoxTelefono.Text = operario.Telefono.ToString();
            if (operario.Foto != null)
            {
                ImageFoto.ImageUrl = operario.Foto;
            }
        }

        TextBoxNombres.Focus();
    }

    protected void ButtonGrabar_Click(object sender, EventArgs e)
    {
        if (Verificar())
        {
            Guardar(TextBoxDocumento.Enabled ? Mensajes.MensajeGraba : Mensajes.MensajeActualiza);
        }
    }


    protected void ImageButtonAyuda_Click(object sender, ImageClickEventArgs e)
    {
        /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
        proc.EnableRaisingEvents = false;
        proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/Ayudas/Ayuda.chm";
        proc.Start();
        proc.Dispose();*/

        // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        // donde descomprimió el archivo descargado de la web
    }    
}    
