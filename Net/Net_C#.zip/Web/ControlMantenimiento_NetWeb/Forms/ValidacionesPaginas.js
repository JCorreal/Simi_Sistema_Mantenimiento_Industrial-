function VerificarAcceso() {  
  
  document.getElementById('TextBoxDocumento').value = document.getElementById('TextBoxDocumento').value.replace(/^\s+|\s+$/g, "");
  if (document.getElementById('TextBoxDocumento').value == '') {
      document.getElementById('TextBoxMensajeError').value = "Documento es requerido";      
      document.getElementById('TextBoxDocumento').focus();
      return false;
  }
   if (document.getElementById('TextBoxDocumento').value.length < 6) 
   { 	
      document.getElementById('TextBoxMensajeError').value = 'Documento debe ser mayor de 6 digTextBoxos';	
      document.getElementById('TextBoxDocumento').focus();
      return false;
   }
  document.getElementById('TextBoxClave').value = document.getElementById('TextBoxClave').value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById('TextBoxClave').value == ""){
      document.getElementById('TextBoxMensajeError').value = "Clave es requerido"	
      document.getElementById('TextBoxClave').focus();
      return false;
  }
  if (document.getElementById('TextBoxClave').value.length < 6) 
  {
      document.getElementById('TextBoxClave').focus();
      return false;
  }  
  
    return true;
}


function VerificarOperarios()
{  
  document.getElementById('TextBoxDocumento').value = document.getElementById('TextBoxDocumento').value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById('TextBoxDocumento').value == ""){
      document.getElementById('TextBoxMensajeError').value = "Documento es requerido";      
      document.getElementById('TextBoxDocumento').focus();
      return false;
  } 
   if (document.getElementById('TextBoxDocumento').value.length < 6) 
   { 	
      document.getElementById('TextBoxMensajeError').value = 'Documento debe ser mayor de 6 digTextBoxos';	
      document.getElementById('TextBoxDocumento').focus();
      return false;
   }
   if (document.getElementById('TextBoxDocumento').value.substring(0,1)==0) 
   { 	
       document.getElementById('TextBoxMensajeError').value = 'Error, primera cifra no puede ser 0';	
       document.getElementById('TextBoxDocumento').focus();             
       return false;
   }
   document.getElementById('TextBoxNombres').value = document.getElementById('TextBoxNombres').value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById('TextBoxNombres').value == "")
   {    
        document.getElementById('TextBoxMensajeError').value= 'Nombres es requerido';
        document.getElementById('TextBoxNombres').focus();
	return false;
   }
   document.getElementById('TextBoxApellidos').value = document.getElementById('TextBoxApellidos').value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById('TextBoxApellidos').value == "")
   {    
        document.getElementById('TextBoxMensajeError').value= 'Apellidos es requerido';	
        document.getElementById('TextBoxApellidos').focus();
	return false;
   }
  document.getElementById('TextBoxTelefono').value = document.getElementById('TextBoxTelefono').value.replace(/^\s+|\s+$/g,"");
  if (document.getElementById('TextBoxTelefono').value == "")
   {    
        document.getElementById('TextBoxMensajeError').value= 'Telefono es requerido';	
        document.getElementById('TextBoxTelefono').focus();
	return false;
   }
   if ((document.getElementById('TextBoxTelefono').value.length != 7)  && (document.getElementById('TextBoxTelefono').value.length != 10))
   { // Si es un teléfono celular debe ser de 10 dígTextBoxos	
       document.getElementById('TextBoxMensajeError').value= 'Por favor debe ingresar entre 7 y 10 digTextBoxos para el telefono';
       document.getElementById('TextBoxTelefono').focus();	 
       return false;
   }
   if (document.getElementById('TextBoxTelefono').value.substring(0,1)==0) 
   { 	
       document.getElementById('TextBoxMensajeError').value = 'Error, primera cifra no puede ser 0';	
       document.getElementById('TextBoxTelefono').focus();             
       return false;
   }
   document.getElementById('TextBoxCorreo').value = document.getElementById('TextBoxCorreo').value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById('TextBoxCorreo').value.length > 0)
   {
    if( !(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/.test(document.getElementById('TextBoxCorreo').value)) )                        
     {
       document.getElementById('TextBoxMensajeError').value= 'Formato de correo errado';
       document.getElementById('TextBoxCorreo').focus();   
       return false;    
     }
   }
    document.getElementById('TextBoxClave').value = document.getElementById('TextBoxClave').value.replace(/^\s+|\s+$/g,"");  
   if (document.getElementById('TextBoxClave').value == ""){
      document.getElementById('TextBoxMensajeError').value = "Clave es requerido"	
      document.getElementById('TextBoxClave').focus();
      return false;
   } 
   if ( document.getElementById('TextBoxClave').value.length < 6)
   {    
        document.getElementById('TextBoxMensajeError').value= 'Error, por favor ingrese una clave que contenga al menos 6 digTextBoxos';	
        document.getElementById('TextBoxClave').focus();
	return false;
   }       

   return true;
}

function VerificarListaValores()
{ 
   document.getElementById('TextBoxNombre').value = document.getElementById('TextBoxNombre').value.replace(/^\s+|\s+$/g,"");
   if (document.getElementById('TextBoxNombre').value == "")
   {    
       document.getElementById('TextBoxMensajeError').value= 'Nombre es requerido';	
       document.getElementById('TextBoxNombre').focus();
       return false;
   }
   return true;
}	

function VerificarEquipos()
{ 
   document.getElementById('TextBoxNombre').value = document.getElementById('TextBoxNombre').value.replace(/^\s+|\s+$/g,"");    
   if (document.getElementById('TextBoxNombre').value == "")
   {    
       document.getElementById('TextBoxMensajeError').value= 'Nombre es requerido';	
       document.getElementById('TextBoxNombre').focus();
       return false;
   }
   document.getElementById('TextBoxSerie').value = document.getElementById('TextBoxSerie').value.replace(/^\s+|\s+$/g,"");    
   if (document.getElementById('TextBoxSerie').value == "")
   {    
       document.getElementById('TextBoxMensajeError').value= 'Serie es requerido';	
       document.getElementById('TextBoxSerie').focus();
       return false;
   } 
   return true;
}

function VerificarCambioClave()
{ 
  document.getElementById('TextBoxClave').value = document.getElementById('TextBoxClave').value.replace(/^\s+|\s+$/g,"");  
  if (document.getElementById('TextBoxClave').value == ""){
      document.getElementById('TextBoxMensajeError').value = "Clave es requerido"	
      document.getElementById('TextBoxClave').focus();
      return false;
  }
  if (document.getElementById('TextBoxClave').value.length < 6) 
  {
      document.getElementById('TextBoxMensajeError').value = "Clave debe ser mayor de 6 digTextBoxos"
      document.getElementById('TextBoxClave').focus();
      return false;
  }
  document.getElementById('TextBoxClaveNueva').value = document.getElementById('TextBoxClaveNueva').value.replace(/^\s+|\s+$/g,"");  
   if (document.getElementById('TextBoxClaveNueva').value == ""){
      document.getElementById('TextBoxMensajeError').value = "Clave Nueva es requerido"	
      document.getElementById('TextBoxClaveNueva').focus();
      return false;
  }
  if (document.getElementById('TextBoxClaveNueva').value.length < 6) 
  {
      document.getElementById('TextBoxMensajeError').value = "Clave debe ser mayor de 6 digTextBoxos"
      document.getElementById('TextBoxClaveNueva').focus();
      return false;
  }
   if (document.getElementById('TextBoxClaveNueva').value == document.getElementById('TextBoxClave').value)
   {    
      document.getElementById('TextBoxMensajeError').value = "La clave debe ser diferente"
      document.getElementById('TextBoxClaveNueva').focus();
      return false;
   }
    document.getElementById('TextBoxConfirmar').value = document.getElementById('TextBoxConfirmar').value.replace(/^\s+|\s+$/g,"");  
    if (document.getElementById('TextBoxConfirmar').value == ""){
        document.getElementById('TextBoxMensajeError').value = "Debe confirmar la clave"	
        document.getElementById('TextBoxConfirmar').focus();
        return false;
  }
   
    if (document.getElementById('TextBoxConfirmar').value != document.getElementById('TextBoxClaveNueva').value)
   {    
      document.getElementById('TextBoxMensajeError').value = "La clave es diferente"
      document.getElementById('TextBoxConfirmar').focus();
      return false;
   }
   return true;
}	

function VerificarBusquedas()
{ 
   var indice = document.getElementById('TextBoxBuscar").selectedIndex;
   document.getElementById('TextBoxDatoBuscar').value = document.getElementById('TextBoxDatosBuscar').value.replace(/^\s+|\s+$/g,"");
   if ((document.getElementById('TextBoxDatoBuscar').value == "") && ( indice == -1))
   {    
      document.getElementById('TextBoxMensajeError').value = "Por favor seleccione o ingrese el dato a buscar"
      document.getElementById('TextBoxDatoBuscar').focus();
      return false;
   }   
   if (document.getElementById('TextBoxDatoBuscar').value.substring(0,1)==0) 
   { 	
       document.getElementById('TextBoxMensajeError').value = 'Error, primera cifra no puede ser 0';	
       document.getElementById('TextBoxDatoBuscar').focus();             
       return false;
   }
   return true;
}

function ConfirmarBorrado()
{
 if (confirm("¿ Esta seguro que desea eliminar este registro ?")) 
 {
   return true;
 }
 else
 {
  return false;
 }
}
