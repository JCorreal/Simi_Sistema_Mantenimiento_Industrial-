﻿
// DAL: Data Access Layer - Capa Acceso Datos Mantenimiento
using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Dao_Mantenimiento : Dao_General, IDao_Mantenimiento
    {
        // Default Constructor
        public Dao_Mantenimiento() { }

        public Mantenimiento obtenerMantenimiento(int datoBuscar)
        {
            Mantenimiento mantenimiento = new Mantenimiento();
            try
            {
                buscarRegistro("TBL_MANTENIMIENTO", datoBuscar);
                if (sdr.Read())
                {
                    mantenimiento.Mantenimiento_id = Convert.ToInt32(sdr["MANTENIMIENTO_ID"].ToString());
                    mantenimiento.Equipo_id = Convert.ToInt32(sdr["EQUIPO_ID"].ToString());
                    mantenimiento.Operario_id = Convert.ToInt32(sdr["OPERARIO_ID"].ToString());
                    mantenimiento.Fecha = Convert.ToDateTime(sdr["FECHA"].ToString());
                    mantenimiento.Observaciones = sdr["OBSERVACIONES"].ToString();
                }
                else
                {
                    mantenimiento = null;
                }
                sdr.Close();                
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return mantenimiento;
        }

        public int guardarMantenimiento(Mantenimiento mantenimiento, int Usuario)
        {
            int resultado = -1;
            try
            {
                using (Cn = new MySqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new MySqlCommand("SPR_IU_Mantenimiento", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_MANTENIMIENTO_ID", MySqlDbType.Int32, 4).Value = mantenimiento.Mantenimiento_id;
                    Cmd.Parameters.Add("p_EQUIPO_ID", MySqlDbType.Int32, 4).Value = mantenimiento.Equipo_id;
                    Cmd.Parameters.Add("p_OPERARIO_ID", MySqlDbType.Int32, 4).Value = mantenimiento.Operario_id;
                    Cmd.Parameters.Add("p_FECHA", MySqlDbType.DateTime, 10).Value = mantenimiento.Fecha;
                    Cmd.Parameters.Add("p_OBSERVACIONES", MySqlDbType.VarChar, 255).Value = mantenimiento.Observaciones;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", MySqlDbType.VarChar, 10).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", MySqlDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);                    
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public ArrayList controlarProgramacion(string tabla)
        {
            ArrayList arlLista = new ArrayList();
            arlLista = controlProgramacion(tabla);
            return arlLista;
        }

        public ArrayList cargarListado(string tabla)
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas(tabla);
            return arlLista;
        }

        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_Mantenimiento");
            return resultado;
        }
    }   
}