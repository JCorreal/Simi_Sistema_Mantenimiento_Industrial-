﻿// DAL: Data Access Layer - Capa Acceso Datos Variables Generales
using System;
using Oracle.DataAccess.Client;
using System.Data;
using System.Collections;
using ControlMantenimiento_NetDesktop.BO;

namespace ControlMantenimiento_NetDesktop.DAL
{
    public class Dao_General
    {
        // Default Constructor
        public Dao_General() { }

        public OracleConnection Cn;
        public OracleDataReader sdr;
        public OracleCommand Cmd;

        public void buscarRegistro(string tabla, int datoBuscar)
        {
            try
            {
                Cn = new OracleConnection(Conexion.obtenerConexion);
                Cmd = new OracleCommand("SPR_R_BuscarRegistro", Cn);
                Cmd.CommandType = CommandType.StoredProcedure;
                Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 20).Value = tabla;
                Cmd.Parameters.Add("p_DATOBUSCAR", OracleDbType.Varchar2, 50).Value = datoBuscar;    
		        Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                Cn.Open();
                sdr = Cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public ArrayList cargarListas(string tabla)
        {
            ArrayList arlLista = new ArrayList();
            try
            {
                using (Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("SPR_R_CargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 30).Value = tabla;
		            Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    Cn.Open();
                    sdr = Cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                          arlLista.Add(new CargaCombosListas(sdr.GetValue(0).ToString(), sdr.GetValue(0).ToString() + " " + sdr.GetValue(1).ToString()));
                    }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return arlLista;
        }

        public ArrayList controlProgramacion(string tabla)
        {
            ArrayList arlListControlProgramacion = new ArrayList();
            try
            {
                using (Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("SPR_R_CargarCombosListas", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 30).Value = tabla;
		            Cmd.Parameters.Add("Out_Data", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                    Cn.Open();
                    sdr = Cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                      arlListControlProgramacion.Add(sdr.GetValue(2).ToString());
                      arlListControlProgramacion.Add(sdr.GetValue(0).ToString());
                      arlListControlProgramacion.Add(sdr.GetValue(1).ToString());
                    }
                    sdr.Close();
                }
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return arlListControlProgramacion;
        }

	public int borrarRegistro(int datoEliminar, string tabla)
        {
            Int32 resultado = 0;
            try
            {
                using (Cn = new OracleConnection(Conexion.obtenerConexion))
                {
                    Cmd = new OracleCommand("SPR_D_Registro", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_TABLA", OracleDbType.Varchar2, 20).Value = tabla;
                    Cmd.Parameters.Add("p_CONDICION", OracleDbType.Int32, 10).Value = datoEliminar;
                    Cmd.Parameters.Add("p_RESULTADO", OracleDbType.Int32, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = (Int32)(Oracle.DataAccess.Types.OracleDecimal)Cmd.Parameters["p_RESULTADO"].Value;
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;
        }

        public void liberarRecursos()
        {
            Cmd.Dispose();
            if (Cn != null)
            {
                Cn.Close();
                Cn.Dispose();
            }
        }
    }
}
