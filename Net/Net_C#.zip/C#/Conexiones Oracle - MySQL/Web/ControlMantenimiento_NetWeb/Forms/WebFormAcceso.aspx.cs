﻿using System;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.BLL;

public partial class Forms_WebFormAcceso : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) { }
    private bool Verificar()
    {
        if (Funciones.validar_CampoVacio(TextBoxDocumento.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxDocumento.Focus();
            return false;
        }
        if (TextBoxDocumento.Text.Length != 6)
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje15;
            TextBoxDocumento.Focus();
            return false;
        }
        if (TextBoxDocumento.Text.Substring(0, 1) == "0")
        {
            TextBoxMensajeError.Text = Mensajes.Mensaje6;
            TextBoxDocumento.Focus();
            return false;
        }
        if (Funciones.validar_SoloNumeros(TextBoxDocumento.Text))
        {
            /* Acá no es bueno mostrar mensaje de que están enviando caracteres
              no numéricos en el documento, para evitar que programas
              maliciosos y/o hackers hagan daño
            */
            // TextBoxMensajeError.Text = Mensajes.Mensaje25;
            TextBoxDocumento.Focus();
            return false;
        }
        if (Funciones.validar_CampoVacio(TextBoxClave.Text))
        {
            TextBoxMensajeError.Text = Mensajes.MensajeCampoRequerido;
            TextBoxClave.Focus();
            return false;
        }
        if (TextBoxClave.Text.Length < 6) // Solo realizar búsqueda en BD si clave ingresada es mayor de 6
        {
            TextBoxClave.Focus();
            return false;
        }
        return true;
    }

    protected void ButtonIngresar_Click(object sender, EventArgs e)
    {
        if (Verificar())
        {
            Controlador_Operario controlador = Funciones.CrearControlador_Operario();
            Operario operario = controlador.obtenerAcceso(TextBoxDocumento.Text.Trim(), Convert.ToInt32(TextBoxClave.Text.Trim()));
            if (operario == null)
            {
                TextBoxMensajeError.Text = Mensajes.Mensaje2;
                TextBoxClave.Focus();
            }
            else
            {
                Session["TIPO_USUARIO"] = operario.Perfil;
                Session["NOMBRE_USUARIO"] = operario.Nombres + " " + operario.Apellidos;
                Funciones.UsuarioConectado = operario.Operario_id;
                Response.Redirect("~/Forms/WebFormMenu.aspx");
            }
        }
    }

    protected void ImageButtonAyuda_Click(object sender, System.Web.UI.ImageClickEventArgs e)
    {
        /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
         proc.EnableRaisingEvents = false;
         proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/ControlMantenimiento-NetWeb/Ayudas/Ayuda.chm";
         proc.Start();
         proc.Dispose();*/

        // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
        // donde descomprimió el archivo descargado de la web

    }

}