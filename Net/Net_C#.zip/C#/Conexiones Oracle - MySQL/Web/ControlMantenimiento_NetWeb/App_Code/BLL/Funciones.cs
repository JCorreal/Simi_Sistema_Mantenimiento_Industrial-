﻿// Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones

using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using ControlMantenimiento_NetWeb.DAL;

namespace ControlMantenimiento_NetWeb.BLL
{
    public class Funciones
    {
        public static string Pagina = null;
        public static int ParametroBuscar = 0;              
        public static string MensajeError;
        public static int UsuarioConectado;
        private static Dao_Operario dao_operario;
        private static Dao_Equipo dao_equipo;
        private static Dao_ListaValores dao_listavalores;
        private static Dao_Mantenimiento dao_mantenimiento;

        public Funciones() { }

        public static Controlador_Operario CrearControlador_Operario()
        {
            dao_operario = (Dao_Operario)AccesoDatosFactory.obtenerDao_Operario();
            return new Controlador_Operario(dao_operario);
        }

        public static Controlador_Equipo CrearControlador_Equipo()
        {
            dao_equipo = (Dao_Equipo)AccesoDatosFactory.obtenerDao_Equipo();
            return new Controlador_Equipo(dao_equipo);
        }

        public static Controlador_ListaValores CrearControlador_ListaValores()
        {
            dao_listavalores = (Dao_ListaValores)AccesoDatosFactory.obtenerDao_ListaValores();
            return new Controlador_ListaValores(dao_listavalores);
        }

        public static Controlador_Mantenimiento CrearControlador_Mantenimiento()
        {
            dao_mantenimiento = (Dao_Mantenimiento)AccesoDatosFactory.obtenerDao_Mantenimiento();
            return new Controlador_Mantenimiento(dao_mantenimiento);
        }

       
      
        // Funcion para validar campos de formulario vacios 
        public static bool validar_CampoVacio(string cadena)
        {
            bool Vacio = false;
            cadena = cadena.Trim();
            if (string.IsNullOrEmpty(cadena))
            {
                Vacio = true;
            }
            return Vacio;
        }


        // Funcion para validar direcciones de correo electronico
        public static bool validar_Correo(string cadena)
        {
            cadena = cadena.Trim();
            return !Regex.IsMatch(cadena, "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");
        }
        
        // Funcion para validar que haya solo numeros en un campo de texto
        public static bool validar_SoloNumeros(string cadena)
        {
            bool status = false;
            for (int i = 0; i < cadena.Length; i++)
            {
                if (!Char.IsNumber(cadena[i]))
                {
                    status = true;
                    break;
                }
            }
            return status;
        }

        // Funcion para limpiar los controles en un formulario (Solo TextBox)
        public static void limpiarForma(Control strWebForm)    
        {         
             foreach (Control strControl in strWebForm.Controls)
             {
                 if (strControl.GetType().ToString().Equals("System.Web.UI.WebControls.TextBox"))
                 {
                     ((TextBox)strControl).Text = string.Empty;
                 }
             }
        }

        // Funcion para comprobar existencia de numeros en nombres
        public static bool validar_SoloLetras(string cadena)
        {
            bool Resultado = false;
            for (int i = 0; i < cadena.Length; i++)
            {
                if (Char.IsNumber(cadena[i]))
                {
                    Resultado = true;
                    break;
                }
            }
            return Resultado;
        }

        // Funcion para eliminar posibles espacios de tabulacion
        public static string eliminarTabulador(string cadena, string Conversion)
        {
            cadena = cadena.Trim();
            while (cadena.IndexOf("  ", 0) != -1)
            {
                cadena = (cadena.Replace("  ", " "));
            }
            if (Conversion == "MAY")
            {
                cadena = cadena.ToUpper();
            }
            if (Conversion == "1MAY") // Organizar primera letra en Mayuscula y siguientes en Minuscula
            {
                cadena = cadena.ToLower();
                cadena = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(cadena);
            }
            return cadena;
        }
        
    }
}

