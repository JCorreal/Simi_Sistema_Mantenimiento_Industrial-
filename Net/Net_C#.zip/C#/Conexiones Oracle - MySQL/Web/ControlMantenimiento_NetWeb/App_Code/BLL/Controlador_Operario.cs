﻿using ControlMantenimiento_NetWeb.BLL;
using ControlMantenimiento_NetWeb.BO;
using ControlMantenimiento_NetWeb.DAL;
using System;
using System.Collections;


public class Controlador_Operario
{
    private readonly IDao_Operario _dao_operario;

    public Controlador_Operario(IDao_Operario dao_operario)
    {
        _dao_operario = dao_operario;
    }

    // Ingresar al Sistema
    public Operario obtenerAcceso(string datoBuscar, int clave)
    {
        Operario operario = null;
        operario = _dao_operario.obtenerAcceso(datoBuscar, clave);
        return operario;
    }

    public ArrayList cargarListado(string condicion)
    {
        return _dao_operario.cargarListado(condicion);
    }

    public Object obtenerRegistro(int datoBuscar)
    {
        Operario operario = new Operario();
        operario = _dao_operario.obtenerOperario(datoBuscar);
        return operario;
    }

    public int guardarOperario(Operario operario)
    {
        return _dao_operario.guardarOperario(operario, Funciones.UsuarioConectado);
    }

    public int guardarCambioClave(int claveAnterior, int claveNueva)
    {
        return _dao_operario.guardarCambioClave(Funciones.UsuarioConectado, claveAnterior, claveNueva);
    }

    public int eliminarRegistro(int datoEliminar)
    {
        return _dao_operario.eliminarRegistro(datoEliminar);
    }

}