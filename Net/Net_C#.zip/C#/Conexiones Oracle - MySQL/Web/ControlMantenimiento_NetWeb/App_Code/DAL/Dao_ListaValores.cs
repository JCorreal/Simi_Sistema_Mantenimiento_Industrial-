﻿// DAL: Data Access Layer - Capa Acceso Datos Marcas y Lineas
using System;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public class Dao_ListaValores : Dao_General, IDao_ListaValores
    {
        public Dao_ListaValores() { }  
        

        public ArrayList cargarListado(string tabla, string condicion)
        {
            ArrayList arlLista = new ArrayList();
            arlLista = cargarListas(tabla, condicion);
            return arlLista;
        }

        public int eliminarRegistro(int datoEliminar)
        {
            int resultado = 0;
            resultado = borrarRegistro(datoEliminar, "TBL_LISTAVALORES");
            return resultado;

        }

        public int guardarListaValores(ListaValores listavalores, int Usuario)
        {
            int resultado = -1;
            try
            {
                using (Cn = new SqlConnection(Conexion.obtenerConexion))
                {
                    Cmd = new SqlCommand("SPR_IU_ListaValores", Cn);
                    Cmd.CommandType = CommandType.StoredProcedure;
                    Cmd.Parameters.Add("p_LISTAVALORES_ID", SqlDbType.Int, 4).Value = listavalores.Listavalores_id;
                    Cmd.Parameters.Add("p_NOMBRE", SqlDbType.VarChar, 50).Value = listavalores.Nombre;
                    Cmd.Parameters.Add("p_DESCRIPCION", SqlDbType.VarChar, 255).Value = listavalores.Descripcion;
                    Cmd.Parameters.Add("p_TIPO", SqlDbType.VarChar, 50).Value = listavalores.Tipo;
                    Cmd.Parameters.Add("p_USUARIOCONECTADO", SqlDbType.Int, 4).Value = Usuario;
                    Cmd.Parameters.Add("p_RESULTADO", SqlDbType.Int, 1).Direction = ParameterDirection.Output;
                    Cn.Open();
                    Cmd.ExecuteNonQuery();
                    resultado = Convert.ToInt32(Cmd.Parameters["p_RESULTADO"].Value);
                }
            }
            catch (Exception e)
            {
                liberarRecursos();
                throw e;
            }
            finally
            {
                liberarRecursos();
            }
            return resultado;

        }

        public ListaValores obtenerListaValores(int datoBuscar)
        {
            ListaValores listavalores = new ListaValores();
            try
            {
                buscarRegistro("TBL_LISTAVALORES", datoBuscar);
                if (sdr.Read())
                {
                    listavalores.Listavalores_id = Convert.ToInt32(sdr["LISTAVALORES_ID"].ToString());
                    listavalores.Nombre = sdr["NOMBRE"].ToString();
                    listavalores.Descripcion = sdr["DESCRIPCION"].ToString();
                }
                else
                {
                    listavalores = null;
                }
                sdr.Close();
            }
            catch (Exception ex)
            {
                liberarRecursos();
                throw ex;
            }
            finally
            {
                liberarRecursos();
            }
            return listavalores;
        }
    }
}