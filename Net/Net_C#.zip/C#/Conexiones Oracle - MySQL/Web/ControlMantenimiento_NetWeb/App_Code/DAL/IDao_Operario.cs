﻿// Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa   

using System.Collections;
using ControlMantenimiento_NetWeb.BO;

namespace ControlMantenimiento_NetWeb.DAL
{
    public interface IDao_Operario
    {
        Operario obtenerAcceso(string documento, int clave);
        Operario obtenerOperario(int datoBuscar);
        int guardarOperario(Operario operario, int usuario);
        int guardarCambioClave(int Usuario, int ClaveAnterior, int ClaveNueva);
       
        ArrayList cargarListado(string Condicion);
        int eliminarRegistro(int DatoEliminar);
    }
        
}
