﻿using System;
using System.Windows.Forms;
using SIMI_Desktop.BO;
using SIMI_Desktop.BLL;
using System.Net;
using System.IO;

namespace SIMI_Desktop
{
    public partial class FormAcceso : Form
    {
        public FormAcceso()
        {
            InitializeComponent();
            var blankContextMenu = new ContextMenuStrip();
            TextBoxDocumento.ContextMenuStrip = blankContextMenu;           
            this.TextBoxDocumento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxDocumento_KeyPress);
            this.TextBoxClave.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxClave_KeyPress);
        }
      
        private bool ingresar;
        private int  ContadorIntentos = 0;
        private KeyPressEventArgs Tecla = new KeyPressEventArgs('\r'); // Send Enter

        private void TextBoxDocumento_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxDocumento.Text))               
                {
                    ingresar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxDocumento.Focus();
                    errorPro.SetError(TextBoxDocumento, Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxDocumento.Text.Length < 6)
                {
                    ingresar = false;
                }
                else
                {
                    errorPro.Clear();
                    TextBoxClave.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        private void TextBoxClave_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((e.KeyChar == '\r') || (e.KeyChar == 9)) // Si presionan Enter o Tab
            {
                if (Funciones.validar_CampoVacio(TextBoxClave.Text))
                {
                    ingresar = false;
                    MessageBox.Show(Mensajes.MensajeCampoRequerido, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TextBoxClave.Focus();
                    errorPro.SetError(TextBoxClave, Mensajes.MensajeCampoRequerido);
                }
                else if (TextBoxDocumento.Text.Length != 6)
                {
                    ingresar = false;
                }
                else
                {
                    errorPro.Clear();
                    ButtonIngresar.Focus();
                }
            }
            else
            {
                if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8)
                {
                    e.Handled = true; // Remover el caracter
                }
            }
        }

        
        
        private void ButtonIngresar_Click(object sender, EventArgs e)
        {          
          Intentos(); // Incrementar contador de intentos de acceso
          ingresar = true;
          TextBoxDocumento_KeyPress(ButtonIngresar, Tecla);
          if (ingresar)
          {
              TextBoxClave_KeyPress(ButtonIngresar, Tecla);
              if (ingresar)
              {
                    Controlador_Operario controlador = Funciones.crearControlador_Operario();
                    Operario operario = controlador.obtenerAcceso(TextBoxDocumento.Text.Trim(), Convert.ToInt32(TextBoxClave.Text.Trim()));
                    if (operario != null)
                  {
                      ingresar = true;
                      Funciones.UsuarioConectado = operario.Operario_id;
                      Funciones.PerfilAcceso = operario.Perfil;
                      Funciones.NombreUsuario = operario.Nombres + " " + operario.Apellidos;
                      SIMI_Desktop.FormMenu Form_Menu = new SIMI_Desktop.FormMenu();
                      this.Close();
                      this.Dispose();
                      Form_Menu.ShowDialog();                       
                  }
                  else
                  {                      
                      MessageBox.Show(Mensajes.Mensaje2, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
                      TextBoxClave.Focus();
                      errorPro.SetError(TextBoxClave, Mensajes.Mensaje2);                      
                  }
              }
          }
        }

        private void Intentos()
        {
            ContadorIntentos = (ContadorIntentos + 1);
            if (ContadorIntentos == 3)
            {
              Application.Exit(); // Usuario desconocido luego de 3 intentos, finalizar
            }
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
              Funciones.limpiarForma(panel2);
              TextBoxDocumento.Focus(); 
        }

        private void ButtonSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ButtonAyuda_Click(object sender, EventArgs e)
        {
            /* System.Diagnostics.Process proc = new System.Diagnostics.Process();
             proc.EnableRaisingEvents = false;
             proc.StartInfo.FileName = "E:/Fuentes CM/ControlMantenimiento-NetDesktop/ControlMantenimiento-NetDesktop/Ayudas/Ayuda.chm";
             proc.Start();
             proc.Dispose();*/

            // Estas líneas son las encargadas de llamar el archivo de ayudas .chm, está en comentario para que usted le coloque la ruta
            // donde descomprimió el archivo descargado de la web
        }

    }
}
