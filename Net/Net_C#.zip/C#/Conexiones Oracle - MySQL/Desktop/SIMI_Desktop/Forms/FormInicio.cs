﻿using System;
using System.Windows.Forms;

namespace SIMI_Desktop
{
    public partial class frmInicio : Form
    {
        public frmInicio()
        {
            InitializeComponent();
            tmrInicio.Enabled = true;  
        }    

        private void tmrInicio_Tick(object sender, EventArgs e)
        {
            tmrInicio.Enabled = false;
            this.Hide();            
            SIMI_Desktop.FormAcceso Form_Acceso = new SIMI_Desktop.FormAcceso();
            Form_Acceso.ShowDialog();           
        }       
    }
}
