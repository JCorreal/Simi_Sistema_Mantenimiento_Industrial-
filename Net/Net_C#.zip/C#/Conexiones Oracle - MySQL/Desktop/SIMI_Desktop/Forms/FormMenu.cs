﻿using System;
using System.Windows.Forms;
using SIMI_Desktop.BLL;
using System.Collections;

namespace SIMI_Desktop
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            if (Funciones.PerfilAcceso == 1) // Solo si tiene perfil de Administrador habilitar
            {
                menuToolStripMenuItem.Enabled = true;
                toolStripButton2.Enabled = true;
                toolStripButton3.Enabled = true;
                toolStripButton4.Enabled = true;
                toolStripButton5.Enabled = true;
                toolStripButton6.Enabled = true;
            }
            lblUsuarioConectado.Text = lblUsuarioConectado.Text + " " + Funciones.NombreUsuario;
        }

        private void operariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(0);  
        }

        private void equiposToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(1);
        }

        private void programarMantenimientoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Funciones.Fuente = "PROGRAMAR";
            SeleccionarOpcion(2);
        }

        private void modificarProgramacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Funciones.Fuente = "PROGRAMACION";
            SeleccionarOpcion(3);
        }

        private void lineasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(4);
        }

        private void marcasToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            SeleccionarOpcion(5); 
        }
        
        private void tostMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            int Seleccion = tostMenu.Items.IndexOf(e.ClickedItem);
            SeleccionarOpcion(Seleccion);
        }

        private void cambioClaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SIMI_Desktop.FormCambioClave Form_CambioClave = new SIMI_Desktop.FormCambioClave();
            Form_CambioClave.ShowDialog(this);
        }

        private void SeleccionarOpcion(int Opcion)
        {
            switch (Opcion)
            {
                case 0:
                       SIMI_Desktop.FormOperarios Form_Operarios = new SIMI_Desktop.FormOperarios();
                       Form_Operarios.ShowDialog(this);
                       break;
                case 1:
                       SIMI_Desktop.FormEquipos Form_Equipos = new SIMI_Desktop.FormEquipos();
                       Form_Equipos.ShowDialog(this);                                             
                       break;                
                case 2:
                       Funciones.Fuente = "PROGRAMAR";
                       VerificarExistencia();
                       break;
                case 3:                     
                       Funciones.Fuente = "PROGRAMACION";
                       VerificarExistencia();                       
                       break;
                case 4:
                        Funciones.ValorTipo = "LINEAS";
                        SIMI_Desktop.FormListaValores Form_ListaValores = new SIMI_Desktop.FormListaValores();
                        Form_ListaValores.ShowDialog(this);
                        break;
                case 5:
                        Funciones.ValorTipo = "MARCAS";
                        SIMI_Desktop.FormListaValores Form_ListaValoress = new SIMI_Desktop.FormListaValores();
                        Form_ListaValoress.ShowDialog(this);
                        break;
            }
        }

        private void VerificarExistencia()
        {
            Funciones.ListadeValores = new ArrayList();
            Controlador_Mantenimiento _controlador = Funciones.crearControlador_Mantenimiento();
            Funciones.ListadeValores = _controlador.controlarProgramacion(Funciones.Fuente);
            bool ExitenOperarios = false;
            bool ExitenEquipos = false;
            for (int i = 0; i < Funciones.ListadeValores.Count; i++)
            {
                if (Convert.ToString(Funciones.ListadeValores[i]).Trim().Equals("OPERARIOS"))
                {
                    ExitenOperarios = true;
                    break;
                }
            }
            for (int j = 0; j < Funciones.ListadeValores.Count; j++)
            {
                if (Convert.ToString(Funciones.ListadeValores[j]).Trim().Equals("EQUIPOS"))
                {
                   ExitenEquipos = true;
                   break;                    
                }
            }
            if (ExitenOperarios == false)
            {
                MessageBox.Show(Mensajes.Mensaje13, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (ExitenEquipos == false)
            {
                MessageBox.Show(Mensajes.Mensaje14, Mensajes.MensajeAplicacion, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                SIMI_Desktop.FormMantenimiento Form_Mantenimiento = new SIMI_Desktop.FormMantenimiento();
                Form_Mantenimiento.ShowDialog(this);
            }

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }       
    }
}
