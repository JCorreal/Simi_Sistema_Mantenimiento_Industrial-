﻿// Esta es una clase transversal, desde donde se instancia el Factory Method y hay algunas validaciones

using System;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using SIMI_Desktop.BO;
using SIMI_Desktop.DAL;
using System.Collections;

namespace SIMI_Desktop.BLL
{
    class Funciones
    {
        public static string ValorTipo;        // Variable para controlar Tipo en Lista de Valores (Lineas o Marcas)
        public static string Fuente;
        public static int PerfilAcceso;
        public static string NombreUsuario;
        public static int UsuarioConectado;
        public static ArrayList ListadeValores;
        private static Dao_Operario dao_operario;
        private static Dao_Equipo dao_equipo;
        private static Dao_ListaValores dao_listavalores;
        private static Dao_Mantenimiento dao_mantenimiento;

        public static Controlador_Operario crearControlador_Operario()
        {
            dao_operario = (Dao_Operario)AccesoDatosFactory.obtenerDao_Operario();
            return new Controlador_Operario(dao_operario);
        }

        public static Controlador_Equipo crearControlador_Equipo()
        {
            dao_equipo = (Dao_Equipo)AccesoDatosFactory.obtenerDao_Equipo();
            return new Controlador_Equipo(dao_equipo);
        }

        public static Controlador_ListaValores crearControlador_ListaValores()
        {
            dao_listavalores = (Dao_ListaValores)AccesoDatosFactory.obtenerDao_ListaValores();
            return new Controlador_ListaValores(dao_listavalores);
        }

        public static Controlador_Mantenimiento crearControlador_Mantenimiento()
        {
            dao_mantenimiento = (Dao_Mantenimiento)AccesoDatosFactory.obtenerDao_Mantenimiento();
            return new Controlador_Mantenimiento(dao_mantenimiento);
        }

        // Funcion para validar campos de frmulario vacios 
        public static bool validar_CampoVacio(string cadena)
        {
            bool Vacio = false;
            cadena = cadena.Trim();
            if (string.IsNullOrEmpty(cadena))
            {
                Vacio = true;
            }
            return Vacio;
        }

        // Funcion para validar direcciones de correo electronico
        public static bool validar_Correo(string cadena)
        {
            cadena = cadena.Trim();
            return !Regex.IsMatch(cadena, "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");         
        }

        // Funcion para comprobar existencia de caracteres no numericos
        public static bool validar_SoloNumeros(string cadena)
        {
            bool status = false;
            for (int i = 0; i < cadena.Length; i++)
            {
                if (!Char.IsNumber(cadena[i]))
                {
                    status = true;
                    break;
                }
            }
            return status;
        }

        // Funcion para comprobar existencia de caracteres diferentes de letras
        public static bool validar_SoloLetras(string cadena)
        {
            bool Resultado = false;
            for (int i = 0; i < cadena.Length; i++)
            {
                if (Char.IsNumber(cadena[i]))
                {
                    Resultado = true;
                    break;
                }
            }
            return Resultado;
        }

        // Funcion para limpiar los controles en un frmulario (Solo TextBox)
        public static void limpiarForma(Panel pnl)
        {
            foreach (Control oControls in pnl.Controls)
            {
                if (oControls is TextBox)
                {
                    oControls.Text = ""; 
                }
            }
        }

        // Funcion para eliminar posibles espacios de tabulacion en un campo de texto
        public static string eliminarTabulador(string cadena, string Conversion)
        {
            cadena = cadena.Trim();
            while (cadena.IndexOf("  ", 0) != -1)
            {
                cadena = (cadena.Replace("  ", " "));
            }
            if (Conversion == "MAY")
            {
                cadena = cadena.ToUpper();
            }
            else if (Conversion == "1MAY") // Organizar primera letra en Mayuscula y siguientes en Minuscula
            {
                cadena = cadena.ToLower();
                cadena = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(cadena);
            }
            return cadena;
        }
        
        // Default Constructor
        public Funciones()
        { }
    }
}
