package dal; // Interface que expone los métodos que implementa el DAO de Mantenimiento

import bo.CargarListado;
import bo.Mantenimiento;
import java.util.ArrayList;

public interface IDao_Mantenimiento {
  
  public Mantenimiento obtenerMantenimiento(int datoBuscar);
  public int guardarMantenimiento(Mantenimiento mantenimiento, int Usuario);
  public int eliminarRegistro(int datoEliminar);   
  public ArrayList cargarEquiposOperarios(String tabla); 
  public ArrayList<CargarListado> cargarListado();   
}
