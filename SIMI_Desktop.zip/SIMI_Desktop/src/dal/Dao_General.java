package dal; // Este es un DAO General con métodos transvesales que los demás extienden

import bo.CargarListado;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Dao_General 
{
    
    public  CallableStatement cst;  // Procedimientos Almacenados
    public  ResultSet Rset;         // Cursor
    public  Connection con;         // Alias para la Conexión   
   
    public synchronized void buscarRegistro(String tabla, int datoBuscar)
    { 
        try
        {  
            con = Conexion.obtenerConexion();
            cst = con.prepareCall("{call SPR_R_BuscarRegistro (?,?,?)}");
            cst.setString(1, tabla);
            cst.setInt(2, datoBuscar);                               
            cst.registerOutParameter(3, oracle.jdbc.OracleTypes.CURSOR);
            cst.execute();
            if (cst.getObject(3)!= null)
            {
             Rset = (ResultSet) cst.getObject(3);                             
            }
        }            
        catch (SQLException ex) 
        {
            System.out.println("Error " +ex); 
            liberarRecursos();
        }           
        catch (Exception ex) 
        {
            System.out.println("Error " +ex);
            liberarRecursos();
        }
    }

    
    public synchronized ArrayList<CargarListado> cargarListas(String tabla )
    {
        ArrayList<CargarListado> arlListado = new ArrayList();
        try 
        {             
            con = Conexion.obtenerConexion();             
            cst = con.prepareCall("{call SPR_R_CargarListado (?,?,?)}");
            cst.setString (1, tabla);
            cst.setString (2, "");
            cst.registerOutParameter(3, oracle.jdbc.OracleTypes.CURSOR);
            cst.execute();
            Rset = (ResultSet) cst.getObject(3);
            while(Rset.next())
            {               
               arlListado.add(new CargarListado(Rset.getString(1), Rset.getString(2), Rset.getString(3), Rset.getString(4), Rset.getString(5), Rset.getString(6)));                                    
            }
            Rset.close();                     
        }
        catch (SQLException ex)
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex) 
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        finally
        {
            liberarRecursos();
	}
        return arlListado;
    } 
     
    public synchronized int borrarRegistro(String tabla, int datoEliminar)
    {
        int resultado = -1;
        try
        {            
            con = Conexion.obtenerConexion();
            cst = con.prepareCall("{call SPR_D_Registro (?,?,?)}");
            cst.setString(1, tabla);
            cst.setInt(2, datoEliminar );                   
            cst.registerOutParameter(3,java.sql.Types.INTEGER);
            cst.execute();
            resultado = cst.getByte(3);           
        }           
        catch (SQLException ex) 
        {
            System.out.println("Error: " +ex);
            liberarRecursos();
        }
        catch (Exception ex) 
        {
            System.out.println("Error: " +ex);
            liberarRecursos();
        }
        finally
        {
	    liberarRecursos();
	} 
        return resultado;
    }
        
    public synchronized ArrayList<CargarListado> cargarArray(String tabla)
    { 
        ArrayList arlListado = new ArrayList();
        try 
        {             
            con = Conexion.obtenerConexion();             
            cst = con.prepareCall("{call SPR_R_CargarCombosListas (?,?)}");
            cst.setString(1, tabla);
            cst.registerOutParameter(2, oracle.jdbc.OracleTypes.CURSOR);
            cst.execute();
            Rset = (ResultSet) cst.getObject(2);            
            while(Rset.next())
            {               
               arlListado.add(Rset.getString(3));  
               arlListado.add(Rset.getString(1));    
               arlListado.add(Rset.getString(2));  
            }
            Rset.close();                  
        }
        catch (SQLException ex) 
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        catch (Exception ex) 
        {
            System.out.println("Error : " +ex);
            liberarRecursos();
        }
        finally
        {
            liberarRecursos();
        }       
        return arlListado;
    }

    public synchronized void liberarRecursos()
    { // Garantizar que se cierren todos los objetos asociados a la Conexion
        try 
        {            
            cst.close();
            con.close();            
        } 
        catch (SQLException ex) 
        {
           System.out.println("Error Liberando Recursos: " +ex);           
        }              
    }
}
