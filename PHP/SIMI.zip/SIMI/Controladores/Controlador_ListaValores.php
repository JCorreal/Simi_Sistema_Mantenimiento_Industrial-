<?php // Este es el Controlador para el registro de Marcas y Lineas
     
class Controlador_ListaValores {
    
    protected $idao_listavalores;
        
    public function __construct(IDao_ListaValores $idao_listavalores)
    {
        $this->idao_listavalores = new Dao_ListaValores();
    }
            
    public function obtenerListaValores($datoBuscar)
    {
       return $this->idao_listavalores->obtenerListaValores($datoBuscar);
    }
    
    public function guardarListaValores ($object)
    {
      $usuario = Funciones::obtenerUsuario(); 
      return $this->idao_listavalores->guardarListaValores($object, $usuario);
    }
    
    public function cargarListado($tabla, $opcion) {
       return $this->idao_listavalores->cargarListado($tabla, $opcion);
    }
    
    public function eliminarRegistro($datoBuscar){        
        return $this->idao_listavalores->eliminarRegistro($datoBuscar);
    }
}
