<!DOCTYPE html>
<html lang="es">
    <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>Listado Operarios</title>
            <link href="../resources/css/bootstrap1.min.css" rel="stylesheet" type="text/css"/>
            <script src="js/ValidacionesPaginas.js" type="text/javascript">
            </script>
    </head>
    
    <body>   
        <?php           
            require_once '../Vistas/WebPage_Maestro.php';                 
            require_once '../Controladores/AutoLoader.php';
            spl_autoload_register();  

            $Pagina = 'WebPage_Operarios.php';
            $datoBuscar = NULL;
            session_start();           
            if ($_SESSION['PerfilAcceso'] != 1)
            {
                $usuario = base64_encode($_SESSION['UsuarioConectado']);
                header("Location: ../Vistas/$Pagina?id=$usuario");
            }
            else 
            {
                if (filter_input_array(INPUT_GET))
                {
                   $datoBuscar = filter_input(INPUT_GET, 'Buscar', FILTER_SANITIZE_NUMBER_INT);
                }          

                $controlador = Funciones::crearControlador_Operario();     
                if (filter_input_array(INPUT_POST))    
                {                 
                    if (filter_input(INPUT_POST, 'itBusqueda') != '')
                    {
                      $datoBuscar = filter_input(INPUT_POST, 'itBusqueda', FILTER_SANITIZE_NUMBER_INT);
                      header("Location: ../Vistas/WebPage_ListadoOperarios.php?Buscar=$datoBuscar");                 
                    }                  
                    else
                    {                           
                          header("Location: ../Vistas/$Pagina");  
                    }               
                }
              }          
        ?>   
    
        <form name="WebPage_ListadoOperarios" action="WebPage_ListadoOperarios.php" method="post">
               <div class="container">
		<br>
                
                <table width="55%" align="center" border="1" cellspacing="0" cellpadding="6">
          
                    <tr>
                        <td align="center" width="55%"  bgcolor="teal"><label class="titulos">Operarios&nbsp;<i class="fa fa-group"></i></label></td>             
                    </tr>
	                            
                    <div align="center">
                         <input type="submit" name="btnNuevo" value="Nuevo"/>            
                         <input type="submit" name="btnBuscar" value="Buscar" />   
                            <input class="small"
                                   type="text"
                                   id="itBusqueda"
                                   name="itBusqueda"                         
                                   maxLength="10"                                                                                                           
                                   onkeypress="return ValidarNumeros(event)" 
                                   onkeydown="return AnularPegado(event)" 
                                   value="">
                          </input>                 
                   </div>
                <table/>
          	
		<table width="55%" rules="all" border="1" align="center">                
	              <thead>		     
                             <th>Documento</th>
                             <th>Operario</th>  
                             <th>Telefono</th>
                             <th>Correo</th>  
                             <th>Foto</th>                                    
			     <th>Acciones</th>	
	              </thead> 
                      <tbody> 
                          <?php
                              $vector_resultado = $controlador->cargarListado($datoBuscar);
                              foreach($vector_resultado as $lista => $valor){
		          ?>
                            <tr>                                
                                <td><?php echo $valor[1];  ?></td>
                                <td><?php echo $valor[2];  ?></td>
                                <td><?php echo $valor[3];  ?></td>
                                <td><?php echo $valor[4];  ?></td>
                                <?php 
                                    if (isset($valor[5]) != NULL)
                                    {
                                ?>   
                                <td width=30><img src='../resources/Imagenes/<?php echo $valor[5]; ?>' width='30'></td>
                                <?php                                 
                                }
                                else
                                {
                                ?> 
                                    <td width=30><img src='../resources/Imagenes/user-default.png' width='30'></td>
                                <?php                                 
                                }
                                ?>                                                                   
                                <td style="width:100px;">
                                <a href="../Vistas/WebPage_Operarios.php?id=<?php echo base64_encode($valor[0]);  ?>" title="Editar datos" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>                                                                         
                                &nbsp &nbsp  
                                 <a href="../Form_Response/Response_Eliminar.php?accion=1&id=<?php echo base64_encode($valor[0]);  ?> " onclick="return ConfirmarBorrado();"  title="Eliminar" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                            </tr>
			    <?php } ?>
                    </tbody>        
                </table>
	   </div>
	 </div>	              
        </form>    
    </body>
</html>

