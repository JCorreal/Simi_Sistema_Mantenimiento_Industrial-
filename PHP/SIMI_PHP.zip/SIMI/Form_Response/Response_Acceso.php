<?php // Este es el Response del Acceso al aplicativo    
       
class Response_Acceso
 {
    
    public static function ingresarSistema()
    {
        $operario = NULL;    
        $documento = filter_input(INPUT_POST, 'itDocumento', FILTER_SANITIZE_NUMBER_INT);
        $clave = filter_input(INPUT_POST, 'itClave', FILTER_SANITIZE_NUMBER_INT);
        
        if (($documento != NULL) && ($clave != NULL)) 
        {        
            $controlador = Funciones::crearControlador_Operario();                          
            $operario =  $controlador->obtenerAcceso($documento, $clave); 
            if ($operario != NULL)
            {      
                session_start(); 
                $_SESSION['UsuarioConectado'] = $operario->getOperario_Id();      
                $_SESSION['PerfilAcceso'] = $operario->getPerfil();
                $_SESSION['NombreUsuario']  = $operario->getNombres();      
                header("Location: ../Vistas/WebPage_Menu.php");  
            }      
        }
    }         
       
 }


