<?php // Este es el Response para el registro de Equipos y Maquinaria
    
class Response_Equipo {
      
    public static function grabarEquipo()
    {
        $equipo = new Equipo();          
        $equipo->setEquipo_id(filter_input(INPUT_POST, 'itCampoClave', FILTER_SANITIZE_NUMBER_INT));
        $equipo->setNombre_equipo(strtoupper(filter_input(INPUT_POST, 'itNombre', FILTER_SANITIZE_STRING)));
        $equipo->setMarca(filter_input(INPUT_POST,'slMarcas'));      
        $equipo->setSerie(strtoupper(filter_input(INPUT_POST, 'itSerie',FILTER_SANITIZE_STRING)));
        $equipo->setLinea(filter_input(INPUT_POST, 'slLineas')); 
        $Lubricacion = filter_input(INPUT_POST, 'chLubricacion', FILTER_DEFAULT);
        $equipo->setLubricacion(!empty($Lubricacion)?1:0);     
        $controlador = Funciones::crearControlador_Equipo();
        $Resultado = $controlador->guardarEquipo($equipo);
        if ($Resultado == 0)
        {
            $mensaje = NULL;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");
        }
        elseif ($Resultado == 1)
        {
            $mensaje = Mensajes::Mensaje7;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");            
        }
        else 
        {
            $mensaje = Mensajes::MensajeErrorBD; 
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
        }           
    }
}

