<?php // Este es el Response para el cambio de clave de acceso al aplicativo    
     
class Response_CambioClave {

    public static function grabarCambioClave($claveanterior, $clavenueva)
    {         
        $controlador = Funciones::crearControlador_Operario();              
        $Resultado = $controlador->guardarCambioClave($claveanterior, $clavenueva);
        if ($Resultado == 0)
        { 
            $mensaje = NULL;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");
        }     
        elseif ($Resultado == 1)
        {
            $mensaje = Mensajes::Mensaje3;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");   
        }
        else 
        {
            $mensaje = Mensajes::MensajeErrorBD;
            header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje");
        }      
          
    }
}


