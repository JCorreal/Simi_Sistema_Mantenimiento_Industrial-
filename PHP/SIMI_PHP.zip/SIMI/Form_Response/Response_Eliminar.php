<?php
        require_once '../Controladores/AutoLoader.php';
        spl_autoload_register();

        $id = base64_decode(filter_input(INPUT_GET, 'id'), FILTER_SANITIZE_NUMBER_INT);                 
        $tabla = (filter_input(INPUT_GET, 'accion'));
        $Resultado = -1;             
        if ($tabla == '1') // TBL_OPERARIOS
        {
            $controlador = Funciones::crearControlador_Operario();
            $Resultado = $controlador->eliminarRegistro($id);
            if ($Resultado == 1)
            {
                $mensaje= Mensajes::Mensaje20;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }  
            else if ($Resultado == 0)
            {
                $mensaje = NULL;  
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
            }
            else
            {
                $mensaje = Mensajes::MensajeErrorBD;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }
        }
        if ($tabla == '2') // TBL_LISTAVALORES
        {
            $controlador  = Funciones::crearControlador_ListaValores();
            $Resultado = $controlador->eliminarRegistro($id);
            if ($Resultado == 1)
            {                   
                $mensaje= Mensajes::Mensaje9;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }
            else if ($Resultado == 0)
            {
                $mensaje = NULL;  
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
            }
            else
            {
                $mensaje = Mensajes::MensajeErrorBD;
                header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
            }
        }
        if ($tabla == '3') // TBL_EQUIPOS
        {
           $controlador  = Funciones::crearControlador_Equipo();
           $Resultado = $controlador->eliminarRegistro($id);
           if ($Resultado == 1)
           {                   
               $mensaje = Mensajes::Mensaje22;                                
               header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
           }
           else if ($Resultado == 0)
           {
                  $mensaje = NULL;  
                  header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
           }
           else
           {
                  $mensaje = Mensajes::MensajeErrorBD;
                  header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
           }
        }
        if ($tabla == '4') // TBL_MANTENIMIENTO
        {
           $controlador  = Funciones::crearControlador_Mantenimiento();
           $Resultado = $controlador->eliminarRegistro($id);                         
           if ($Resultado == 0)
           {
               $mensaje = NULL;  
               header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=R&mensaje=$mensaje");                                 
           }
           else
           {
               $mensaje = Mensajes::MensajeErrorBD;
               header("Location: ../Vistas/WebPage_Respuesta.php?respuesta=E&mensaje=$mensaje"); 
           }
        }
