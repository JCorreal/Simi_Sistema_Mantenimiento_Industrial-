<!DOCTYPE html>
<html>    
    <head>
            <title>.</title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">                    
            <link href="../resources/css/Estilo.css" rel="stylesheet" type="text/css"/>
            <link href="../resources/css/formoid-solid-green.css" rel="stylesheet" type="text/css"/>        
            <link href="../resources/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>    
            <script src="../resources/js/jquery.min.js" type="text/javascript"></script>
            <script src="../resources/js/formoid-solid-green.js" type="text/javascript"></script>        
            <script src="../resources/js/FuncionesTeclado.js" type="text/javascript"></script>               
    </head> 
        
    <body>
            <?php  
                 require_once '../Controladores/AutoLoader.php';                 
                 spl_autoload_register(); 
            ?> 
            <div class="DivSuperior"><br><?php echo Mensajes::MensajeAplicacion;?>
                    <div class="DivIzquierda"></div>                                        
            </div>    
            <br><br>
    </body>
</html>



