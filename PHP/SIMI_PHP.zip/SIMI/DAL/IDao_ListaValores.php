<?php // Interface que expone los métodos que implementa el DAO de Marcas-Líneas

interface IDao_ListaValores {
   
   public function obtenerListaValores($datoBuscar);
   public function guardarListaValores($listavalores, $usuario);
   public function cargarListado($tabla, $opcion);
   public function eliminarRegistro($datoEliminar);

}
