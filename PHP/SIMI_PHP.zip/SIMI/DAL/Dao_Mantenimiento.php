<?php // Capa Acceso Datos para programación de Mantenimiento
    
class Dao_Mantenimiento extends Dao_General implements IDao_Mantenimiento{
     
    public function obtenerMantenimiento($datoBuscar)
    {  
        try
        {      
            $vecr = parent::buscarRegistro('TBL_MANTENIMIENTO', $datoBuscar);
            if ($vecr != NULL)
            {
                $mantenimiento = new Mantenimiento();         
                $mantenimiento->setMantenimiento_Id($vecr[0][0]);
                $mantenimiento->setEquipo_Id($vecr[0][1]);
                $mantenimiento->setOperario_Id($vecr[0][2]);        
                $mantenimiento->setFecha($vecr[0][3]);
                $mantenimiento->setObservaciones($vecr[0][4]);
                unset($vecr);
                return $mantenimiento;
            }
            else
            {
              return NULL;
            }
        }
        catch (Exception $ex)
        {
           echo $ex;
        }
    }
  
    public function guardarMantenimiento($mantenimiento, $usuario)
    {  
        $cn = Conexion::obtenerConexion(); 
        try 
        {        
            $cn->query("SET @result = 1");
            $cn->query("CALL SPR_IU_Mantenimiento('" . $mantenimiento->getMantenimiento_Id() . "', 
                                                  '" . $mantenimiento->getEquipo_Id() . "', 
                                                  '" . $mantenimiento->getOperario_Id() . "',
                                                  '" . $mantenimiento->getFecha() . "', 
                                                  '" . $mantenimiento->getObservaciones() . "', 
                                                  '" . $usuario . "', 
                                                  @result)");

            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];
        }
        catch (Exception $ex)
        {
           mysqli_close($cn);
           echo $ex;
        }      
    }
  
    public function controlarProgramacion($tabla) {
        $listaElementos = parent::controlProgramacion($tabla);
        return $listaElementos;
    }
    
    public function cargarListado($opcion) {
        $listaElementos = parent::cargarListas("TBL_MANTENIMIENTO", $opcion);
        return $listaElementos;
    }
    
    public function eliminarRegistro($datoEliminar) {
      $result = parent::borrarRegistro("TBL_MANTENIMIENTO", $datoEliminar);
      return $result;
    }
}
