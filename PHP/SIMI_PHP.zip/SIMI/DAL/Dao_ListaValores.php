<?php // Capa Acceso Datos para Marcas y Líneas
    
class Dao_ListaValores extends Dao_General implements IDao_ListaValores {
  
    public function obtenerListaValores($datoBuscar)
    {  
        try
        {
            $vecr = parent::buscarRegistro('TBL_LISTAVALORES', $datoBuscar);
            if ($vecr != NULL)
            {
                $listavalores = new ListaValores();
                $listavalores->setListaValores_Id($vecr[0][0]);
                $listavalores->setNombre($vecr[0][1]);
                $listavalores->setDescripcion($vecr[0][2]);
                $listavalores->setTipo($vecr[0][3]);   
                unset($vecr);
                return $listavalores;
            }
            else
            {
                return NULL;
            }
        }
        catch (Exception $ex)
        {
           echo $ex;
        }
    }

    public function guardarListaValores($listavalores, $usuario)
    {          
        $cn = Conexion::obtenerConexion();  
        try
        {             
            $cn->query("SET @result = 1");
            $cn->query("CALL SPR_IU_ListaValores('" . $listavalores->getListaValores_Id() . "', 
                                                 '" . $listavalores->getNombre() . "', 
                                                 '" . $listavalores->getDescripcion() . "', 
                                                 '" . $listavalores->getTipo() . "', 
                                                 '" . $usuario . "',  
                                                 @result)");

            $res = $cn->query("SELECT @result AS result");
            $row = $res->fetch_assoc();
            mysqli_close($cn);
            return $row['result'];
        }
        catch (Exception $ex)
        {
           mysqli_close($cn);
           echo $ex;
        }  
    }
  
   
    public function cargarListado($tabla, $opcion) {
        $listaElementos = parent::cargarListas($tabla, $opcion);
        return $listaElementos;
    }
    
    public function eliminarRegistro($datoEliminar) {
      $result = parent::borrarRegistro("TBL_LISTAVALORES", $datoEliminar);
      return $result;
    }
}
