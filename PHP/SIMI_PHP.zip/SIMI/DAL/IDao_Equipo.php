<?php // Interface que expone los métodos que implementa el DAO de Equipos

interface IDao_Equipo {

    public function obtenerEquipo($datoBuscar);
    public function guardarEquipo($equipo, $usuario);
    public function cargarListado($opcion);
    public function controlarProgramacion();
    public function eliminarRegistro($datoEliminar);

}
